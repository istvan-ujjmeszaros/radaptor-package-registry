<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->registerLibrary(LibrariesSoAdmin::__ADMIN_SITE); ?>
<?php $this->registerLibrary(LibrariesSoAdmin::STIMULUS_LOADER); ?>
<?php
$lang = (string)($this->props['lang'] ?? substr(Kernel::getLocale(), 0, 2));
$administration_string = (string)($this->strings['admin.menu.section.administration'] ?? '');
$site_name = (string)($this->props['site_name'] ?? Config::APP_SITE_NAME->value());
$document_title = (string)($this->props['document_title'] ?? trim($administration_string . ' - ' . $site_name, ' -'));
$administration_label = (string)($this->props['administration_label'] ?? $administration_string);
?>
<!DOCTYPE html>
<html lang="<?= e($lang) ?>">
<head>
	<meta charset="utf-8">
	<title><?= e($document_title) ?></title>
	<meta name="robots" content="NOINDEX, NOFOLLOW">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="/favicon.ico">
	<link rel="icon" href="/favicon.ico" type="image/x-icon">
	<meta name="viewport" content="width=device-width">
	<?= $this->getRenderer()->getLibraryDebugInfo(); ?>
	<?= $this->getRenderer()->getCss(); ?>
	<?= $this->getRenderer()->getJsTop(); ?>
	<!--link rel="stylesheet" href="debug.css" type="text/css"-->

</head>
<body>
<?= $this->getRenderer()->fetchInnerHtml(); ?>
<div id="container">
	<!-- TOPMENU -->
	<div id="topmenu-container">
		<div id="topmenu">
			<?= $this->fetchSlot('top_menu_admin'); ?>
		</div>
	</div>
	<!-- /TOPMENU -->
	<!-- HEADER -->
	<div id="header">
		<div id="header-left">
			<?= $this->fetchSlot('admin_menu'); ?>
		</div>
		<div id="logo"><a href="/"><?= e($site_name) ?> - <?= e($administration_label) ?></a></div>
		<div class="cleaner"></div>
	</div>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="admin-body-layout">
		<div class="admin-sidebar-panel">
			<?= $this->fetchSlot('side_menu_admin'); ?>
		</div>
		<div class="admin-content-panel">
			<?= $this->fetchSlot('content'); ?>
		</div>
	</div>
	<!-- /CONTENT -->
	<br class="cleaner">
</div>
<?= $this->getRenderer()->getJs(); ?>
<script type="text/javascript">
	renderSystemMessages();
</script>
<?= $this->fetchSlot('page_chrome'); ?>
<?= $this->getRenderer()->fetchClosingHtml(); ?>
