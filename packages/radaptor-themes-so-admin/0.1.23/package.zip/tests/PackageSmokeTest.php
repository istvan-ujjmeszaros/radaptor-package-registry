<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class PackageSmokeTest extends TestCase
{
	public function testRegistryPackageMetadataIsValid(): void
	{
		$root = dirname(__DIR__);
		$metadata_path = $root . '/.registry-package.json';
		$this->assertFileExists($metadata_path);

		$decoded = json_decode((string) file_get_contents($metadata_path), true);
		$this->assertIsArray($decoded);
		$this->assertSame('radaptor/themes/so-admin', $decoded['package'] ?? null);
		$this->assertSame('theme', $decoded['type'] ?? null);
		$this->assertSame('so-admin', $decoded['id'] ?? null);
		$this->assertIsString($decoded['dependencies']['radaptor/core/cms'] ?? null);
		$this->assertMatchesRegularExpression('/^\^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $decoded['dependencies']['radaptor/core/cms']);
	}

	public function testThemeEntrypointsExist(): void
	{
		$root = dirname(__DIR__);

		$this->assertFileExists($root . '/theme/_layout/template.layout_admin_default.php');
		$this->assertFileExists($root . '/theme/Cms/template._admin_dropdown.php');
		$this->assertDirectoryExists($root . '/public/assets/themes/so-admin');
		$this->assertFileExists($root . '/public/assets/themes/so-admin/controllers/form-builder-controller.js');
		$this->assertFileExists($root . '/public/assets/themes/so-admin/controllers/form-list-controller.js');
		$this->assertFileExists($root . '/public/assets/themes/so-admin/controllers/form-hooks-panel.js');
		$this->assertFileExists($root . '/public/assets/themes/so-admin/controllers/form-builder-preview-drop-controller.js');
		$this->assertFileExists($root . '/public/assets/themes/so-admin/css/form-builder.css');
	}

	public function testFormAdminEntrypointsAreWiredToTheListWidgetAndAssets(): void
	{
		$root = dirname(__DIR__);
		$side_menu_source = (string) file_get_contents($root . '/theme/SideMenuAdmin/template.sideMenuAdmin.php');
		$library_source = (string) file_get_contents($root . '/theme/class.LibrariesSoAdmin.php');
		$list_controller_source = (string) file_get_contents($root . '/public/assets/themes/so-admin/controllers/form-list-controller.js');
		$css_source = (string) file_get_contents($root . '/public/assets/themes/so-admin/css/form-builder.css');

		$this->assertStringContainsString('::CAPTUREFORMLIST', $side_menu_source);
		$this->assertStringContainsString('::CAPTUREFORMBUILDER', $side_menu_source);
		$this->assertStringContainsString('widget_url($captureFormListWidget)', $side_menu_source);
		$this->assertStringContainsString('__ADMIN_FORM_BUILDER', $library_source);
		$this->assertStringContainsString('/assets/packages/themes/so-admin/css/form-builder.css', $library_source);
		$this->assertStringContainsString('searchParams.get("form")', $list_controller_source);
		$this->assertStringContainsString('searchParams.get("edit")', $list_controller_source);
		$this->assertStringContainsString('window.location.replace(url.toString())', $list_controller_source);
		$this->assertStringContainsString('searchParams.set("form", slug)', $list_controller_source);
		$this->assertStringContainsString('searchParams.delete("form")', $list_controller_source);
		$this->assertStringContainsString('searchParams.delete("edit")', $list_controller_source);
		$this->assertStringNotContainsString('searchParams.set("edit"', $list_controller_source);
		$this->assertStringContainsString('fragmentUrl.searchParams.set("definition_slug", slug)', $list_controller_source);
		$this->assertStringContainsString('this.boundBuilderChanged = (event) => this.onBuilderChanged(event)', $list_controller_source);
		$this->assertStringContainsString('this.editorDirty = Boolean(event.detail?.dirty)', $list_controller_source);
		$this->assertStringContainsString('body:has(.form-list)', $css_source);
		$this->assertStringContainsString('.form-list__card', $css_source);
		$this->assertStringContainsString('.form-list__editor-modal', $css_source);
		$this->assertStringContainsString('.form-builder__hooks-overlay', $css_source);
		$this->assertStringContainsString('.form-builder__hook-target-list', $css_source);
		$this->assertStringContainsString('.form-builder__hook-check .form-check-input', $css_source);
		$this->assertStringContainsString('.form-builder__hook-metadata-field', $css_source);
		$this->assertStringContainsString('.form-builder__draft-row', $css_source);
	}

	public function testFormHooksAdminUiEntrypointsExist(): void
	{
		$root = dirname(__DIR__);
		$list_source = (string) file_get_contents($root . '/public/assets/themes/so-admin/controllers/form-list-controller.js');
		$builder_source = (string) file_get_contents($root . '/public/assets/themes/so-admin/controllers/form-builder-controller.js');
		$panel_source = (string) file_get_contents($root . '/public/assets/themes/so-admin/controllers/form-hooks-panel.js');

		$this->assertStringContainsString('import { createFormHooksPanel } from "./form-hooks-panel.js"', $list_source);
		$this->assertStringContainsString('import { createFormHooksPanel } from "./form-hooks-panel.js"', $builder_source);
		$this->assertStringContainsString('this.hooksPanel = createFormHooksPanel(this, {', $list_source);
		$this->assertStringContainsString('this.hooksPanel = createFormHooksPanel(this, {', $builder_source);
		$this->assertStringContainsString('controllerName: "form-list"', $list_source);
		$this->assertStringContainsString('controllerName: "form-builder"', $builder_source);

		$this->assertStringContainsString('"hooksModal"', $list_source);
		$this->assertStringContainsString('hooksListUrl: String', $list_source);
		$this->assertStringContainsString('hooksSaveUrl: String', $list_source);
		$this->assertStringContainsString('hooksDeleteUrl: String', $list_source);
		$this->assertStringContainsString('hooksDeliveriesUrl: String', $list_source);
		$this->assertStringContainsString('openHooks(event)', $list_source);
		$this->assertStringContainsString('this.hooksPanel?.open(event)', $list_source);
		$this->assertStringContainsString('normalizeEditorPanel(panel)', $list_source);
		$this->assertStringContainsString('["input", "hooks"].includes(value)', $list_source);

		$this->assertStringContainsString('"hooksButton"', $builder_source);
		$this->assertStringContainsString('"hookSecretInput"', $builder_source);
		$this->assertStringContainsString('"hookMetadataAddButton"', $builder_source);
		$this->assertStringContainsString('"hookExcludedFields"', $builder_source);
		$this->assertStringContainsString('hooksListUrl: String', $builder_source);
		$this->assertStringContainsString('hooksDeliveriesUrl: String', $builder_source);
		$this->assertStringContainsString('showHooksModal(event)', $builder_source);
		$this->assertStringContainsString('this.hooksPanel?.open(event)', $builder_source);
		$this->assertStringContainsString('openInitialOverlay()', $builder_source);
		$this->assertStringContainsString('captureHookFields()', $builder_source);

		$this->assertStringContainsString('export function createFormHooksPanel(host, options = {})', $panel_source);
		$this->assertStringContainsString('url.searchParams.set("definition_slug", definitionSlug)', $panel_source);
		$this->assertStringContainsString('form.builder.hooks.loading', $panel_source);
		$this->assertStringContainsString('form.builder.hooks.preset.custom', $panel_source);
		$this->assertStringContainsString('form.builder.hooks.confirm_delete', $panel_source);
		$this->assertStringContainsString('form.builder.hooks.secret_configured', $panel_source);
		$this->assertStringContainsString('target_kind', $panel_source);
		$this->assertStringContainsString('formData.set("metadata_json", JSON.stringify(nextHook.metadata))', $panel_source);
		$this->assertStringContainsString('formData.set("excluded_field_keys_json", JSON.stringify(nextHook.excludedFieldKeys))', $panel_source);
		$this->assertStringContainsString('formData.set("enable_in_non_production", nextHook.enableInNonProduction ? "1" : "0")', $panel_source);
		$this->assertStringContainsString('metadataSchemaEntries(definition)', $panel_source);
		$this->assertStringContainsString('syncCapabilityFields(definition, hook)', $panel_source);
		$this->assertStringContainsString('supports_url: this.booleanValue(target?.supports_url, true)', $panel_source);
		$this->assertStringContainsString('isCurrentRequest(requestId, definitionSlug)', $panel_source);
		$this->assertStringContainsString('payload === null || typeof payload !== "object"', $panel_source);
		$this->assertStringContainsString('data-action="${this.controllerName}#removeHookMetadataRow"', $panel_source);
		$this->assertStringContainsString('escapeAttr(value)', $panel_source);
		$this->assertStringContainsString('"\\"": "&quot;"', $panel_source);
		$this->assertStringContainsString('"\'": "&#039;"', $panel_source);
		$this->assertStringNotContainsString('target_url', $panel_source);
		$this->assertStringNotContainsString('enabled_non_production', $panel_source);
		$this->assertStringNotContainsString('excluded_fields_json', $panel_source);
		$this->assertStringNotContainsString('available_field_keys', $panel_source);
	}

	public function testFormBuilderControllerKeepsReviewGuards(): void
	{
		$root = dirname(__DIR__);
		$source = (string) file_get_contents($root . '/public/assets/themes/so-admin/controllers/form-builder-controller.js');

		$this->assertStringContainsString('pushUndo(this.undoScopeForEvent("form", event))', $source);
		$this->assertStringContainsString('pushUndo(this.undoScopeForEvent(`field:${this.selectedIndex}`, event))', $source);
		$this->assertStringContainsString('scheduleUndoScopeReset(scopeKey)', $source);
		$this->assertStringContainsString('const shouldOverwrite = overwrite === true', $source);
		$this->assertStringContainsString('uniqueIdentifier(base)', $source);
		$this->assertStringContainsString('hasFieldIdentifierConflict(identifier, selectedIndex)', $source);
		$this->assertStringContainsString('toggleI18nMode(event)', $source);
		$this->assertStringContainsString('displayKeyedI18nMode()', $source);
		$this->assertStringContainsString('|| this.hasFormDefinitionI18nReference(this.descriptor)', $source);
		$this->assertStringContainsString('collectI18nReferenceKeys(value, keys)', $source);
		$this->assertStringContainsString('syncFormTranslationLinks()', $source);
		$this->assertStringContainsString('translationUrlForTextDefinition(value)', $source);
		$this->assertStringContainsString('translationUrlForOptions(field)', $source);
		$this->assertStringContainsString('form_def.${this.formI18nSlug()}', $source);
		$this->assertStringContainsString('hideConflictActions()', $source);
		$this->assertStringContainsString('showConflictActions()', $source);
		$this->assertStringContainsString('if (this.hasConflictActionsTarget)', $source);
		$this->assertStringContainsString('dirty: this.dirty', $source);
		$this->assertStringContainsString('const value = String(option)', $source);
		$this->assertStringContainsString('String(option.value || this.identifier(this.textValue(option.label)) || "")', $source);
		$this->assertStringContainsString('parseOptions(value, field)', $source);
		$this->assertStringContainsString('const fieldSegment = field ? this.fieldI18nSegment(field) : ""', $source);
		$this->assertStringContainsString(': { text: (labelParts.join("=").trim() || rawValue.trim()) }', $source);
		$this->assertStringContainsString('field.validators = field.validators.map((validator) => {', $source);
		$this->assertStringContainsString('message: { text: this.textValue(validator.message) },', $source);
		$this->assertStringContainsString('displayTextValue(value)', $source);
		$this->assertStringContainsString('this.readOnly && value && typeof value === "object"', $source);
		$this->assertStringContainsString('const title = this.displayTextValue(this.descriptor.title)', $source);
		$this->assertStringContainsString('this.formTitleInputTarget.value = this.displayTextValue(this.descriptor.title)', $source);
		$this->assertLessThan(
			strpos($source, 'Object.prototype.hasOwnProperty.call(this.strings, value.key)'),
			strpos($source, 'if ("text" in value)'),
		);
		$this->assertStringContainsString('this.i18nWorkbenchUrl = String(this.state.i18n_workbench_url || "")', $source);
		$this->assertStringContainsString('if (this.i18nWorkbenchUrl === "")', $source);
		$this->assertStringContainsString('this.loadingDraftVersion = false', $source);
		$this->assertStringContainsString('if (this.readOnly || this.definitionSlug === "" || this.saving || this.loadingDraftVersion)', $source);
		$this->assertStringContainsString('const disabled = this.readOnly || this.saving || this.loadingDraftVersion', $source);
		$this->assertStringContainsString('this.loadingDraftVersion = true', $source);
		$this->assertStringContainsString('this.loadingDraftVersion = false', $source);
		$this->assertStringContainsString('const label = String(this.s("form.builder.panel.drafts"))', $source);
		$this->assertStringContainsString('const count = Array.isArray(this.versions) ? this.versions.length : 0', $source);
		$this->assertStringContainsString('replace(/^[._]+|[._]+$/g, "")', $source);
		$this->assertStringContainsString('Object.prototype.hasOwnProperty.call(this.strings, value.key)', $source);
		$this->assertStringContainsString('this.hasPublishedVersion = Boolean(this.publishedVersion)', $source);
		$this->assertStringContainsString('Object.prototype.hasOwnProperty.call(state, "published_version")', $source);
		$this->assertStringContainsString('this.hasPublishedVersion = this.hasPublishedVersion || Boolean(this.publishedVersion)', $source);
		$this->assertStringContainsString('if (this.hasPublishedVersion && oldKey !== "" && nextKey !== oldKey', $source);
		$this->assertStringContainsString('this.hasPublishedVersion = true', $source);
		$this->assertStringContainsString('const responseText = await response.text()', $source);
		$this->assertStringContainsString('JSON.parse(responseText)', $source);
		$this->assertStringNotContainsString('response.json().catch(() => ({}))', $source);
		$this->assertStringContainsString('async loadDraftVersion(event)', $source);
		$this->assertStringContainsString('async updateDraftNote(event)', $source);
		$this->assertStringNotContainsString('/admin/i18n/', $source);
		$this->assertStringNotContainsString("dropRoot.classList.add(\"radaptor-form-builder-drop-active\")\n\n            return", $source);
	}
}
