<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$values = is_array($this->props['values'] ?? null) ? $this->props['values'] : [];
$isSafeLinkGroupUrl = static function (string $url): bool {
	$url = trim($url);

	if ($url === '' || preg_match('/[\x00-\x1F\x7F]/', $url) === 1) {
		return false;
	}

	if (preg_match('/^([a-z][a-z0-9+.-]*):/i', $url, $matches) !== 1) {
		return true;
	}

	return in_array(strtolower($matches[1]), ['http', 'https'], true);
};
?>
<span class="label"<?= (string)($this->props['label_style_attr'] ?? '') ?>><?= e((string)($this->props['label'] ?? '')) ?></span>
<?= $this->fetchContent('helper') ?>
<div class="form-link-group">
	<?php foreach ($values as $value): ?>
		<?php
		$url = (string)($value['url'] ?? '');
		$label = (string)($value['label'] ?? $url);
		$active = (bool)($value['active'] ?? false);
		$is_safe_url = $isSafeLinkGroupUrl($url);
		?>
		<?php if ($active): ?>
			<span class="form-link-group-item active" aria-current="true"><?= e($label) ?></span>
		<?php elseif (!$is_safe_url): ?>
			<span class="form-link-group-item"><?= e($label) ?></span>
		<?php else: ?>
			<a class="form-link-group-item" href="<?= e(trim($url)) ?>"><?= e($label) ?></a>
		<?php endif; ?>
	<?php endforeach; ?>
</div>
