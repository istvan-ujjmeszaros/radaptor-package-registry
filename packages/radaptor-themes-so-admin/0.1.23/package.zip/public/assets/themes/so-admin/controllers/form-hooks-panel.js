export function createFormHooksPanel(host, options = {}) {
    return new FormHooksPanel(host, options)
}

class FormHooksPanel {
    constructor(host, options = {}) {
        this.host = host
        this.controllerName = String(options.controllerName || "form-builder")
        this.getDefinitionSlug = typeof options.getDefinitionSlug === "function" ? options.getDefinitionSlug : () => ""
        this.setDefinitionSlug = typeof options.setDefinitionSlug === "function" ? options.setDefinitionSlug : null
        this.slugFromEvent = typeof options.slugFromEvent === "function" ? options.slugFromEvent : null
        this.getInitialFields = typeof options.getInitialFields === "function" ? options.getInitialFields : () => []
        this.displayText = typeof options.displayText === "function" ? options.displayText : (value) => this.defaultDisplayText(value)
        this.requireDefinitionSlug = options.requireDefinitionSlug === true
        this.hooks = []
        this.hookTargets = []
        this.hookPresets = []
        this.hookFields = []
        this.activeHookId = ""
        this.requestId = 0
        this.opener = null
    }

    disconnect() {
        this.requestId += 1
    }

    open(event) {
        event?.preventDefault()

        if (!this.host.hasHooksModalTarget) {
            return
        }

        const definitionSlug = this.resolveDefinitionSlug(event)

        if (definitionSlug === "" && this.requireDefinitionSlug) {
            return
        }

        if (this.setDefinitionSlug) {
            this.setDefinitionSlug(definitionSlug)
        }

        this.requestId += 1
        this.opener = event?.currentTarget || null
        const requestId = this.requestId
        this.activeHookId = ""
        this.hooks = []
        this.hookTargets = []
        this.hookFields = this.normalizeHookFields(this.getInitialFields())
        this.hookPresets = this.defaultHookPresets()
        this.updateTitle()
        this.renderPresets()
        this.renderOverlay()
        this.setStatus(this.s("form.builder.hooks.loading"))
        this.host.hooksModalTarget.hidden = false
        this.host.hooksModalTarget.querySelector("button,select,input")?.focus()
        this.load(requestId, definitionSlug)
    }

    close(event) {
        event?.preventDefault()

        if (!this.host.hasHooksModalTarget || this.host.hooksModalTarget.hidden) {
            return
        }

        this.host.hooksModalTarget.hidden = true
        this.requestId += 1
        this.closeFocusElement()?.focus?.()
    }

    closeOnBackdrop(event) {
        if (event.target === this.host.hooksModalTarget) {
            this.close(event)
        }
    }

    async load(requestId = this.requestId, definitionSlug = this.currentDefinitionSlug()) {
        if (definitionSlug === "" || !this.host.hasHooksListUrlValue || this.host.hooksListUrlValue === "") {
            this.setStatus(this.s("form.builder.hooks.unavailable"))
            return
        }

        try {
            const url = new URL(this.host.hooksListUrlValue, window.location.origin)
            url.searchParams.set("definition_slug", definitionSlug)
            const payload = await this.fetchJson(url.toString(), {
                method: "GET",
                headers: { Accept: "application/json" },
            })

            if (!this.isCurrentRequest(requestId, definitionSlug)) {
                return
            }

            this.applyPayload(payload)
            await this.loadDeliveries(requestId, definitionSlug)
            if (!this.isCurrentRequest(requestId, definitionSlug)) {
                return
            }
            this.setStatus(this.s("form.builder.hooks.status.loaded"))
        } catch (error) {
            if (!this.isCurrentRequest(requestId, definitionSlug)) {
                return
            }

            this.setStatus(this.errorMessage(error, "form.builder.hooks.error_load"))
            this.renderOverlay()
        }
    }

    async loadDeliveries(requestId = this.requestId, definitionSlug = this.currentDefinitionSlug()) {
        if (!this.host.hasHooksDeliveriesUrlValue || this.host.hooksDeliveriesUrlValue === "") {
            return
        }

        try {
            const url = new URL(this.host.hooksDeliveriesUrlValue, window.location.origin)
            url.searchParams.set("definition_slug", definitionSlug)
            url.searchParams.set("limit", "25")
            const payload = await this.fetchJson(url.toString(), {
                method: "GET",
                headers: { Accept: "application/json" },
            })
            if (!this.isCurrentRequest(requestId, definitionSlug)) {
                return
            }
            this.attachDeliveries(payload?.data?.deliveries || payload?.deliveries || [])
        } catch (_error) {
            if (!this.isCurrentRequest(requestId, definitionSlug)) {
                return
            }

            this.attachDeliveries([])
        }
    }

    isCurrentRequest(requestId, definitionSlug) {
        return requestId === this.requestId
            && definitionSlug === this.currentDefinitionSlug()
            && this.host.hasHooksModalTarget
            && !this.host.hooksModalTarget.hidden
    }

    create(event) {
        event?.preventDefault()
        const preset = this.selectedPreset()
        const hook = this.normalizeHook({
            _client_id: `new_${Date.now()}_${this.hooks.length}`,
            target_kind: preset.target_kind || preset.id,
            url: preset.url || "",
            preset_key: preset.preset_key || "",
            enabled: true,
            enable_in_non_production: false,
            metadata: preset.metadata || {},
            excluded_field_keys: preset.excluded_field_keys || [],
            recent_logs: [],
        }, this.hooks.length)

        this.hooks.unshift(hook)
        this.activeHookId = this.hookDomId(hook)
        this.renderOverlay()
        this.firstVisibleInput()?.focus()
    }

    select(event) {
        event?.preventDefault()
        this.activeHookId = String(event?.currentTarget?.dataset?.hookId || "")
        this.renderOverlay()
    }

    addMetadataRow(event) {
        event?.preventDefault()

        if (!this.host.hasHookMetadataRowsTarget) {
            return
        }

        this.host.hookMetadataRowsTarget.insertAdjacentHTML("beforeend", this.metadataRowHtml("", ""))
        this.host.hookMetadataRowsTarget.querySelector(".form-builder__hook-metadata-row:last-child input")?.focus()
    }

    removeMetadataRow(event) {
        event?.preventDefault()
        event?.currentTarget?.closest?.(".form-builder__hook-metadata-row")?.remove()
    }

    async save(event) {
        event?.preventDefault()
        const hook = this.currentHook()

        if (!hook) {
            return
        }

        if (!this.host.hasHooksSaveUrlValue || this.host.hooksSaveUrlValue === "") {
            this.setStatus(this.s("form.builder.hooks.unavailable"))
            return
        }

        const definition = this.targetDefinition(hook)
        const supportsUrl = this.supports(definition, "url", true)
        const supportsSecret = this.supports(definition, "secret", false)
        const submittedHookDomId = this.hookDomId(hook)
        const nextHook = {
            ...hook,
            url: supportsUrl && this.host.hasHookTargetUrlInputTarget ? this.host.hookTargetUrlInputTarget.value : "",
            secret: supportsSecret && this.host.hasHookSecretInputTarget ? this.host.hookSecretInputTarget.value : "",
            enabled: this.host.hasHookEnabledInputTarget ? this.host.hookEnabledInputTarget.checked : true,
            enableInNonProduction: this.host.hasHookNonProductionInputTarget ? this.host.hookNonProductionInputTarget.checked : false,
            metadata: this.collectMetadata(definition),
            excludedFieldKeys: this.collectExcludedFields(),
        }
        Object.assign(hook, nextHook)

        const requestId = this.requestId
        const definitionSlug = this.currentDefinitionSlug()
        const formData = new FormData()
        formData.set("definition_slug", definitionSlug)
        formData.set("hook_id", hook.id || "")
        formData.set("target_kind", nextHook.target_kind || "")
        formData.set("url", nextHook.url)
        if (supportsSecret && nextHook.secret !== "") {
            formData.set("secret", nextHook.secret)
        }
        formData.set("preset_key", nextHook.preset_key || "")
        formData.set("enabled", nextHook.enabled ? "1" : "0")
        formData.set("enable_in_non_production", nextHook.enableInNonProduction ? "1" : "0")
        formData.set("metadata_json", JSON.stringify(nextHook.metadata))
        formData.set("excluded_field_keys_json", JSON.stringify(nextHook.excludedFieldKeys))
        formData.set("csrf_token", this.host.csrfTokenValue)

        try {
            const payload = await this.postForm(this.host.hooksSaveUrlValue, formData)
            if (!this.isCurrentRequest(requestId, definitionSlug)) {
                return
            }

            this.mergeResponse(payload, submittedHookDomId)
            this.setStatus(this.s("form.builder.hooks.status.saved"))
        } catch (error) {
            if (!this.isCurrentRequest(requestId, definitionSlug)) {
                return
            }

            this.setStatus(this.errorMessage(error, "form.builder.hooks.error_save"))
        }
    }

    async delete(event) {
        event?.preventDefault()
        const hook = this.currentHook()

        if (!hook || !window.confirm(this.s("form.builder.hooks.confirm_delete"))) {
            return
        }

        const submittedHookDomId = this.hookDomId(hook)

        if (hook.id === "") {
            this.removeByDomId(submittedHookDomId)
            this.setStatus(this.s("form.builder.hooks.status.deleted"))
            return
        }

        if (!this.host.hasHooksDeleteUrlValue || this.host.hooksDeleteUrlValue === "") {
            this.setStatus(this.s("form.builder.hooks.unavailable"))
            return
        }

        const requestId = this.requestId
        const definitionSlug = this.currentDefinitionSlug()
        const formData = new FormData()
        formData.set("definition_slug", definitionSlug)
        formData.set("hook_id", hook.id)
        formData.set("csrf_token", this.host.csrfTokenValue)

        try {
            const payload = await this.postForm(this.host.hooksDeleteUrlValue, formData)
            if (!this.isCurrentRequest(requestId, definitionSlug)) {
                return
            }

            if (Array.isArray(payload?.data?.hooks)) {
                this.applyPayload(payload)
            } else {
                this.removeByDomId(submittedHookDomId)
            }

            this.setStatus(this.s("form.builder.hooks.status.deleted"))
        } catch (error) {
            if (!this.isCurrentRequest(requestId, definitionSlug)) {
                return
            }

            this.setStatus(this.errorMessage(error, "form.builder.hooks.error_delete"))
        }
    }

    applyPayload(payload) {
        const data = payload?.data && typeof payload.data === "object" ? payload.data : payload
        this.hooks = Array.isArray(data?.hooks) ? data.hooks.map((hook, index) => this.normalizeHook(hook, index)) : []
        this.hookTargets = this.normalizeTargets(data?.targets)
        this.hookPresets = this.normalizePresets(data?.presets)
        this.hookFields = this.normalizeHookFields(data?.fields)
        if (this.hookFields.length === 0) {
            this.hookFields = this.normalizeHookFields(this.getInitialFields())
        }
        this.attachDeliveries(data?.deliveries || [])
        this.activeHookId = this.hooks.length > 0 ? this.hookDomId(this.hooks[0]) : ""
        this.renderPresets()
        this.renderOverlay()
    }

    attachDeliveries(deliveries) {
        const rows = Array.isArray(deliveries) ? deliveries : []

        this.hooks.forEach((hook) => {
            const hookId = Number(hook.id || 0)
            hook.recent_logs = rows.filter((row) => hookId > 0 && Number(row?.hook_id || 0) === hookId)
        })

        this.renderOverlay()
    }

    mergeResponse(payload, submittedHookDomId = this.activeHookId) {
        if (Array.isArray(payload?.data?.hooks)) {
            this.applyPayload(payload)
            return
        }

        const savedHook = payload?.data?.hook

        if (savedHook && typeof savedHook === "object") {
            const normalized = this.normalizeHook(savedHook, this.hooks.length)
            const targetId = String(submittedHookDomId || this.activeHookId)
            const wasActive = this.activeHookId === targetId
            const index = this.hooks.findIndex((hook) => this.hookDomId(hook) === targetId)

            if (index >= 0) {
                this.hooks.splice(index, 1, normalized)
            } else {
                this.hooks.unshift(normalized)
            }

            if (wasActive || this.activeHookId === "") {
                this.activeHookId = this.hookDomId(normalized)
            }
        }

        this.renderOverlay()
    }

    removeByDomId(hookDomId) {
        const targetId = String(hookDomId || "")
        const activeId = this.activeHookId
        this.hooks = this.hooks.filter((hook) => this.hookDomId(hook) !== targetId)
        const activeStillExists = this.hooks.some((hook) => this.hookDomId(hook) === activeId)
        this.activeHookId = targetId !== activeId && activeStillExists
            ? activeId
            : (this.hooks.length > 0 ? this.hookDomId(this.hooks[0]) : "")
        this.renderOverlay()
    }

    renderOverlay() {
        this.updateTitle()
        this.renderList()
        this.renderEditor()
    }

    updateTitle() {
        if (this.host.hasHooksTitleSlugTarget) {
            const slug = this.currentDefinitionSlug()
            this.host.hooksTitleSlugTarget.textContent = slug === "" ? "" : ` / ${slug}`
        }
    }

    renderPresets() {
        if (!this.host.hasHooksPresetSelectTarget) {
            return
        }

        const presets = this.hookPresets.length > 0 ? this.hookPresets : this.defaultHookPresets()
        this.host.hooksPresetSelectTarget.innerHTML = presets.map((preset) => {
            return `<option value="${this.escapeAttr(preset.id)}">${this.escapeHtml(preset.label)}</option>`
        }).join("")
    }

    renderList() {
        if (!this.host.hasHooksListTarget) {
            return
        }

        if (this.hooks.length === 0) {
            this.host.hooksListTarget.innerHTML = `<div class="form-builder__empty-properties">${this.escapeHtml(this.s("form.builder.hooks.empty"))}</div>`
            return
        }

        this.host.hooksListTarget.innerHTML = this.hooks.map((hook) => {
            const hookId = this.hookDomId(hook)
            const active = hookId === this.activeHookId
            const preset = this.presetLabel(hook.target_kind)
            const metadataTarget = this.metadataTargetLabel(hook.metadata)
            const target = hook.label || hook.url || metadataTarget || preset || this.s("form.builder.hooks.target")
            const enabled = hook.enabled ? `<span class="badge text-bg-success bg-opacity-75">${this.escapeHtml(this.s("form.builder.hooks.enabled"))}</span>` : ""

            return `<button type="button" class="form-builder__hook-target${active ? " is-active" : ""}" data-hook-id="${this.escapeAttr(hookId)}" data-action="${this.controllerName}#selectHook" aria-pressed="${active ? "true" : "false"}">`
                + `<span>${this.escapeHtml(target)}</span>`
                + `<small>${this.escapeHtml(preset)}</small>`
                + enabled
                + `</button>`
        }).join("")
    }

    renderEditor() {
        if (!this.host.hasHooksEditorTarget) {
            return
        }

        const hook = this.currentHook()
        this.host.hooksEditorTarget.hidden = !hook

        if (!hook) {
            return
        }

        const definition = this.targetDefinition(hook)
        this.syncCapabilityFields(definition, hook)
        if (this.host.hasHookTargetUrlInputTarget) {
            this.host.hookTargetUrlInputTarget.value = hook.url || ""
        }
        if (this.host.hasHookSecretInputTarget) {
            this.host.hookSecretInputTarget.value = ""
            this.host.hookSecretInputTarget.placeholder = hook.has_secret
                ? this.s("form.builder.hooks.secret_configured")
                : this.s("form.builder.hooks.secret_placeholder")
        }
        if (this.host.hasHookEnabledInputTarget) {
            this.host.hookEnabledInputTarget.checked = Boolean(hook.enabled)
        }
        if (this.host.hasHookNonProductionInputTarget) {
            this.host.hookNonProductionInputTarget.checked = Boolean(hook.enableInNonProduction)
        }
        this.renderMetadata(hook, definition)
        this.renderExcludedFields(hook.excludedFieldKeys)
        this.renderLogs(hook.recent_logs)
    }

    renderExcludedFields(excludedFields) {
        if (!this.host.hasHookExcludedFieldsTarget) {
            return
        }

        if (this.hookFields.length === 0) {
            this.host.hookExcludedFieldsTarget.innerHTML = `<div class="form-builder__empty-properties">${this.escapeHtml(this.s("form.builder.hooks.no_fields"))}</div>`
            return
        }

        const excluded = new Set(this.stringArray(excludedFields))
        this.host.hookExcludedFieldsTarget.innerHTML = this.hookFields.map((field) => {
            const checked = excluded.has(field.key) ? " checked" : ""

            return `<label class="form-check form-builder__hook-check">`
                + `<input type="checkbox" class="form-check-input" data-hook-excluded-field value="${this.escapeAttr(field.key)}"${checked}>`
                + `<span>${this.escapeHtml(field.label || field.key)}</span>`
                + `<code>${this.escapeHtml(field.key)}</code>`
                + `</label>`
        }).join("")
    }

    renderLogs(logs) {
        if (!this.host.hasHookLogsBodyTarget) {
            return
        }

        const rows = Array.isArray(logs) ? logs : []

        if (rows.length === 0) {
            this.host.hookLogsBodyTarget.innerHTML = `<tr><td colspan="4" class="text-body-secondary">${this.escapeHtml(this.s("form.builder.hooks.no_logs"))}</td></tr>`
            return
        }

        this.host.hookLogsBodyTarget.innerHTML = rows.map((log) => {
            const result = log?.result && typeof log.result === "object" ? log.result : {}
            const time = this.formatDate(log?.completed_at || log?.queued_at || log?.created_at || log?.time || "")
            const status = String(log?.status || "")
            const httpStatus = String(log?.http_status || log?.status_code || result.http_status || result.status || "")
            const message = String(log?.message || log?.error || log?.error_message || result.message || result.body_preview || "")

            return `<tr>`
                + `<td>${this.escapeHtml(time)}</td>`
                + `<td>${this.escapeHtml(status)}</td>`
                + `<td>${this.escapeHtml(httpStatus)}</td>`
                + `<td>${this.escapeHtml(message)}</td>`
            + `</tr>`
        }).join("")
    }

    renderMetadata(hook, definition) {
        if (!this.host.hasHookMetadataRowsTarget) {
            return
        }

        const schemaEntries = this.metadataSchemaEntries(definition)

        if (this.host.hasHookMetadataAddButtonTarget) {
            this.host.hookMetadataAddButtonTarget.hidden = schemaEntries.length > 0
        }

        if (schemaEntries.length > 0) {
            this.host.hookMetadataRowsTarget.innerHTML = schemaEntries
                .map(([key, schema]) => this.metadataSchemaFieldHtml(key, schema, hook.metadata?.[key] ?? ""))
                .join("")
            return
        }

        this.host.hookMetadataRowsTarget.innerHTML = this.metadataRows(hook.metadata)
            .map((row) => this.metadataRowHtml(row.key, row.value))
            .join("")
    }

    metadataSchemaFieldHtml(key, schema, value) {
        const type = String(schema?.type || "string")
        const required = this.booleanValue(schema?.required, false)
        const label = this.s(`form.builder.hooks.metadata.${key}`)
        const requiredAttr = required ? " required" : ""
        const keyAttr = this.escapeAttr(key)
        const valueString = String(value ?? "")

        if (type === "boolean") {
            const checked = this.booleanValue(value, false) ? " checked" : ""

            return `<label class="form-check form-builder__hook-metadata-field form-builder__hook-metadata-field--check">`
                + `<input type="checkbox" class="form-check-input" data-hook-metadata-schema-key="${keyAttr}" data-hook-metadata-type="boolean"${checked}>`
                + `<span>${this.escapeHtml(label)}</span>`
                + `</label>`
        }

        if (type === "field_key") {
            const options = [`<option value="">${this.escapeHtml(this.s("form.builder.hooks.metadata.no_field"))}</option>`]
                .concat(this.hookFields.map((field) => {
                    const selected = field.key === valueString ? " selected" : ""

                    return `<option value="${this.escapeAttr(field.key)}"${selected}>${this.escapeHtml(field.label || field.key)}</option>`
                }))
                .join("")

            return `<label class="form-label form-builder__hook-metadata-field">`
                + `<span>${this.escapeHtml(label)}</span>`
                + `<select class="form-select form-select-sm" data-hook-metadata-schema-key="${keyAttr}" data-hook-metadata-type="field_key"${requiredAttr}>${options}</select>`
                + `</label>`
        }

        const inputType = type === "email" ? "email" : "text"

        return `<label class="form-label form-builder__hook-metadata-field">`
            + `<span>${this.escapeHtml(label)}</span>`
            + `<input type="${inputType}" class="form-control form-control-sm" data-hook-metadata-schema-key="${keyAttr}" data-hook-metadata-type="${this.escapeAttr(type)}" value="${this.escapeAttr(valueString)}"${requiredAttr}>`
            + `</label>`
    }

    metadataRowHtml(key, value) {
        return `<div class="form-builder__hook-metadata-row">`
            + `<input type="text" class="form-control form-control-sm" data-hook-metadata-key placeholder="${this.escapeAttr(this.s("form.builder.hooks.metadata_key"))}" value="${this.escapeAttr(key)}">`
            + `<input type="text" class="form-control form-control-sm" data-hook-metadata-value placeholder="${this.escapeAttr(this.s("form.builder.hooks.metadata_value"))}" value="${this.escapeAttr(value)}">`
            + `<button type="button" class="btn btn-outline-secondary btn-sm" data-action="${this.controllerName}#removeHookMetadataRow" aria-label="${this.escapeAttr(this.s("form.builder.hooks.remove_metadata"))}"><i class="bi bi-x-lg" aria-hidden="true"></i></button>`
            + `</div>`
    }

    collectMetadata(definition = null) {
        const metadata = {}

        if (!this.host.hasHookMetadataRowsTarget) {
            return metadata
        }

        const schemaEntries = definition ? this.metadataSchemaEntries(definition) : []

        if (schemaEntries.length > 0) {
            this.host.hookMetadataRowsTarget.querySelectorAll("[data-hook-metadata-schema-key]").forEach((input) => {
                const key = String(input.dataset.hookMetadataSchemaKey || "").trim()

                if (key === "") {
                    return
                }

                if (input.dataset.hookMetadataType === "boolean") {
                    metadata[key] = Boolean(input.checked)
                    return
                }

                const value = String(input.value || "").trim()

                if (value !== "") {
                    metadata[key] = value
                }
            })

            return metadata
        }

        this.host.hookMetadataRowsTarget.querySelectorAll(".form-builder__hook-metadata-row").forEach((row) => {
            const key = String(row.querySelector("[data-hook-metadata-key]")?.value || "").trim()
            const value = String(row.querySelector("[data-hook-metadata-value]")?.value || "")

            if (key !== "") {
                metadata[key] = value
            }
        })

        return metadata
    }

    collectExcludedFields() {
        if (!this.host.hasHookExcludedFieldsTarget) {
            return []
        }

        return Array.from(this.host.hookExcludedFieldsTarget.querySelectorAll("[data-hook-excluded-field]:checked"))
            .map((input) => String(input.value || ""))
            .filter(Boolean)
    }

    currentHook() {
        return this.hooks.find((hook) => this.hookDomId(hook) === this.activeHookId) || null
    }

    hookDomId(hook) {
        return hook.id !== "" ? `id:${hook.id}` : `client:${hook._clientId}`
    }

    normalizeHook(hook, index) {
        const targetKind = this.normalizeKind(hook?.target_kind || "custom_https_webhook")

        return {
            id: String(hook?.hook_id || ""),
            _clientId: String(hook?._client_id || `loaded_${index}`),
            label: String(hook?.label || ""),
            target_kind: targetKind,
            url: String(hook?.url || ""),
            preset_key: String(hook?.preset_key || ""),
            enabled: this.booleanValue(hook?.enabled, true),
            enableInNonProduction: this.booleanValue(hook?.enable_in_non_production, false),
            has_secret: this.booleanValue(hook?.has_secret, false),
            metadata: this.metadataObject(hook?.metadata),
            excludedFieldKeys: this.stringArray(hook?.excluded_field_keys),
            recent_logs: Array.isArray(hook?.recent_logs) ? hook.recent_logs : [],
        }
    }

    normalizeTargets(targets) {
        if (!Array.isArray(targets)) {
            return []
        }

        return targets.map((target) => ({
            kind: this.normalizeKind(target?.kind || ""),
            label: this.displayText(target?.name || target?.label || target?.kind || ""),
            supports_url: this.booleanValue(target?.supports_url, true),
            supports_secret: this.booleanValue(target?.supports_secret, false),
            supports_preset_key: this.booleanValue(target?.supports_preset_key, false),
            metadata_schema: this.metadataSchemaObject(target?.metadata_schema),
        })).filter((target) => target.kind !== "")
    }

    normalizePresets(presets) {
        if (!Array.isArray(presets) || presets.length === 0) {
            return this.defaultHookPresets()
        }

        return presets.map((preset) => {
            const id = String(preset?.id || "custom_https_webhook")
            const targetKind = this.normalizeKind(preset?.target_kind || id)

            return {
                id,
                target_kind: targetKind,
                label: this.displayText(preset?.label || preset?.id || this.s("form.builder.hooks.preset.custom")),
                url: String(preset?.url || ""),
                preset_key: String(preset?.preset_key || ""),
                metadata: this.metadataObject(preset?.metadata),
                excluded_field_keys: this.stringArray(preset?.excluded_field_keys),
            }
        })
    }

    normalizeHookFields(fields) {
        if (!Array.isArray(fields)) {
            return []
        }

        return fields.map((field) => {
            const key = String(field?.key || field || "")
            const label = this.displayText(field?.label || field?.title || key)

            return { key, label }
        }).filter((field) => field.key !== "")
    }

    defaultHookPresets() {
        return [{
            id: "custom_https_webhook",
            target_kind: "custom_https_webhook",
            label: this.s("form.builder.hooks.preset.custom"),
            url: "",
            preset_key: "",
            metadata: {},
            excluded_field_keys: [],
        }]
    }

    selectedPreset() {
        const presetId = this.host.hasHooksPresetSelectTarget ? this.host.hooksPresetSelectTarget.value : "custom_https_webhook"

        return this.hookPresets.find((preset) => preset.id === presetId) || this.defaultHookPresets()[0]
    }

    presetLabel(presetId) {
        const normalized = this.normalizeKind(presetId)

        return (this.hookPresets.find((preset) => preset.id === presetId || preset.target_kind === normalized) || this.defaultHookPresets()[0]).label
    }

    targetDefinition(hook) {
        const kind = this.normalizeKind(hook?.target_kind || "")

        return this.hookTargets.find((target) => target.kind === kind)
            || this.defaultTarget()
    }

    defaultTarget() {
        return {
            kind: "custom_https_webhook",
            label: this.s("form.builder.hooks.preset.custom"),
            supports_url: true,
            supports_secret: true,
            supports_preset_key: false,
            metadata_schema: {},
        }
    }

    supports(definition, feature, fallback = false) {
        const key = `supports_${feature}`

        if (!definition || definition[key] === undefined || definition[key] === null || definition[key] === "") {
            return fallback
        }

        return this.booleanValue(definition[key], fallback)
    }

    syncCapabilityFields(definition, hook) {
        const supportsUrl = this.supports(definition, "url", true)
        const supportsSecret = this.supports(definition, "secret", false)

        if (this.host.hasHookTargetUrlGroupTarget) {
            this.host.hookTargetUrlGroupTarget.hidden = !supportsUrl
        }

        if (this.host.hasHookTargetUrlInputTarget) {
            this.host.hookTargetUrlInputTarget.disabled = !supportsUrl
        }

        if (this.host.hasHookSecretGroupTarget) {
            this.host.hookSecretGroupTarget.hidden = !supportsSecret
        }

        if (this.host.hasHookSecretInputTarget) {
            this.host.hookSecretInputTarget.disabled = !supportsSecret
            this.host.hookSecretInputTarget.required = supportsSecret && !hook.has_secret
        }
    }

    firstVisibleInput() {
        return Array.from(this.host.hooksEditorTarget?.querySelectorAll("input,select,button") || [])
            .find((element) => !element.disabled && !element.hidden && element.offsetParent !== null)
            || null
    }

    metadataTargetLabel(metadata) {
        const data = this.metadataObject(metadata)

        return String(data.to || "")
    }

    metadataSchemaObject(schema) {
        return schema && typeof schema === "object" && !Array.isArray(schema) ? schema : {}
    }

    metadataSchemaEntries(definition) {
        return Object.entries(this.metadataSchemaObject(definition?.metadata_schema))
    }

    normalizeKind(value) {
        const kind = String(value || "").trim().toLowerCase().replace(/-/g, "_")

        if (["custom", "custom_http", "https_webhook", "webhook", "custom_https"].includes(kind)) {
            return "custom_https_webhook"
        }

        if (["email", "raw_email", "raw_form_email"].includes(kind)) {
            return "raw_form_data_email"
        }

        return kind.replace(/[^a-z0-9_]+/g, "_")
    }

    metadataObject(metadata) {
        if (metadata && typeof metadata === "object" && !Array.isArray(metadata)) {
            return Object.fromEntries(Object.entries(metadata).map(([key, value]) => [key, String(value ?? "")]))
        }

        return {}
    }

    metadataRows(metadata) {
        return Object.entries(this.metadataObject(metadata)).map(([key, value]) => ({ key, value }))
    }

    stringArray(value) {
        return Array.isArray(value) ? value.map((item) => String(item || "")).filter(Boolean) : []
    }

    booleanValue(value, fallback) {
        if (value === undefined || value === null || value === "") {
            return fallback
        }

        return value === true || value === 1 || value === "1" || value === "true"
    }

    defaultDisplayText(value) {
        if (value && typeof value === "object") {
            return String(value.text || value.label || value.key || "")
        }

        return String(value || "")
    }

    formatDate(value) {
        const raw = String(value || "").trim()

        if (raw === "") {
            return ""
        }

        const parsed = new Date(raw.replace(/\s+/, "T"))

        return Number.isNaN(parsed.getTime()) ? raw : parsed.toLocaleString()
    }

    setStatus(message) {
        if (this.host.hasHooksStatusTarget) {
            this.host.hooksStatusTarget.textContent = message
        }
    }

    async fetchJson(url, options = {}) {
        const response = await fetch(url, options)
        const responseText = await response.text()
        let payload = {}

        try {
            payload = responseText === "" ? {} : JSON.parse(responseText)
        } catch (_error) {
            throw new Error(this.s("form.builder.error_request"))
        }

        if (payload === null || typeof payload !== "object") {
            throw new Error(this.s("form.builder.error_request"))
        }

        if (!response.ok) {
            throw new Error(payload?.error?.message || this.s("form.builder.error_request"))
        }

        return payload
    }

    async postForm(url, formData) {
        const response = await fetch(url, {
            method: "POST",
            headers: { Accept: "application/json" },
            body: formData,
        })
        const responseText = await response.text()
        let payload = {}

        try {
            payload = responseText === "" ? {} : JSON.parse(responseText)
        } catch (_error) {
            throw new Error(this.s("form.builder.error_request"))
        }

        if (payload === null || typeof payload !== "object") {
            throw new Error(this.s("form.builder.error_request"))
        }

        if (!response.ok) {
            throw new Error(payload?.error?.message || this.s("form.builder.error_request"))
        }

        return payload
    }

    errorMessage(error, fallbackKey) {
        return error instanceof Error && error.message !== "" ? error.message : this.s(fallbackKey)
    }

    resolveDefinitionSlug(event) {
        if (this.slugFromEvent) {
            return String(this.slugFromEvent(event) || "")
        }

        return this.currentDefinitionSlug()
    }

    currentDefinitionSlug() {
        return String(this.getDefinitionSlug() || "")
    }

    closeFocusElement() {
        if (this.opener) {
            return this.opener
        }

        if (this.host.hasHooksButtonTarget) {
            return this.host.hooksButtonTarget
        }

        return null
    }

    escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, (char) => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            "\"": "&quot;",
            "'": "&#039;",
        }[char]))
    }

    escapeAttr(value) {
        return this.escapeHtml(value)
    }

    s(key) {
        return this.host.s(key)
    }
}
