<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class PackageSmokeTest extends TestCase
{
	public function testRegistryPackageMetadataIsValid(): void
	{
		$root = dirname(__DIR__);
		$metadata_path = $root . '/.registry-package.json';
		$this->assertFileExists($metadata_path);

		$decoded = json_decode((string) file_get_contents($metadata_path), true);
		$this->assertIsArray($decoded);
		$this->assertSame('radaptor/themes/so-admin', $decoded['package'] ?? null);
		$this->assertSame('theme', $decoded['type'] ?? null);
		$this->assertSame('so-admin', $decoded['id'] ?? null);
		$this->assertIsString($decoded['dependencies']['radaptor/core/cms'] ?? null);
		$this->assertMatchesRegularExpression('/^\^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $decoded['dependencies']['radaptor/core/cms']);
	}

	public function testThemeEntrypointsExist(): void
	{
		$root = dirname(__DIR__);

		$this->assertFileExists($root . '/theme/_layout/template.layout_admin_default.php');
		$this->assertFileExists($root . '/theme/Cms/template._admin_dropdown.php');
		$this->assertDirectoryExists($root . '/public/assets/themes/so-admin');
		$this->assertFileExists($root . '/public/assets/themes/so-admin/controllers/form-builder-controller.js');
		$this->assertFileExists($root . '/public/assets/themes/so-admin/controllers/form-list-controller.js');
		$this->assertFileExists($root . '/public/assets/themes/so-admin/css/form-builder.css');
	}

	public function testFormBuilderControllerKeepsReviewGuards(): void
	{
		$root = dirname(__DIR__);
		$source = (string) file_get_contents($root . '/public/assets/themes/so-admin/controllers/form-builder-controller.js');

		$this->assertStringContainsString('pushUndo(this.undoScopeForEvent("form", event))', $source);
		$this->assertStringContainsString('pushUndo(this.undoScopeForEvent(`field:${this.selectedIndex}`, event))', $source);
		$this->assertStringContainsString('scheduleUndoScopeReset(scopeKey)', $source);
		$this->assertStringContainsString('const shouldOverwrite = overwrite === true', $source);
		$this->assertStringContainsString('uniqueIdentifier(base)', $source);
		$this->assertStringContainsString('hasFieldIdentifierConflict(identifier, selectedIndex)', $source);
		$this->assertStringContainsString('parseOptions(value)', $source);
		$this->assertStringNotContainsString("dropRoot.classList.add(\"radaptor-form-builder-drop-active\")\n\n            return", $source);
	}
}
