import { Controller } from "/assets/packages/themes/so-admin/js/stimulus.js"
import { renderInlineLoader } from "/assets/packages/themes/so-admin/js/async-loader.js"

export default class extends Controller {
    static targets = [
        "status",
        "modal",
        "editorHost",
        "hooksModal",
        "hooksTitleSlug",
        "hooksStatus",
        "hooksPresetSelect",
        "hooksList",
        "hooksEditor",
        "hookTargetUrlGroup",
        "hookTargetUrlInput",
        "hookSecretGroup",
        "hookSecretInput",
        "hookEnabledInput",
        "hookNonProductionInput",
        "hookMetadataAddButton",
        "hookMetadataRows",
        "hookExcludedFields",
        "hookLogsBody",
        "hookDeleteButton",
        "hookSaveButton",
    ]

    static values = {
        createUrl: String,
        editorFragmentUrl: String,
        hooksListUrl: String,
        hooksSaveUrl: String,
        hooksDeleteUrl: String,
        hooksDeliveriesUrl: String,
        csrfToken: String,
        strings: Object,
    }

    connect() {
        this.modalInstance = null
        this.editorSlug = ""
        this.editorPanel = "form"
        this.editorDirty = false
        this.listNeedsRefresh = false
        this.editorRequestId = 0
        this.editorAbortController = null
        this.modalHidePrevented = false
        this.hooksDefinitionSlug = ""
        this.hooks = []
        this.hookTargets = []
        this.hookPresets = []
        this.hookFields = []
        this.activeHookId = ""
        this.hooksRequestId = 0
        this.hooksOpener = null
        this.boundModalHide = (event) => this.beforeModalHide(event)
        this.boundModalHidden = () => this.afterModalHidden()
        this.boundDirtyChange = (event) => this.onBuilderDirtyChange(event)
        this.boundBuilderChanged = (event) => this.onBuilderChanged(event)
        this.boundPanelChange = (event) => this.onBuilderPanelChange(event)
        this.boundPopState = () => this.openFromUrl({ replace: true })

        if (this.hasModalTarget) {
            this.modalTarget.addEventListener("hide.bs.modal", this.boundModalHide)
            this.modalTarget.addEventListener("hidden.bs.modal", this.boundModalHidden)
        }

        this.element.addEventListener("form-builder:dirty-change", this.boundDirtyChange)
        this.element.addEventListener("form-builder:changed", this.boundBuilderChanged)
        this.element.addEventListener("form-builder:panel-change", this.boundPanelChange)
        window.addEventListener("popstate", this.boundPopState)
        this.openFromUrl({ replace: true })
    }

    disconnect() {
        this.cancelEditorRequest()
        this.editorRequestId += 1

        if (this.hasModalTarget) {
            this.modalTarget.removeEventListener("hide.bs.modal", this.boundModalHide)
            this.modalTarget.removeEventListener("hidden.bs.modal", this.boundModalHidden)
        }

        this.element.removeEventListener("form-builder:dirty-change", this.boundDirtyChange)
        this.element.removeEventListener("form-builder:changed", this.boundBuilderChanged)
        this.element.removeEventListener("form-builder:panel-change", this.boundPanelChange)
        window.removeEventListener("popstate", this.boundPopState)
    }

    async create(event) {
        event.preventDefault()
        const form = event.currentTarget
        const formData = new FormData(form)
        formData.set("csrf_token", this.csrfTokenValue)

        try {
            const payload = await this.postForm(this.createUrlValue, formData)
            const slug = payload?.data?.definition?.definition_slug || formData.get("definition_slug")
            this.listNeedsRefresh = true
            form.reset()
            await this.openEditorSlug(String(slug), { panel: "form" })
        } catch (error) {
            this.setStatus(this.errorMessage(error, "form.builder.error_create"))
        }
    }

    openEditor(event) {
        if (!this.isPlainPrimaryClick(event)) {
            return
        }

        event.preventDefault()
        const slug = event.params.slug || event.currentTarget?.dataset?.formListSlugParam || ""
        this.openEditorSlug(String(slug), { panel: this.panelFromUrl() })
    }

    requestCloseEditor(event) {
        event.preventDefault()
        this.modal()?.hide()
    }

    openHooks(event) {
        event?.preventDefault()
        const slug = event?.params?.slug || event?.currentTarget?.dataset?.formListSlugParam || ""

        if (slug === "" || !this.hasHooksModalTarget) {
            return
        }

        this.hooksRequestId += 1
        this.hooksOpener = event?.currentTarget || null
        this.hooksDefinitionSlug = String(slug)
        const requestId = this.hooksRequestId
        const definitionSlug = this.hooksDefinitionSlug
        this.activeHookId = ""
        this.hooks = []
        this.hookFields = []
        this.hookPresets = this.defaultHookPresets()
        this.updateHooksTitle()
        this.renderHookPresets()
        this.renderHooksOverlay()
        this.setHooksStatus(this.s("form.builder.hooks.loading"))
        this.hooksModalTarget.hidden = false
        this.hooksModalTarget.querySelector("button,select,input")?.focus()
        this.loadHooks(requestId, definitionSlug)
    }

    closeHooks(event) {
        event?.preventDefault()

        if (!this.hasHooksModalTarget || this.hooksModalTarget.hidden) {
            return
        }

        this.hooksModalTarget.hidden = true
        this.hooksRequestId += 1
        this.hooksOpener?.focus?.()
    }

    closeHooksOnBackdrop(event) {
        if (event.target === this.hooksModalTarget) {
            this.closeHooks(event)
        }
    }

    async loadHooks(requestId = this.hooksRequestId, definitionSlug = this.hooksDefinitionSlug) {
        if (definitionSlug === "" || !this.hasHooksListUrlValue || this.hooksListUrlValue === "") {
            this.setHooksStatus(this.s("form.builder.hooks.unavailable"))
            return
        }

        try {
            const url = new URL(this.hooksListUrlValue, window.location.origin)
            url.searchParams.set("definition_slug", definitionSlug)
            const payload = await this.fetchJson(url.toString(), {
                method: "GET",
                headers: { Accept: "application/json" },
            })

            if (!this.isCurrentHooksRequest(requestId, definitionSlug)) {
                return
            }

            this.applyHooksPayload(payload)
            await this.loadHookDeliveries(requestId, definitionSlug)
            if (!this.isCurrentHooksRequest(requestId, definitionSlug)) {
                return
            }
            this.setHooksStatus(this.s("form.builder.hooks.status.loaded"))
        } catch (error) {
            if (!this.isCurrentHooksRequest(requestId, definitionSlug)) {
                return
            }

            this.setHooksStatus(this.errorMessage(error, "form.builder.hooks.error_load"))
            this.renderHooksOverlay()
        }
    }

    async loadHookDeliveries(requestId = this.hooksRequestId, definitionSlug = this.hooksDefinitionSlug) {
        if (!this.hasHooksDeliveriesUrlValue || this.hooksDeliveriesUrlValue === "") {
            return
        }

        try {
            const url = new URL(this.hooksDeliveriesUrlValue, window.location.origin)
            url.searchParams.set("definition_slug", definitionSlug)
            url.searchParams.set("limit", "25")
            const payload = await this.fetchJson(url.toString(), {
                method: "GET",
                headers: { Accept: "application/json" },
            })
            if (!this.isCurrentHooksRequest(requestId, definitionSlug)) {
                return
            }
            this.attachHookDeliveries(payload?.data?.deliveries || payload?.deliveries || [])
        } catch (_error) {
            if (!this.isCurrentHooksRequest(requestId, definitionSlug)) {
                return
            }

            this.attachHookDeliveries([])
        }
    }

    isCurrentHooksRequest(requestId, definitionSlug) {
        return requestId === this.hooksRequestId
            && definitionSlug === this.hooksDefinitionSlug
            && this.hasHooksModalTarget
            && !this.hooksModalTarget.hidden
    }

    createHook(event) {
        event?.preventDefault()
        const preset = this.selectedHookPreset()
        const hook = this.normalizeHook({
            _client_id: `new_${Date.now()}_${this.hooks.length}`,
            target_kind: preset.target_kind || preset.id,
            target_url: preset.target_url || "",
            preset: preset.id,
            preset_key: preset.preset_key || "",
            enabled: true,
            enabled_non_production: false,
            metadata: preset.metadata || {},
            excluded_fields: preset.excluded_fields || [],
            recent_logs: [],
        }, this.hooks.length)

        this.hooks.unshift(hook)
        this.activeHookId = this.hookDomId(hook)
        this.renderHooksOverlay()
        this.firstVisibleHookInput()?.focus()
    }

    selectHook(event) {
        event?.preventDefault()
        this.activeHookId = String(event?.currentTarget?.dataset?.hookId || "")
        this.renderHooksOverlay()
    }

    addHookMetadataRow(event) {
        event?.preventDefault()

        if (!this.hasHookMetadataRowsTarget) {
            return
        }

        this.hookMetadataRowsTarget.insertAdjacentHTML("beforeend", this.hookMetadataRowHtml("", ""))
        this.hookMetadataRowsTarget.querySelector(".form-builder__hook-metadata-row:last-child input")?.focus()
    }

    removeHookMetadataRow(event) {
        event?.preventDefault()
        event?.currentTarget?.closest?.(".form-builder__hook-metadata-row")?.remove()
    }

    async saveHook(event) {
        event?.preventDefault()
        const hook = this.currentHook()

        if (!hook) {
            return
        }

        if (!this.hasHooksSaveUrlValue || this.hooksSaveUrlValue === "") {
            this.setHooksStatus(this.s("form.builder.hooks.unavailable"))
            return
        }

        const definition = this.hookTargetDefinition(hook)
        const supportsUrl = this.hookSupports(definition, "url", true)
        const supportsSecret = this.hookSupports(definition, "secret", false)
        const submittedHookDomId = this.hookDomId(hook)
        const nextHook = {
            ...hook,
            target_url: supportsUrl ? this.hookTargetUrlInputTarget.value : "",
            secret: supportsSecret && this.hasHookSecretInputTarget ? this.hookSecretInputTarget.value : "",
            enabled: this.hookEnabledInputTarget.checked,
            enabled_non_production: this.hookNonProductionInputTarget.checked,
            metadata: this.collectHookMetadata(definition),
            excluded_fields: this.collectExcludedFields(),
        }
        Object.assign(hook, nextHook)

        const requestId = this.hooksRequestId
        const definitionSlug = this.hooksDefinitionSlug
        const formData = new FormData()
        formData.set("definition_slug", definitionSlug)
        formData.set("hook_id", hook.id || "")
        formData.set("target_kind", nextHook.target_kind || nextHook.preset || "")
        formData.set("url", nextHook.target_url)
        formData.set("target_url", nextHook.target_url)
        if (supportsSecret && nextHook.secret !== "") {
            formData.set("secret", nextHook.secret)
        }
        formData.set("preset_key", nextHook.preset_key || "")
        formData.set("preset", nextHook.preset || "")
        formData.set("enabled", nextHook.enabled ? "1" : "0")
        formData.set("enable_in_non_production", nextHook.enabled_non_production ? "1" : "0")
        formData.set("enabled_non_production", nextHook.enabled_non_production ? "1" : "0")
        formData.set("metadata_json", JSON.stringify(nextHook.metadata))
        formData.set("excluded_field_keys_json", JSON.stringify(nextHook.excluded_fields))
        formData.set("excluded_fields_json", JSON.stringify(nextHook.excluded_fields))
        formData.set("csrf_token", this.csrfTokenValue)

        try {
            const payload = await this.postForm(this.hooksSaveUrlValue, formData)
            if (!this.isCurrentHooksRequest(requestId, definitionSlug)) {
                return
            }

            this.mergeHookResponse(payload, submittedHookDomId)
            this.setHooksStatus(this.s("form.builder.hooks.status.saved"))
        } catch (error) {
            if (!this.isCurrentHooksRequest(requestId, definitionSlug)) {
                return
            }

            this.setHooksStatus(this.errorMessage(error, "form.builder.hooks.error_save"))
        }
    }

    async deleteHook(event) {
        event?.preventDefault()
        const hook = this.currentHook()

        if (!hook || !window.confirm(this.s("form.builder.hooks.confirm_delete"))) {
            return
        }

        const submittedHookDomId = this.hookDomId(hook)

        if (hook.id === "") {
            this.removeHookByDomId(submittedHookDomId)
            this.setHooksStatus(this.s("form.builder.hooks.status.deleted"))
            return
        }

        if (!this.hasHooksDeleteUrlValue || this.hooksDeleteUrlValue === "") {
            this.setHooksStatus(this.s("form.builder.hooks.unavailable"))
            return
        }

        const requestId = this.hooksRequestId
        const definitionSlug = this.hooksDefinitionSlug
        const formData = new FormData()
        formData.set("definition_slug", definitionSlug)
        formData.set("hook_id", hook.id)
        formData.set("csrf_token", this.csrfTokenValue)

        try {
            const payload = await this.postForm(this.hooksDeleteUrlValue, formData)
            if (!this.isCurrentHooksRequest(requestId, definitionSlug)) {
                return
            }

            if (Array.isArray(payload?.data?.hooks)) {
                this.applyHooksPayload(payload)
            } else {
                this.removeHookByDomId(submittedHookDomId)
            }

            this.setHooksStatus(this.s("form.builder.hooks.status.deleted"))
        } catch (error) {
            if (!this.isCurrentHooksRequest(requestId, definitionSlug)) {
                return
            }

            this.setHooksStatus(this.errorMessage(error, "form.builder.hooks.error_delete"))
        }
    }

    async openEditorSlug(slug, options = {}) {
        if (slug === "" || !this.hasModalTarget || !this.hasEditorHostTarget) {
            return
        }

        const panel = this.normalizeEditorPanel(options.panel)
        if (!this.confirmEditorTransition(slug, panel)) {
            return
        }

        this.cancelEditorRequest()
        const requestId = this.editorRequestId + 1
        const abortController = new AbortController()
        this.editorRequestId = requestId
        this.editorAbortController = abortController
        this.editorSlug = slug
        this.editorPanel = panel
        this.editorDirty = false
        this.updateEditorUrl(slug, panel, Boolean(options.replace))
        this.setEditorLoading()
        this.modal()?.show()

        try {
            const fragmentUrl = new URL(this.editorFragmentUrlValue, window.location.origin)
            fragmentUrl.searchParams.set("definition_slug", slug)
            fragmentUrl.searchParams.set("panel", panel)
            const response = await fetch(fragmentUrl.toString(), {
                method: "GET",
                headers: { Accept: "text/html" },
                signal: abortController.signal,
            })
            const html = await response.text()

            if (!response.ok) {
                throw new Error(html)
            }

            if (!this.isCurrentEditorRequest(requestId, slug)) {
                return
            }

            this.editorHostTarget.innerHTML = html
        } catch (error) {
            if (error?.name === "AbortError" || !this.isCurrentEditorRequest(requestId, slug)) {
                return
            }

            this.editorHostTarget.innerHTML = `<div class="alert alert-danger m-3" role="alert">${this.escapeHtml(this.s("form.list.editor_load_failed"))}</div>`
        } finally {
            if (this.editorRequestId === requestId) {
                this.editorAbortController = null
            }
        }
    }

    openFromUrl(options = {}) {
        const url = new URL(window.location.href)
        const slug = url.searchParams.get("form") || ""
        const legacySlug = slug === "" ? url.searchParams.get("edit") || "" : ""

        if (legacySlug !== "") {
            url.searchParams.delete("edit")
            url.searchParams.set("form", legacySlug)
            window.location.replace(url.toString())

            return
        }

        if (slug === "") {
            if (this.editorSlug !== "") {
                this.modalHidePrevented = false
                this.modal()?.hide()
                if (this.modalHidePrevented && this.editorSlug !== "") {
                    this.updateEditorUrl(this.editorSlug, this.editorPanel, true)
                }
            }

            return
        }

        this.openEditorSlug(slug, { replace: Boolean(options.replace), panel: this.panelFromUrl() })
    }

    beforeModalHide(event) {
        this.modalHidePrevented = false

        if (!this.editorDirty) {
            return
        }

        if (!window.confirm(this.s("form.builder.warning.discard_unsaved"))) {
            this.modalHidePrevented = true
            event.preventDefault()
        }
    }

    afterModalHidden() {
        this.cancelEditorRequest()
        this.editorRequestId += 1
        this.editorSlug = ""
        this.editorPanel = "form"
        this.editorDirty = false
        this.setEditorLoading()
        const url = this.urlWithoutEditor()
        window.history.replaceState({}, "", url.toString())

        if (this.listNeedsRefresh) {
            window.location.assign(url.pathname + url.search)
        }
    }

    onBuilderDirtyChange(event) {
        this.editorDirty = Boolean(event.detail?.dirty)
    }

    onBuilderChanged(event) {
        this.editorDirty = Boolean(event.detail?.dirty)
        this.listNeedsRefresh = true
    }

    onBuilderPanelChange(event) {
        if (this.editorSlug === "") {
            return
        }

        const panel = this.normalizeEditorPanel(event.detail?.panel)
        this.editorPanel = panel
        this.updateEditorUrl(this.editorSlug, panel, true)
    }

    modal() {
        if (!this.hasModalTarget || !window.bootstrap?.Modal) {
            this.setStatus(this.s("form.list.editor_load_failed"))
            return null
        }

        this.modalInstance = this.modalInstance || window.bootstrap.Modal.getOrCreateInstance(this.modalTarget)

        return this.modalInstance
    }

    updateEditorUrl(slug, panel, replace = false) {
        const url = new URL(window.location.href)
        url.searchParams.delete("edit")
        url.searchParams.set("form", slug)
        url.searchParams.set("panel", panel)
        window.history[replace ? "replaceState" : "pushState"]({}, "", url.toString())
    }

    urlWithoutEditor() {
        const url = new URL(window.location.href)
        url.searchParams.delete("edit")
        url.searchParams.delete("form")
        url.searchParams.delete("panel")

        return url
    }

    panelFromUrl() {
        return this.normalizeEditorPanel(new URL(window.location.href).searchParams.get("panel"))
    }

    normalizeEditorPanel(panel) {
        const value = String(panel || "").toLowerCase()

        return ["input", "hooks"].includes(value) ? value : "form"
    }

    confirmEditorTransition(slug, panel) {
        if (!this.editorDirty || this.editorSlug === "" || (this.editorSlug === slug && this.editorPanel === panel)) {
            return true
        }

        if (window.confirm(this.s("form.builder.warning.discard_unsaved"))) {
            return true
        }

        this.updateEditorUrl(this.editorSlug, this.editorPanel, true)

        return false
    }

    cancelEditorRequest() {
        if (this.editorAbortController) {
            this.editorAbortController.abort()
            this.editorAbortController = null
        }
    }

    isCurrentEditorRequest(requestId, slug) {
        return this.editorRequestId === requestId && this.editorSlug === slug
    }

    setEditorLoading() {
        if (this.hasEditorHostTarget) {
            this.editorHostTarget.innerHTML = this.editorLoadingHtml()
        }
    }

    editorLoadingHtml() {
        const label = this.s("form.list.editor_loading")

        return `<div class="form-list__editor-loading"><span>${this.escapeHtml(label)}</span>${renderInlineLoader({ label, size: 24, color: "#0d6efd" })}</div>`
    }

    applyHooksPayload(payload) {
        const data = payload?.data && typeof payload.data === "object" ? payload.data : payload
        this.hooks = Array.isArray(data?.hooks) ? data.hooks.map((hook, index) => this.normalizeHook(hook, index)) : []
        this.hookTargets = this.normalizeHookTargets(data?.targets)
        this.hookPresets = this.normalizeHookPresets(data?.presets || data?.targets)
        this.hookFields = this.normalizeHookFields(data?.fields || data?.available_field_keys)
        this.attachHookDeliveries(data?.deliveries || [])
        this.activeHookId = this.hooks.length > 0 ? this.hookDomId(this.hooks[0]) : ""
        this.renderHookPresets()
        this.renderHooksOverlay()
    }

    attachHookDeliveries(deliveries) {
        const rows = Array.isArray(deliveries) ? deliveries : []

        this.hooks.forEach((hook) => {
            const hookId = Number(hook.id || 0)
            hook.recent_logs = rows.filter((row) => hookId > 0 && Number(row?.hook_id || 0) === hookId)
        })

        this.renderHooksOverlay()
    }

    mergeHookResponse(payload, submittedHookDomId = this.activeHookId) {
        if (Array.isArray(payload?.data?.hooks)) {
            this.applyHooksPayload(payload)
            return
        }

        const savedHook = payload?.data?.hook

        if (savedHook && typeof savedHook === "object") {
            const normalized = this.normalizeHook(savedHook, this.hooks.length)
            const targetId = String(submittedHookDomId || this.activeHookId)
            const wasActive = this.activeHookId === targetId
            const index = this.hooks.findIndex((hook) => this.hookDomId(hook) === targetId)

            if (index >= 0) {
                this.hooks.splice(index, 1, normalized)
            } else {
                this.hooks.unshift(normalized)
            }

            if (wasActive || this.activeHookId === "") {
                this.activeHookId = this.hookDomId(normalized)
            }
        }

        this.renderHooksOverlay()
    }

    removeCurrentHook() {
        this.removeHookByDomId(this.activeHookId)
    }

    removeHookByDomId(hookDomId) {
        const targetId = String(hookDomId || "")
        const activeId = this.activeHookId
        this.hooks = this.hooks.filter((hook) => this.hookDomId(hook) !== targetId)
        const activeStillExists = this.hooks.some((hook) => this.hookDomId(hook) === activeId)
        this.activeHookId = targetId !== activeId && activeStillExists
            ? activeId
            : (this.hooks.length > 0 ? this.hookDomId(this.hooks[0]) : "")
        this.renderHooksOverlay()
    }

    renderHooksOverlay() {
        this.updateHooksTitle()
        this.renderHooksList()
        this.renderHookEditor()
    }

    updateHooksTitle() {
        if (this.hasHooksTitleSlugTarget) {
            this.hooksTitleSlugTarget.textContent = this.hooksDefinitionSlug === "" ? "" : ` / ${this.hooksDefinitionSlug}`
        }
    }

    renderHookPresets() {
        if (!this.hasHooksPresetSelectTarget) {
            return
        }

        const presets = this.hookPresets.length > 0 ? this.hookPresets : this.defaultHookPresets()
        this.hooksPresetSelectTarget.innerHTML = presets.map((preset) => {
            return `<option value="${this.escapeAttr(preset.id)}">${this.escapeHtml(preset.label)}</option>`
        }).join("")
    }

    renderHooksList() {
        if (!this.hasHooksListTarget) {
            return
        }

        if (this.hooks.length === 0) {
            this.hooksListTarget.innerHTML = `<div class="form-builder__empty-properties">${this.escapeHtml(this.s("form.builder.hooks.empty"))}</div>`
            return
        }

        this.hooksListTarget.innerHTML = this.hooks.map((hook) => {
            const hookId = this.hookDomId(hook)
            const active = hookId === this.activeHookId
            const preset = this.presetLabel(hook.target_kind || hook.preset)
            const metadataTarget = this.metadataTargetLabel(hook.metadata)
            const target = hook.label || hook.target_url || metadataTarget || preset || this.s("form.builder.hooks.target")
            const enabled = hook.enabled ? `<span class="badge text-bg-success bg-opacity-75">${this.escapeHtml(this.s("form.builder.hooks.enabled"))}</span>` : ""

            return `<button type="button" class="form-builder__hook-target${active ? " is-active" : ""}" data-hook-id="${this.escapeAttr(hookId)}" data-action="form-list#selectHook" aria-pressed="${active ? "true" : "false"}">`
                + `<span>${this.escapeHtml(target)}</span>`
                + `<small>${this.escapeHtml(preset)}</small>`
                + enabled
                + `</button>`
        }).join("")
    }

    renderHookEditor() {
        if (!this.hasHooksEditorTarget) {
            return
        }

        const hook = this.currentHook()
        this.hooksEditorTarget.hidden = !hook

        if (!hook) {
            return
        }

        const definition = this.hookTargetDefinition(hook)
        this.syncHookCapabilityFields(definition)
        this.hookTargetUrlInputTarget.value = hook.target_url || ""
        if (this.hasHookSecretInputTarget) {
            this.hookSecretInputTarget.value = ""
        }
        this.hookEnabledInputTarget.checked = Boolean(hook.enabled)
        this.hookNonProductionInputTarget.checked = Boolean(hook.enabled_non_production)
        this.renderHookMetadata(hook, definition)
        this.renderExcludedFields(hook.excluded_fields)
        this.renderHookLogs(hook.recent_logs)
    }

    renderExcludedFields(excludedFields) {
        if (!this.hasHookExcludedFieldsTarget) {
            return
        }

        if (this.hookFields.length === 0) {
            this.hookExcludedFieldsTarget.innerHTML = `<div class="form-builder__empty-properties">${this.escapeHtml(this.s("form.builder.hooks.no_fields"))}</div>`
            return
        }

        const excluded = new Set(this.stringArray(excludedFields))
        this.hookExcludedFieldsTarget.innerHTML = this.hookFields.map((field) => {
            const checked = excluded.has(field.key) ? " checked" : ""

            return `<label class="form-check form-builder__hook-check">`
                + `<input type="checkbox" class="form-check-input" data-hook-excluded-field value="${this.escapeAttr(field.key)}"${checked}>`
                + `<span>${this.escapeHtml(field.label || field.key)}</span>`
                + `<code>${this.escapeHtml(field.key)}</code>`
                + `</label>`
        }).join("")
    }

    renderHookLogs(logs) {
        if (!this.hasHookLogsBodyTarget) {
            return
        }

        const rows = Array.isArray(logs) ? logs : []

        if (rows.length === 0) {
            this.hookLogsBodyTarget.innerHTML = `<tr><td colspan="4" class="text-body-secondary">${this.escapeHtml(this.s("form.builder.hooks.no_logs"))}</td></tr>`
            return
        }

        this.hookLogsBodyTarget.innerHTML = rows.map((log) => {
            const result = log?.result && typeof log.result === "object" ? log.result : {}
            const time = this.formatHookDate(log?.completed_at || log?.queued_at || log?.created_at || log?.time || "")
            const status = String(log?.status || "")
            const httpStatus = String(log?.http_status || log?.status_code || result.http_status || result.status || "")
            const message = String(log?.message || log?.error || log?.error_message || result.message || result.body_preview || "")

            return `<tr>`
                + `<td>${this.escapeHtml(time)}</td>`
                + `<td>${this.escapeHtml(status)}</td>`
                + `<td>${this.escapeHtml(httpStatus)}</td>`
                + `<td>${this.escapeHtml(message)}</td>`
            + `</tr>`
        }).join("")
    }

    renderHookMetadata(hook, definition) {
        if (!this.hasHookMetadataRowsTarget) {
            return
        }

        const schemaEntries = this.metadataSchemaEntries(definition)

        if (this.hasHookMetadataAddButtonTarget) {
            this.hookMetadataAddButtonTarget.hidden = schemaEntries.length > 0
        }

        if (schemaEntries.length > 0) {
            this.hookMetadataRowsTarget.innerHTML = schemaEntries
                .map(([key, schema]) => this.hookMetadataSchemaFieldHtml(key, schema, hook.metadata?.[key] ?? ""))
                .join("")
            return
        }

        this.hookMetadataRowsTarget.innerHTML = this.metadataRows(hook.metadata)
            .map((row) => this.hookMetadataRowHtml(row.key, row.value))
            .join("")
    }

    hookMetadataSchemaFieldHtml(key, schema, value) {
        const type = String(schema?.type || "string")
        const required = this.booleanValue(schema?.required, false)
        const label = this.s(`form.builder.hooks.metadata.${key}`)
        const requiredAttr = required ? " required" : ""
        const keyAttr = this.escapeAttr(key)
        const valueString = String(value ?? "")

        if (type === "boolean") {
            const checked = this.booleanValue(value, false) ? " checked" : ""

            return `<label class="form-check form-builder__hook-metadata-field form-builder__hook-metadata-field--check">`
                + `<input type="checkbox" class="form-check-input" data-hook-metadata-schema-key="${keyAttr}" data-hook-metadata-type="boolean"${checked}>`
                + `<span>${this.escapeHtml(label)}</span>`
                + `</label>`
        }

        if (type === "field_key") {
            const options = [`<option value="">${this.escapeHtml(this.s("form.builder.hooks.metadata.no_field"))}</option>`]
                .concat(this.hookFields.map((field) => {
                    const selected = field.key === valueString ? " selected" : ""

                    return `<option value="${this.escapeAttr(field.key)}"${selected}>${this.escapeHtml(field.label || field.key)}</option>`
                }))
                .join("")

            return `<label class="form-label form-builder__hook-metadata-field">`
                + `<span>${this.escapeHtml(label)}</span>`
                + `<select class="form-select form-select-sm" data-hook-metadata-schema-key="${keyAttr}" data-hook-metadata-type="field_key"${requiredAttr}>${options}</select>`
                + `</label>`
        }

        const inputType = type === "email" ? "email" : "text"

        return `<label class="form-label form-builder__hook-metadata-field">`
            + `<span>${this.escapeHtml(label)}</span>`
            + `<input type="${inputType}" class="form-control form-control-sm" data-hook-metadata-schema-key="${keyAttr}" data-hook-metadata-type="${this.escapeAttr(type)}" value="${this.escapeAttr(valueString)}"${requiredAttr}>`
            + `</label>`
    }

    hookMetadataRowHtml(key, value) {
        return `<div class="form-builder__hook-metadata-row">`
            + `<input type="text" class="form-control form-control-sm" data-hook-metadata-key placeholder="${this.escapeAttr(this.s("form.builder.hooks.metadata_key"))}" value="${this.escapeAttr(key)}">`
            + `<input type="text" class="form-control form-control-sm" data-hook-metadata-value placeholder="${this.escapeAttr(this.s("form.builder.hooks.metadata_value"))}" value="${this.escapeAttr(value)}">`
            + `<button type="button" class="btn btn-outline-secondary btn-sm" data-action="form-list#removeHookMetadataRow" aria-label="${this.escapeAttr(this.s("form.builder.hooks.remove_metadata"))}"><i class="bi bi-x-lg" aria-hidden="true"></i></button>`
            + `</div>`
    }

    collectHookMetadata(definition = null) {
        const metadata = {}

        if (!this.hasHookMetadataRowsTarget) {
            return metadata
        }

        const schemaEntries = definition ? this.metadataSchemaEntries(definition) : []

        if (schemaEntries.length > 0) {
            this.hookMetadataRowsTarget.querySelectorAll("[data-hook-metadata-schema-key]").forEach((input) => {
                const key = String(input.dataset.hookMetadataSchemaKey || "").trim()

                if (key === "") {
                    return
                }

                if (input.dataset.hookMetadataType === "boolean") {
                    metadata[key] = Boolean(input.checked)
                    return
                }

                const value = String(input.value || "").trim()

                if (value !== "") {
                    metadata[key] = value
                }
            })

            return metadata
        }

        this.hookMetadataRowsTarget.querySelectorAll(".form-builder__hook-metadata-row").forEach((row) => {
            const key = String(row.querySelector("[data-hook-metadata-key]")?.value || "").trim()
            const value = String(row.querySelector("[data-hook-metadata-value]")?.value || "")

            if (key !== "") {
                metadata[key] = value
            }
        })

        return metadata
    }

    collectExcludedFields() {
        if (!this.hasHookExcludedFieldsTarget) {
            return []
        }

        return Array.from(this.hookExcludedFieldsTarget.querySelectorAll("[data-hook-excluded-field]:checked"))
            .map((input) => String(input.value || ""))
            .filter(Boolean)
    }

    currentHook() {
        return this.hooks.find((hook) => this.hookDomId(hook) === this.activeHookId) || null
    }

    hookDomId(hook) {
        return hook.id !== "" ? `id:${hook.id}` : `client:${hook._clientId}`
    }

    normalizeHook(hook, index) {
        const targetKind = this.normalizeHookKind(hook?.target_kind || hook?.kind || hook?.target || hook?.preset || "custom_https_webhook")

        return {
            id: String(hook?.id || hook?.hook_id || ""),
            _clientId: String(hook?._client_id || hook?.client_id || `loaded_${index}`),
            label: String(hook?.label || ""),
            target_kind: targetKind,
            target_url: String(hook?.target_url || hook?.url || ""),
            preset: String(hook?.preset || hook?.preset_id || targetKind),
            preset_key: String(hook?.preset_key || ""),
            enabled: this.booleanValue(hook?.enabled, true),
            enabled_non_production: this.booleanValue(hook?.enabled_non_production ?? hook?.enable_in_non_production, false),
            has_secret: this.booleanValue(hook?.has_secret, false),
            metadata: this.metadataObject(hook?.metadata),
            excluded_fields: this.stringArray(hook?.excluded_fields || hook?.excluded_field_keys),
            recent_logs: Array.isArray(hook?.recent_logs) ? hook.recent_logs : (Array.isArray(hook?.logs || hook?.deliveries) ? (hook.logs || hook.deliveries) : []),
        }
    }

    normalizeHookTargets(targets) {
        if (!Array.isArray(targets)) {
            return []
        }

        return targets.map((target) => ({
            kind: this.normalizeHookKind(target?.kind || target?.id || ""),
            label: String(target?.label || target?.name || target?.kind || ""),
            supports_url: this.booleanValue(target?.supports_url, true),
            supports_secret: this.booleanValue(target?.supports_secret, false),
            supports_preset_key: this.booleanValue(target?.supports_preset_key, false),
            metadata_schema: this.metadataSchemaObject(target?.metadata_schema),
        })).filter((target) => target.kind !== "")
    }

    normalizeHookPresets(presets) {
        if (!Array.isArray(presets) || presets.length === 0) {
            return this.defaultHookPresets()
        }

        return presets.map((preset) => {
            const id = String(preset?.id || preset?.key || preset?.kind || "custom_https_webhook")
            const targetKind = this.normalizeHookKind(preset?.target_kind || preset?.kind || id)

            return {
                id,
                target_kind: targetKind,
                label: String(preset?.label || preset?.name || preset?.id || this.s("form.builder.hooks.preset.custom")),
                target_url: String(preset?.target_url || preset?.url || ""),
                preset_key: String(preset?.preset_key || ""),
                metadata: this.metadataObject(preset?.metadata),
                excluded_fields: this.stringArray(preset?.excluded_fields),
            }
        })
    }

    normalizeHookFields(fields) {
        if (!Array.isArray(fields)) {
            return []
        }

        return fields.map((field) => {
            const key = String(field?.key || field?.name || field?.id || field || "")
            const label = this.textFromUnknown(field?.label || field?.title || field?.name || key)

            return { key, label }
        }).filter((field) => field.key !== "")
    }

    defaultHookPresets() {
        return [{
            id: "custom_https_webhook",
            target_kind: "custom_https_webhook",
            label: this.s("form.builder.hooks.preset.custom"),
            target_url: "",
            preset_key: "",
            metadata: {},
            excluded_fields: [],
        }]
    }

    selectedHookPreset() {
        const presetId = this.hasHooksPresetSelectTarget ? this.hooksPresetSelectTarget.value : "custom"

        return this.hookPresets.find((preset) => preset.id === presetId) || this.defaultHookPresets()[0]
    }

    presetLabel(presetId) {
        const normalized = this.normalizeHookKind(presetId)

        return (this.hookPresets.find((preset) => preset.id === presetId || preset.target_kind === normalized) || this.defaultHookPresets()[0]).label
    }

    hookTargetDefinition(hook) {
        const kind = this.normalizeHookKind(hook?.target_kind || hook?.preset || "")

        return this.hookTargets.find((target) => target.kind === kind)
            || this.defaultHookTarget()
    }

    defaultHookTarget() {
        return {
            kind: "custom_https_webhook",
            label: this.s("form.builder.hooks.preset.custom"),
            supports_url: true,
            supports_secret: true,
            supports_preset_key: false,
            metadata_schema: {},
        }
    }

    hookSupports(definition, feature, fallback = false) {
        const key = `supports_${feature}`

        if (!definition || definition[key] === undefined || definition[key] === null || definition[key] === "") {
            return fallback
        }

        return this.booleanValue(definition[key], fallback)
    }

    syncHookCapabilityFields(definition) {
        const supportsUrl = this.hookSupports(definition, "url", true)
        const supportsSecret = this.hookSupports(definition, "secret", false)

        if (this.hasHookTargetUrlGroupTarget) {
            this.hookTargetUrlGroupTarget.hidden = !supportsUrl
        }

        if (this.hasHookTargetUrlInputTarget) {
            this.hookTargetUrlInputTarget.disabled = !supportsUrl
        }

        if (this.hasHookSecretGroupTarget) {
            this.hookSecretGroupTarget.hidden = !supportsSecret
        }

        if (this.hasHookSecretInputTarget) {
            this.hookSecretInputTarget.disabled = !supportsSecret
        }
    }

    firstVisibleHookInput() {
        return Array.from(this.hooksEditorTarget?.querySelectorAll("input,select,button") || [])
            .find((element) => !element.disabled && !element.hidden && element.offsetParent !== null)
            || null
    }

    metadataTargetLabel(metadata) {
        const data = this.metadataObject(metadata)

        return String(data.to || "")
    }

    metadataSchemaObject(schema) {
        return schema && typeof schema === "object" && !Array.isArray(schema) ? schema : {}
    }

    metadataSchemaEntries(definition) {
        return Object.entries(this.metadataSchemaObject(definition?.metadata_schema))
    }

    normalizeHookKind(value) {
        const kind = String(value || "").trim().toLowerCase().replace(/-/g, "_")

        if (["custom", "custom_http", "https_webhook", "webhook", "custom_https"].includes(kind)) {
            return "custom_https_webhook"
        }

        if (["email", "raw_email", "raw_form_email"].includes(kind)) {
            return "raw_form_data_email"
        }

        return kind.replace(/[^a-z0-9_]+/g, "_")
    }

    metadataObject(metadata) {
        if (Array.isArray(metadata)) {
            return metadata.reduce((result, row) => {
                const key = String(row?.key || "").trim()

                if (key !== "") {
                    result[key] = String(row?.value || "")
                }

                return result
            }, {})
        }

        if (metadata && typeof metadata === "object") {
            return Object.fromEntries(Object.entries(metadata).map(([key, value]) => [key, String(value ?? "")]))
        }

        return {}
    }

    metadataRows(metadata) {
        return Object.entries(this.metadataObject(metadata)).map(([key, value]) => ({ key, value }))
    }

    stringArray(value) {
        return Array.isArray(value) ? value.map((item) => String(item || "")).filter(Boolean) : []
    }

    booleanValue(value, fallback) {
        if (value === undefined || value === null || value === "") {
            return fallback
        }

        return value === true || value === 1 || value === "1" || value === "true"
    }

    textFromUnknown(value) {
        if (value && typeof value === "object") {
            return String(value.text || value.label || value.key || "")
        }

        return String(value || "")
    }

    formatHookDate(value) {
        const raw = String(value || "").trim()

        if (raw === "") {
            return ""
        }

        const parsed = new Date(raw.replace(/\s+/, "T"))

        return Number.isNaN(parsed.getTime()) ? raw : parsed.toLocaleString()
    }

    setHooksStatus(message) {
        if (this.hasHooksStatusTarget) {
            this.hooksStatusTarget.textContent = message
        }
    }

    async fetchJson(url, options = {}) {
        const response = await fetch(url, options)
        const responseText = await response.text()
        let payload = {}

        try {
            payload = responseText === "" ? {} : JSON.parse(responseText)
        } catch (_error) {
            throw new Error(this.s("form.builder.error_request"))
        }

        if (!response.ok) {
            throw new Error(payload?.error?.message || this.s("form.builder.error_request"))
        }

        return payload
    }

    async postForm(url, formData) {
        const response = await fetch(url, {
            method: "POST",
            headers: { Accept: "application/json" },
            body: formData,
        })
        const payload = await response.json().catch(() => ({}))

        if (!response.ok) {
            throw new Error(payload?.error?.message || this.s("form.builder.error_request"))
        }

        return payload
    }

    setStatus(message) {
        if (this.hasStatusTarget) {
            this.statusTarget.textContent = message
        }
    }

    isPlainPrimaryClick(event) {
        return event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey
    }

    errorMessage(error, fallbackKey) {
        return error instanceof Error && error.message !== "" ? error.message : this.s(fallbackKey)
    }

    escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, (char) => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            "\"": "&quot;",
            "'": "&#039;",
        }[char]))
    }

    escapeAttr(value) {
        return this.escapeHtml(value)
    }

    s(key) {
        return this.stringsValue?.[key] || key
    }
}
