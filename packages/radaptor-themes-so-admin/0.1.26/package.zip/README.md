# Radaptor SoAdmin Theme

`radaptor/themes/so-admin` provides the classic admin theme (`SoAdmin`)
for Radaptor CMS.
It includes theme templates, layout wrappers, and isolated assets maintained
separately from other themes.

## Installation

Use through a registry-first consumer app:

- [`radaptor-app`](https://github.com/istvan-ujjmeszaros/radaptor-app)
- [`radaptor-portal`](https://github.com/istvan-ujjmeszaros/radaptor-portal)

The theme is resolved from package metadata during app install/update.

## Dependencies

From `.registry-package.json`:

- `radaptor/core/cms` (`^0.1.17`)

## Layout deprecation declarations

When a layout name in this theme becomes obsolete and is replaced by a successor,
declare the rename in `.registry-package.json`'s `deprecated_layouts` map:

```json
"deprecated_layouts": {
    "admin_nomenu": "admin_login"
}
```

The next `radaptor install` / `update` / `local-lock:refresh` run in any consumer
app that picks up this theme version will, after refreshing the registry packages
on disk, detect affected webpages and `_theme_settings` mappings and prompt the
maintainer to apply the rename (or pass `--apply-layout-renames` /
`--abort-on-layout-renames` non-interactively). Aborting leaves the registry
refreshed but performs no CMS-content mutation; the next run re-prompts.

**Never remove past entries from `deprecated_layouts`.** The map is cumulative —
consumer apps may upgrade across multiple theme versions, and an older entry must
still cover their content state. Apply policy:

- Old key (LHS) must be a layout that this theme previously shipped but no longer renders.
- New value (RHS) must be a layout this theme (or its core dependency) currently
  registers in `theme/_layout/template.layout_<name>.php` (or the core CMS shipped
  layouts under `core/cms/templates-common/default-SoAdmin/_layout/`).
- The gate validates the target layout exists; missing targets fail
  install/update/local-lock:refresh before any CMS-content mutation
  (the registry has been refreshed at that point, but lockfile-write,
  asset-build, plugin-bridge, migrations, and seeds have not yet run).

## Development and Release

Maintain this theme in `/apps/_RADAPTOR/packages-dev/themes/so-admin`, not inside a consumer app's
`packages/registry/...` runtime copy. Validate through a consumer app `php` container; do not run
host PHP, Composer, PHPUnit, PHPStan, or PHP-CS-Fixer.

Release key:

- `theme:so-admin`

Normal flow: package PR, local Codex CLI review agent result posted on the PR, fix/review loop
repeated until the current HEAD has an explicit no-findings result, clean repo checks, explicit
maintainer approval, squash merge, fast-forward local `main`, `package:release theme:so-admin`,
commit the `.registry-package.json` version bump, then publish the generated artifact through
`radaptor_plugin_registry`.

Asset links are declared in `.registry-package.json` under `assets.public` and are created by
`build:assets` under the consumer app's `public/www/assets/packages/...`. Do not manually copy or
symlink theme assets into app runtime paths.

## License

This package is distributed under the proprietary evaluation license in
[LICENSE](./LICENSE).
Evaluation-only: no production/commercial/distribution/derivative use without
a separate license agreement.

## Contact

istvan@radaptor.com
