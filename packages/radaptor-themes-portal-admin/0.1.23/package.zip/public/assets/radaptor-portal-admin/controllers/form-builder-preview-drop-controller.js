import { Controller } from "/assets/packages/radaptor-portal-admin/js/stimulus.js"

export default class extends Controller {
    dragEnter(event) {
        this.acceptDrop(event)
    }

    dragOver(event) {
        this.acceptDrop(event)
    }

    acceptDrop(event) {
        event.preventDefault()
        this.element.classList.add("radaptor-form-builder-drop-active")

        const zone = event.target.closest?.("[data-form-builder-drop-index]")

        this.element.querySelectorAll(".radaptor-form-builder-drop-zone-active").forEach((activeZone) => {
            activeZone.classList.remove("radaptor-form-builder-drop-zone-active")
        })

        if (zone) {
            zone.classList.add("radaptor-form-builder-drop-zone-active")
        }

        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = "copy"
        }

        window.parent.postMessage({
            type: "radaptor:form-builder-preview-hover",
            dropIndex: this.dropIndexFromEvent(event),
            clientX: event.clientX,
            clientY: event.clientY,
        }, "*")
    }

    dragLeave(event) {
        if (event.relatedTarget && this.element.contains(event.relatedTarget)) {
            return
        }

        this.clearDropState()
    }

    drop(event) {
        event.preventDefault()
        event.stopPropagation()

        window.parent.postMessage({
            type: "radaptor:form-builder-preview-drop",
            payload: this.payloadFromDataTransfer(event),
            dropIndex: this.dropIndexFromEvent(event),
            clientX: event.clientX,
            clientY: event.clientY,
        }, "*")
        this.clearDropState()
    }

    clearDropState() {
        this.element.classList.remove("radaptor-form-builder-drop-active")
        this.element.querySelectorAll(".radaptor-form-builder-drop-zone-active").forEach((zone) => {
            zone.classList.remove("radaptor-form-builder-drop-zone-active")
        })
    }

    dropIndexFromEvent(event) {
        const zone = event.target.closest?.("[data-form-builder-drop-index]")

        if (!zone) {
            return null
        }

        const index = Number(zone.dataset.formBuilderDropIndex)

        return Number.isInteger(index) ? index : null
    }

    payloadFromDataTransfer(event) {
        const raw = event.dataTransfer?.getData("text/plain") || ""

        if (raw === "") {
            return null
        }

        try {
            const parsed = JSON.parse(raw)

            if (parsed && typeof parsed === "object") {
                return parsed
            }
        } catch {
            return {
                kind: "palette",
                fieldType: raw,
            }
        }

        return null
    }
}
