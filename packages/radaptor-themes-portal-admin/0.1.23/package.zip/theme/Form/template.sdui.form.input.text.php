<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$readonly = (bool)($this->props['readonly'] ?? false);
$has_errors = !empty($this->props['errors'] ?? []);
$input_classes = 'form-control' . ($has_errors ? ' is-invalid' : '');
$connected_autocomplete_input_id = (string)($this->props['connected_autocomplete_input_id'] ?? '');
$connected_autocomplete_field_key = (string)($this->props['connected_autocomplete_field_key'] ?? '');
?>
<div class="col">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label" for="<?= e((string)$this->props['id']) ?>"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
		<input class="<?= e($input_classes) ?>" id="<?= e((string)$this->props['id']) ?>"<?= (string)($this->props['input_style_attr'] ?? '') ?> type="text" name="<?= e((string)$this->props['name']) ?>" data-field-key="<?= e((string)($this->props['data_field_key'] ?? $this->props['name'] ?? '')) ?>" value="<?= e((string)($this->props['value'] ?? '')) ?>"<?= $readonly ? ' readonly="readonly" tabindex="-1"' : '' ?>>
	<?= $this->fetchContent('helper') ?>
</div>

<?php if ((string)($this->props['autocomplete_url'] ?? '') !== ''): ?>
	<script>
		(function () {
		<?php if ((string)($this->props['connected_autocomplete_fieldname'] ?? '') !== ''): ?>
		document.getElementById("<?= e((string)($this->props['connected_autocomplete_row_id'] ?? '')) ?>")?.style.setProperty('display', 'none')
		var setConnectedAutocompleteValue = function (source, value) {
			var connectedAutocompleteInputId = "<?= e($connected_autocomplete_input_id) ?>";
			var connectedAutocompleteFieldKey = "<?= e($connected_autocomplete_field_key) ?>";
			var connected = connectedAutocompleteInputId !== "" ? $(document.getElementById(connectedAutocompleteInputId)) : $();

			if (!connected.length && connectedAutocompleteFieldKey !== "") {
				connected = $(source).closest("form").find("[data-field-key]").filter(function () {
					return $(this).attr("data-field-key") === connectedAutocompleteFieldKey;
				});
			}

			connected.val(value);
		};
		<?php endif; ?>

		$("#<?= e((string)$this->props['id']) ?>")
			.bind("keydown", function (event) {
				if (event.keyCode === $.ui.keyCode.TAB &&
					$(this).data("ui-autocomplete").menu.active) {
					event.preventDefault();
				}
			})
			<?php if ((string)($this->props['connected_autocomplete_fieldname'] ?? '') !== ''): ?>
				.bind("keyup", function (event) {
					if (event.keyCode !== $.ui.keyCode.ENTER) {
						setConnectedAutocompleteValue(this, '_' + this.value + '_')
					}
				})
			<?php endif; ?>
			.autocomplete({
				source: function (request, response) {
					$.getJSON("<?= e((string)($this->props['autocomplete_url'] ?? '')) ?>", {
						term: extractLast(request.term)
					}, response);
				},
				search: function () {
					extractLast(this.value);
				},
				focus: function () {
					return false;
				},
				select: function (event, ui) {
					$("#<?= e((string)$this->props['id']) ?>").val(stripTags(ui.item.label));
					<?php if ((string)($this->props['connected_autocomplete_fieldname'] ?? '') !== ''): ?>
						setConnectedAutocompleteValue(this, ui.item.value);
					<?php endif; ?>
					return false;
				}
			})
			.data("ui-autocomplete")._renderItem = function (ul, item) {
			item.label = item.label.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + $.ui.autocomplete.escapeRegex($.trim(this.term)) + ")(?![^<>]*>)(?![^&;]+;)", "gi"), "<strong>$1</strong>");
			return $("<li></li>")
				.data("item.autocomplete", item)
					.append("<a>" + item.label + "</a>")
					.appendTo(ul);
			};
		})();
	</script>
<?php endif; ?>
