<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$values = is_array($this->props['values'] ?? null) ? $this->props['values'] : [];
$isSafeLinkGroupUrl = static function (string $url): bool {
	$url = trim($url);

	if ($url === '' || preg_match('/[\x00-\x1F\x7F]/', $url) === 1) {
		return false;
	}

	if (preg_match('/^([a-z][a-z0-9+.-]*):/i', $url, $matches) !== 1) {
		return true;
	}

	return in_array(strtolower($matches[1]), ['http', 'https'], true);
};
?>
<div class="col-12">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label d-block"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
	<div class="btn-group flex-wrap" role="group">
		<?php foreach ($values as $value): ?>
			<?php
			$url = (string)($value['url'] ?? '');
			$label = (string)($value['label'] ?? $url);
			$active = (bool)($value['active'] ?? false);
			$is_safe_url = $isSafeLinkGroupUrl($url);
			?>
			<?php if ($active): ?>
				<span class="btn btn-sm btn-primary disabled" aria-current="true"><?= e($label) ?></span>
			<?php elseif (!$is_safe_url): ?>
				<span class="btn btn-sm btn-outline-secondary disabled"><?= e($label) ?></span>
			<?php else: ?>
				<a class="btn btn-sm btn-outline-secondary" href="<?= e(trim($url)) ?>"><?= e($label) ?></a>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>
	<?= $this->fetchContent('helper') ?>
</div>
