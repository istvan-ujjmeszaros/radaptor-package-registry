<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$this->registerLibrary('CALENDAR');
$readonly = (bool)($this->props['readonly'] ?? false);
$has_errors = !empty($this->props['errors'] ?? []);
?>
<div class="col">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label" for="<?= e((string)$this->props['id']) ?>"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
		<input class="form-control<?= $has_errors ? ' is-invalid' : '' ?>" id="<?= e((string)$this->props['id']) ?>"<?= (string)($this->props['input_style_attr'] ?? '') ?> type="text" name="<?= e((string)$this->props['name']) ?>" data-field-key="<?= e((string)($this->props['data_field_key'] ?? $this->props['name'] ?? '')) ?>" value="<?= e((string)($this->props['value'] ?? '')) ?>" data-controller="flatpickr" data-flatpickr-enable-time-value="true" data-flatpickr-date-format-value="Y-m-d H:i"<?= $readonly ? ' readonly="readonly" tabindex="-1"' : '' ?>>
	<?= $this->fetchContent('helper') ?>
</div>
