<?php
assert(isset($this) && $this instanceof Template);
$this->registerLibrary('_ADMIN_DROPDOWN');
$layout_commands = is_array($this->props['layout_commands'] ?? null) ? $this->props['layout_commands'] : [];
?>

<div class="admin-dropdown-container position-fixed" style="bottom: 20px; right: 20px; z-index: 1050;">
	<div class="dropdown dropup">
		<button class="btn btn-primary rounded-circle shadow-lg" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="width: 50px; height: 50px;">
			<?= Icons::get(IconNames::ADMIN_WRENCH); ?>
		</button>
		<ul class="dropdown-menu dropdown-menu-end shadow">
			<li>
				<a class="dropdown-item" href="<?= e((string)($this->props['page_edit_url'] ?? '')) ?>">
					<i class="bi bi-gear me-2"></i><?= e((string)($this->props['page_edit_label'] ?? '')) ?>
				</a>
			</li>
			<li>
				<a class="dropdown-item" href="<?= e((string)($this->props['edit_mode_url'] ?? '')) ?>">
					<i class="bi bi-pencil me-2"></i><?= e((string)($this->props['edit_mode_action_label'] ?? $this->props['edit_mode_label'] ?? '')) ?>
				</a>
			</li>

			<?php foreach ($layout_commands as $command): ?>
				<?php $icon = isset($command['icon']) ? IconNames::tryFrom((string)$command['icon']) : null; ?>
				<li>
					<a class="dropdown-item" href="<?= e((string)($command['url'] ?? '')) ?>">
						<?= Icons::get($icon); ?>
						<span class="ms-2"><?= e((string)($command['title'] ?? '')) ?></span>
					</a>
				</li>
			<?php endforeach; ?>

			<li><hr class="dropdown-divider"></li>
			<li>
				<a class="dropdown-item" href="<?= e((string)($this->props['home_url'] ?? '')) ?>">
					<i class="bi bi-house me-2"></i><?= e((string)($this->props['home_label'] ?? '')) ?>
				</a>
			</li>
			<li>
				<a class="dropdown-item" href="<?= e((string)($this->props['logout_url'] ?? '')) ?>">
					<i class="bi bi-box-arrow-right me-2"></i><?= e((string)($this->props['logout_label'] ?? '')) ?>
				</a>
			</li>
		</ul>
	</div>
</div>
