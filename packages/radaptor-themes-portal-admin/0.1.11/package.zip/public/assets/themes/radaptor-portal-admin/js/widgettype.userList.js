/**
 * User list DataTable functionality for RadaptorPortalAdmin theme.
 * Uses DataTables 2.x API.
 */
if (typeof(widgettype) != "object")
    var widgettype = {};

widgettype.userList = new function()
{
    var _config = {};
    var _userListTable;

    this.bindEvents = function()
    {
        $(window).on("resize", function() {
            if (_userListTable) {
                _userListTable.columns.adjust();
            }
        });
    }

    this.initUserListTable = function()
    {
        _userListTable = new DataTable("#" + _config.userListTableId, {
            columns: [
                {
                    orderable: true,
                    searchable: true,
                    render: function(data, type, row) {
                        if (type === 'display') {
                            if (_config.url_datasheet) {
                                var target_url = _config.url_datasheet + (data * 1) + '/';
                                return '<a href="' + target_url + '">' + data + '</a>';
                            }

                            return data;
                        }
                        return data;
                    }
                },
                {
                    searchable: true,
                    type: "html"
                },
                {
                    orderable: false,
                    render: function(data, type, row) {
                        if (type !== 'display') return data;

                        var id = data;
                        var operation_edit = '<a class="operation-edit" data-operation="edit" data-id="' + id + '" title="' + widgettype.userList.escapeAttribute(_config.label_edit) + '" aria-label="' + widgettype.userList.escapeAttribute(_config.label_edit) + '">' + _config.icon_edit + '</a>';
                        var operation_datasheet = '<a class="operation-datasheet" data-operation="datasheet" data-id="' + id + '" title="' + widgettype.userList.escapeAttribute(_config.label_datasheet) + '" aria-label="' + widgettype.userList.escapeAttribute(_config.label_datasheet) + '">' + _config.icon_datasheet + '</a>';
                        var operation_roles = '<a class="operation-roles" data-operation="roles" data-id="' + id + '" title="' + widgettype.userList.escapeAttribute(_config.label_roles) + '" aria-label="' + widgettype.userList.escapeAttribute(_config.label_roles) + '">' + _config.icon_roles + '</a>';
                        var operation_usergroups = '<a class="operation-usergroups" data-operation="usergroups" data-id="' + id + '" title="' + widgettype.userList.escapeAttribute(_config.label_usergroups) + '" aria-label="' + widgettype.userList.escapeAttribute(_config.label_usergroups) + '">' + _config.icon_usergroups + '</a>';

                        var ret = "";
                        if (_config.operation_edit) ret += operation_edit;
                        if (_config.operation_datasheet) ret += operation_datasheet;
                        if (_config.operation_roles) ret += operation_roles;
                        if (_config.operation_usergroups) ret += operation_usergroups;

                        return ret;
                    }
                }
            ],
            layout: {
                topStart: 'pageLength',
                topEnd: 'search',
                bottomStart: 'info',
                bottomEnd: 'paging'
            },
            info: true,
            paging: true,
            processing: true,
            stateSave: false,
            ajax: {
                url: _config.ajaxBaseUrl + "Load",
                dataSrc: function(payload) {
                    if (!payload || payload.ok !== true) {
                        return [];
                    }
                    return (payload.data && payload.data.data) ? payload.data.data : [];
                }
            },
            language: {
                infoFiltered: "<br><i>szűrt eredmény _MAX_ adatsorból</i>",
                infoEmpty: "Nincs találat",
                info: "_TOTAL_ megjeleníthető elem (megjelenítve: _START_ - _END_)",
                emptyTable: "- - -",
                paginate: {
                    first: "Első",
                    last: "Utolsó",
                    next: "Következő",
                    previous: "Előző"
                },
                search: "Keresés:",
                zeroRecords: "Nincs megjeleníthető elem"
            },
            rowCallback: function(row, data, displayNum, displayIndex, dataIndex) {
                widgettype.userList.bindOperationEvents(row);
            },
            scrollY: "100%",
            scrollX: true
        });
    }

    this.escapeAttribute = function(value)
    {
        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/"/g, "&quot;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;");
    }

    this.bindOperationEvents = function(in_element)
    {
        $(in_element).find(".operation-edit").on("click", function(e){
            window.location = _config.url_edit + '&item_id=' + $(this).data("id");
            e.preventDefault();
            return false;
        });

        $(in_element).find(".operation-datasheet").on("click", function(e){
            window.location = _config.url_datasheet + $(this).data("id") + '/';
            e.preventDefault();
            return false;
        });

        $(in_element).find(".operation-roles").on("click", function(e){
            window.location = _config.url_roles + $(this).data("id") + '/';
            e.preventDefault();
            return false;
        });

        $(in_element).find(".operation-usergroups").on("click", function(e){
            window.location = _config.url_usergroups + $(this).data("id") + '/';
            e.preventDefault();
            return false;
        });
    }

    this.init = function(config)
    {
        _config = config;
        this.bindEvents();
        this.initUserListTable();
    }
}
