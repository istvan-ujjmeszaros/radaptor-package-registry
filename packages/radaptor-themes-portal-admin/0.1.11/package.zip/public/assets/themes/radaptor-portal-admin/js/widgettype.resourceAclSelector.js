/**
 * Resource ACL Selector - DataTables 2.x version
 * Converted from CDN version (1.9.1 API) to work with DataTables 2.x
 */
if (typeof(widgettype) != "object")
    var widgettype = {};

widgettype.resourceAclSelector = new function()
{
    var _config = {};
    var _inheritedTable;
    var _specificTable;
    var _checkboxvalues = {};

    this.bindEvents = function()
    {
        $('#' + _config.checkbox_id).change(function() {
            widgettype.resourceAclSelector.updateInheritance();
        });
    }

    this.updateInheritance = function()
    {
        var checked = $('#' + _config.checkbox_id).is(':checked') ? 1 : 0;

        $.ajax({
            method: "get",
            url: _config.ajaxBaseUrl + "SetInheritance",
            data: { "inheritance": checked },
            dataType: "json",
            cache: false,
            complete: function()
            {
                if (typeof renderSystemMessages === 'function') renderSystemMessages();

                _inheritedTable.ajax.reload(function() {
                    if (checked)
                        widgettype.resourceAclSelector.showInherited();
                    else
                        widgettype.resourceAclSelector.hideInherited();
                });
            }
        });
    }

    this.hideInherited = function()
    {
        $('#acl-userselector-inherited').slideUp();
    }

    this.showInherited = function()
    {
        $('#acl-userselector-inherited').slideDown(null, function() {
            _inheritedTable.columns.adjust();
        });
    }

    this.initInheritedTable = function()
    {
        _inheritedTable = new DataTable("#" + _config.inheritedTableId, {
            ajax: {
                url: _config.ajaxBaseUrl + "SubjectList&type=inherited",
                dataSrc: function(payload) {
                    if (!payload || payload.ok !== true) {
                        return [];
                    }
                    return payload.data && payload.data.aaData ? payload.data.aaData : [];
                }
            },
            columns: [
                { searchable: true },
                { orderable: false, searchable: false, className: 'dt-center' },
                { orderable: false, searchable: false, className: 'dt-center' },
                { orderable: false, searchable: false, className: 'dt-center' },
                { orderable: false, searchable: false, className: 'dt-center' },
                { orderable: false, searchable: false, className: 'dt-center' }
            ],
            layout: {
                topStart: 'info',
                topEnd: { search: {}, pageLength: {} },
                bottomEnd: 'paging'
            },
            info: true,
            paging: true,
            processing: true,
            stateSave: false,
            language: {
                infoFiltered: "<br><i>sz\u0171rt eredm\u00e9ny _MAX_ adatsorb\u00f3l</i>",
                infoEmpty: "Nincs tal\u00e1lat",
                info: "_TOTAL_ megjelen\u00edthet\u0151 elem (megjelen\u00edtve: _START_ - _END_)",
                emptyTable: "- - -",
                paginate: {
                    first: "Els\u0151",
                    last: "Utols\u00f3",
                    next: "K\u00f6vetkez\u0151",
                    previous: "El\u0151z\u0151"
                },
                search: "Keres\u00e9s:",
                zeroRecords: "Nincs megjelen\u00edthet\u0151 elem"
            }
        });
    }

    this.initSpecificTable = function()
    {
        _specificTable = new DataTable("#" + _config.specificTableId, {
            ajax: {
                url: _config.ajaxBaseUrl + "SubjectList&type=specific",
                dataSrc: function(payload) {
                    if (!payload || payload.ok !== true) {
                        return [];
                    }
                    return payload.data && payload.data.aaData ? payload.data.aaData : [];
                }
            },
            columns: [
                { searchable: true },
                { orderable: false, searchable: false, className: 'dt-center' },
                { orderable: false, searchable: false, className: 'dt-center' },
                { orderable: false, searchable: false, className: 'dt-center' },
                { orderable: false, searchable: false, className: 'dt-center' },
                { orderable: false, searchable: false, className: 'dt-center' },
                {
                    orderable: false,
                    searchable: false,
                    render: function(data, type, row, meta) {
                        if (type !== 'display') return data;
                        // row[6] contains the acl_id
                        return '<a class="operation operation-delete" data-operation="deleteAcl" data-id="' + row[6] + '" href="#">' + _config.icon_trash + '</a>';
                    }
                }
            ],
            layout: {
                topStart: 'info',
                topEnd: { search: {}, pageLength: {} },
                bottomEnd: 'paging'
            },
            info: true,
            paging: true,
            processing: true,
            stateSave: false,
            language: {
                infoFiltered: "<br><i>sz\u0171rt eredm\u00e9ny _MAX_ adatsorb\u00f3l</i>",
                infoEmpty: "Nincs tal\u00e1lat",
                info: "_TOTAL_ megjelen\u00edthet\u0151 elem (megjelen\u00edtve: _START_ - _END_)",
                emptyTable: "- - -",
                paginate: {
                    first: "Els\u0151",
                    last: "Utols\u00f3",
                    next: "K\u00f6vetkez\u0151",
                    previous: "El\u0151z\u0151"
                },
                search: "Keres\u00e9s:",
                zeroRecords: "Nincs megjelen\u00edthet\u0151 elem"
            },
            drawCallback: function() {
                // Bind checkbox change events after each draw
                $('#' + _config.specificTableId + ' input[type="checkbox"]').off('change').on('change', function() {
                    widgettype.resourceAclSelector.saveOperationState(this);
                });
                // Bind operation link events
                widgettype.resourceAclSelector.bindOperationEvents($('#' + _config.specificTableId));
            }
        });

        // Add the new object selector input
        $("#" + _config.specificTableId + "_wrapper").prepend(
            '<div class="new-object-selector mb-3">' +
            '<label class="me-2">Új hozzárendelés:</label>' +
            '<input class="new-object-selector-input form-control d-inline-block" type="text" style="width: 300px;">' +
            '<a href="#" class="controller-menu btn btn-sm btn-primary ms-2">Hozzárendel</a>' +
            '</div>'
        );
    }

    this.saveOperationState = function(element)
    {
        var checked = $(element).is(':checked') ? 1 : 0;
        var data = $(element).data();

        if (_checkboxvalues[data.acl_id + data.operation] === checked)
            return;

        _checkboxvalues[data.acl_id + data.operation] = checked;

        $.ajax({
            method: "get",
            url: _config.ajaxBaseUrl + "SetOperation",
            data: {
                "checked": checked,
                "operation": data.operation,
                "acl_id": data.acl_id
            },
            dataType: "json",
            cache: false,
            complete: function()
            {
                _specificTable.ajax.reload();
                if (typeof renderSystemMessages === 'function') renderSystemMessages();
            }
        });
    }

    this.initObjectSelector = function()
    {
        function split(val) {
            return val.split(/,\s*/);
        }
        function extractLast(term) {
            return split(term).pop();
        }

        $(".new-object-selector-input")
            .bind("keydown", function(event) {
                if ((event.keyCode === $.ui.keyCode.TAB) && $(this).data("ui-autocomplete") && $(this).data("ui-autocomplete").menu.active)
                    event.preventDefault();
            })
            .bind("keyup", function(event) {
                if (event.keyCode !== $.ui.keyCode.ENTER) {
                    $(this).data("object_type", "unknown");
                    $(this).data("object_name", $(this).val().trim());
                }
            })
            .autocomplete({
                source: function(request, response) {
                    $.getJSON(_config.ajaxBaseUrl + "ObjectListAutocomplete", {
                        term: extractLast(request.term)
                    }, response);
                },
                search: function() {
                    var term = extractLast(this.value);
                },
                focus: function() {
                    return false;
                },
                select: function(event, ui) {
                    var input = $(".new-object-selector-input");
                    var objectName = ui.item.object_name;
                    // Strip HTML tags
                    if (typeof stripTags === 'function') {
                        objectName = stripTags(objectName);
                    } else {
                        objectName = objectName.replace(/<[^>]*>/g, '');
                    }
                    $(input).val(objectName);
                    $(input).data("object_type", ui.item.object_type);
                    $(input).data("object_name", ui.item.object_name);
                    return false;
                }
            });

        // Custom render for autocomplete items
        var autocomplete = $(".new-object-selector-input").data("ui-autocomplete");
        if (autocomplete) {
            autocomplete._renderItem = function(ul, item) {
                var searchTerm = $.ui.autocomplete.escapeRegex($.trim(this.term));
                item.label = item.object_name.replace(
                    new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + searchTerm + ")(?![^<>]*>)(?![^&;]+;)", "gi"),
                    "<strong>$1</strong>"
                );

                var visible_label;
                if (item.object_type == "user")
                    visible_label = "<a>" + _config.icon_user + item.label + "</a>";
                else if (item.object_type == "usergroup")
                    visible_label = "<a>" + _config.icon_usergroup + item.label + "</a>";
                else
                    visible_label = "<a>" + item.label + "</a>";

                return $("<li></li>")
                    .data("item.autocomplete", item)
                    .append(visible_label)
                    .appendTo(ul);
            };
        }

        // Bind the "Hozzárendel" button
        $(document).on("click", "a.controller-menu", function(e) {
            e.preventDefault();

            var input = $(".new-object-selector-input");

            if ($(input).val().trim() === "")
                return false;

            var object_type = $(input).data("object_type") || "unknown";
            var object_name = $(input).data("object_name") || $(input).val().trim();

            $.ajax({
                method: "get",
                url: _config.ajaxBaseUrl + "AddObject",
                data: {
                    "object_type": object_type,
                    "object_name": object_name
                },
                dataType: "json",
                cache: false,
                success: function(r) {
                    if (r && r.ok === true) {
                        $(input).val("");
                        $(input).removeData();
                    }
                },
                complete: function() {
                    _specificTable.ajax.reload();
                    if (typeof renderSystemMessages === 'function') renderSystemMessages();
                }
            });

            return false;
        });
    }

    this.bindOperationEvents = function(in_element)
    {
        $(in_element).find(".operation").off("click").on("click", function(e) {
            e.preventDefault();

            var acl_id = $(this).data("id");
            var operation = $(this).data("operation");
            operation = operation.charAt(0).toUpperCase() + operation.slice(1);

            $.ajax({
                method: "get",
                url: _config.ajaxBaseUrl + operation,
                data: { "acl_id": acl_id },
                dataType: "json",
                cache: false,
                complete: function() {
                    _specificTable.ajax.reload();
                    if (typeof renderSystemMessages === 'function') renderSystemMessages();
                }
            });

            return false;
        });
    }

    this.init = function(config)
    {
        _config = config;

        this.bindEvents();
        this.initInheritedTable();

        if (!$('#' + _config.checkbox_id).is(':checked'))
            $('#acl-userselector-inherited').hide();

        this.initSpecificTable();
        this.initObjectSelector();
    }
}
