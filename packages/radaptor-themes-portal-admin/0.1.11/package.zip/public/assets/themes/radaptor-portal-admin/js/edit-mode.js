(function () {
	'use strict';

	if (window.__radaptorPortalAdminEditModeDropdownsInitialized) {
		return;
	}

	window.__radaptorPortalAdminEditModeDropdownsInitialized = true;

	var dropdownSelector = '[data-widget-insert-dropdown]';
	var initialized = new WeakSet();
	var observerStarted = false;

	function closeDropdown(dropdown) {
		var button = dropdown.querySelector('[data-widget-insert-toggle]');

		dropdown.classList.remove('is-open');

		if (button) {
			button.setAttribute('aria-expanded', 'false');
		}
	}

	function closeAllDropdowns(except) {
		document.querySelectorAll(dropdownSelector + '.is-open').forEach(function (dropdown) {
			if (dropdown !== except) {
				closeDropdown(dropdown);
			}
		});
	}

	function openDropdown(dropdown) {
		var button = dropdown.querySelector('[data-widget-insert-toggle]');

		closeAllDropdowns(dropdown);
		dropdown.classList.add('is-open');

		if (button) {
			button.setAttribute('aria-expanded', 'true');
		}
	}

	function toggleDropdown(event) {
		event.preventDefault();
		event.stopPropagation();

		var dropdown = event.currentTarget.closest(dropdownSelector);

		if (!dropdown) {
			return;
		}

		if (dropdown.classList.contains('is-open')) {
			closeDropdown(dropdown);
			return;
		}

		openDropdown(dropdown);
	}

	function initDropdown(dropdown) {
		var button = dropdown.querySelector('[data-widget-insert-toggle]');

		if (!button || initialized.has(dropdown)) {
			return;
		}

		button.addEventListener('click', toggleDropdown);
		initialized.add(dropdown);
	}

	function initDropdowns(root) {
		var scope = root && root.querySelectorAll ? root : document;

		scope.querySelectorAll(dropdownSelector).forEach(initDropdown);

		if (scope.matches && scope.matches(dropdownSelector)) {
			initDropdown(scope);
		}
	}

	function startObserver() {
		if (observerStarted || !document.documentElement) {
			return;
		}

		observerStarted = true;

		new MutationObserver(function (mutations) {
			mutations.forEach(function (mutation) {
				mutation.addedNodes.forEach(function (node) {
					if (node.nodeType === Node.ELEMENT_NODE) {
						initDropdowns(node);
					}
				});
			});
		}).observe(document.documentElement, { childList: true, subtree: true });
	}

	document.addEventListener('click', function (event) {
		if (!event.target.closest(dropdownSelector)) {
			closeAllDropdowns();
		}
	});

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape') {
			closeAllDropdowns();
		}
	});

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () {
			initDropdowns(document);
			startObserver();
		});
	} else {
		initDropdowns(document);
		startObserver();
	}
}());
