# Radaptor Portal Admin Theme

`radaptor/themes/portal-admin` provides the Bootstrap 5 based admin theme
(`RadaptorPortalAdmin`) for Radaptor CMS layouts and widgets.
It contains theme templates, layout wrappers, JS/CSS asset wiring, and admin UI styling.

## Installation

Use through a registry-first consumer app:

- [`radaptor-app`](https://github.com/istvan-ujjmeszaros/radaptor-app)
- [`radaptor-portal`](https://github.com/istvan-ujjmeszaros/radaptor-portal)

The theme is resolved from package metadata; no manual copy step is required.

## Dependencies

From `.registry-package.json`:

- `radaptor/core/cms` (`^0.1.17`)

## Development and Release

Maintain this theme in `/apps/_RADAPTOR/packages-dev/themes/portal-admin`, not inside a consumer
app's `packages/registry/...` runtime copy. Validate through a consumer app `php` container; do not
run host PHP, Composer, PHPUnit, PHPStan, or PHP-CS-Fixer.

Release key:

- `theme:portal-admin`

Normal flow: package PR, `@codex review`, clean repo checks, squash merge, fast-forward local
`main`, `package:release theme:portal-admin`, commit the `.registry-package.json` version bump,
then publish the generated artifact through `radaptor_plugin_registry`.

Asset links are declared in `.registry-package.json` under `assets.public` and are created by
`build:assets` under the consumer app's `public/www/assets/packages/...`. Do not manually copy or
symlink theme assets into app runtime paths.

## License

This package is distributed under the proprietary evaluation license in
[LICENSE](./LICENSE).
Evaluation-only: no production/commercial/distribution/derivative use without
a separate license agreement.

## Contact

istvan@radaptor.com
