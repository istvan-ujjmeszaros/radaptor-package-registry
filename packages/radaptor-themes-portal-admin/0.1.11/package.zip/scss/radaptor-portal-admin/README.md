# RadaptorPortalAdmin SCSS

This is the SCSS entry point for the RadaptorPortalAdmin theme.

## Build

The CSS is built using Dart Sass. Run from inside the PHP container:

```bash
sass /app/scss/radaptor-portal-admin/main.scss \
     /package-working-repos/themes/portal-admin/public/assets/themes/radaptor-portal-admin/css/radaptor-portal-admin.css \
     --style=compressed --no-source-map \
     --load-path=/app/vendor/twbs/bootstrap-5.3.3
```

Or use the build script:

```bash
/app/docker/build-theme-css.sh
```

## Architecture

This file only imports from:
- Bootstrap 5 (from vendor directory)
- Shared SCSS (from workspace level `/apps/_RADAPTOR/shared-scss/`)

All component styles are defined in the shared-scss directory to maintain synchronization with radaptor-portal.

## Dependencies

- Bootstrap 5.3.3 (SCSS source)
- Dart Sass (standalone binary, no Node.js)
