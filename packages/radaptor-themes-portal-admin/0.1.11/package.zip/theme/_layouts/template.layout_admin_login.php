<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->registerLibrary('__RADAPTOR_PORTAL_ADMIN_SITE'); ?>
<?php
$lang = (string)($this->props['lang'] ?? substr(Kernel::getLocale(), 0, 2));
$site_name = (string)($this->props['site_name'] ?? Config::APP_SITE_NAME->value());
$document_title = (string)($this->props['document_title'] ?? $site_name);
?>
<!DOCTYPE html>
<html lang="<?= e($lang) ?>" data-bs-theme="dark">
<head>
	<meta charset="utf-8">
	<title><?= e($document_title) ?></title>
	<meta name="robots" content="NOINDEX, NOFOLLOW">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="/favicon.ico">
	<link rel="icon" href="/favicon.ico" type="image/x-icon">
	<?= $this->getRenderer()->getLibraryDebugInfo(); ?>
	<?= $this->getRenderer()->getCss(); ?>
	<?= $this->getRenderer()->getJsTop(); ?>
</head>
<body class="admin-layout">
<?= $this->getRenderer()->fetchInnerHtml(); ?>
<main class="min-vh-100 d-flex align-items-center p-3 p-lg-4">
	<div class="w-100">
		<?= $this->fetchContent('content'); ?>
	</div>
</main>
<div class="flash-messages" id="flash-messages"></div>
<?= $this->fetchContent('page_chrome'); ?>
<?= $this->getRenderer()->getJs(); ?>
<script>
	if (typeof renderSystemMessages === 'function') {
		renderSystemMessages();
	}
</script>
<?= $this->getRenderer()->fetchClosingHtml(); ?>
</body>
</html>
