<?php assert(isset($this) && $this instanceof Template); ?>
<div class="col-12" data-controller="codemirror">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label" for="<?= e((string)$this->props['id']) ?>"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
	<div data-codemirror-target="editor" class="border rounded" style="min-height: 300px;"></div>
	<textarea class="d-none" data-codemirror-target="textarea" id="<?= e((string)$this->props['id']) ?>" name="<?= e((string)$this->props['name']) ?>"><?= e((string)($this->props['value'] ?? '')) ?></textarea>
	<?= $this->fetchContent('helper') ?>
</div>
