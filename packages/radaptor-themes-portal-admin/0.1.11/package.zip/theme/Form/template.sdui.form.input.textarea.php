<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$readonly = (bool)($this->props['readonly'] ?? false);
$has_errors = !empty($this->props['errors'] ?? []);
?>
<div class="col-12">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label" for="<?= e((string)$this->props['id']) ?>"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
	<textarea class="form-control<?= $has_errors ? ' is-invalid' : '' ?>" id="<?= e((string)$this->props['id']) ?>"<?= (string)($this->props['input_style_attr'] ?? '') ?> name="<?= e((string)$this->props['name']) ?>" rows="6"<?= $readonly ? ' readonly="readonly" tabindex="-1"' : '' ?>><?= e((string)($this->props['value'] ?? '')) ?></textarea>
	<?= $this->fetchContent('helper') ?>
</div>
