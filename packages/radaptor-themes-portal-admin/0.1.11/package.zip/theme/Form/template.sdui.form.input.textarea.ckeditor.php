<?php assert(isset($this) && $this instanceof Template); ?>
<?php
if (Config::DEV_APP_DEBUG_INFO->value() && Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER)) {
	$this->registerLibrary('CKEDITOR_SOURCE');
} else {
	$this->registerLibrary('CKEDITOR');
}
?>
<div class="col-12">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label" for="<?= e((string)$this->props['id']) ?>"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
	<textarea class="form-control<?= !empty($this->props['errors'] ?? []) ? ' is-invalid' : '' ?>" id="<?= e((string)$this->props['id']) ?>" name="<?= e((string)$this->props['name']) ?>" data-controller="ckeditor"><?= e((string)($this->props['value'] ?? '')) ?></textarea>
	<?= $this->fetchContent('helper') ?>
</div>
