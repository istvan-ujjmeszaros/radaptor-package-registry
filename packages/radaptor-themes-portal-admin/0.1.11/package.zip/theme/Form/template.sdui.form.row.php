<?php assert(isset($this) && $this instanceof Template); ?>
<div id="<?= e((string)($this->props['row_id'] ?? '')) ?>" class="row g-3 mb-1">
	<?= $this->fetchContent('content') ?>
</div>
