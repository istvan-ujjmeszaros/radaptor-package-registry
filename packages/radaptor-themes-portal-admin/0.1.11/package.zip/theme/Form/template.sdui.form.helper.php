<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$error_string = trim((string)($this->props['error_string'] ?? ''));
$info_string = trim((string)($this->props['info_string'] ?? ''));
$normalize_breaks = static function (string $message): string {
	return str_replace(["<br />", "<br/>", "<br>"], "\n", $message);
};
?>
<?php if ($error_string !== ''): ?>
	<div class="invalid-feedback d-block"><?= nl2br(e($normalize_breaks($error_string))) ?></div>
<?php elseif ($info_string !== ''): ?>
	<div class="form-text"><?= nl2br(e($normalize_breaks($info_string))) ?></div>
<?php endif; ?>
