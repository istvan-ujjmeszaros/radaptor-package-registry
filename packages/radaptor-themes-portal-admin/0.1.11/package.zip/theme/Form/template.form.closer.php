<!DOCTYPE html>
<html>
<head>
		<title><?= e(t('form.closer.title')) ?></title>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="/favicon.ico">
</head>
<body>
<script>window.close();</script>
<div class="alert alert-warning m-3">
		<strong><?= e(t('form.closer.close_window')) ?></strong>
</div>
</body>
</html>
