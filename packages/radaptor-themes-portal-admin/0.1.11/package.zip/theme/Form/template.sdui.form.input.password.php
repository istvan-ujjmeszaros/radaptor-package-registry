<?php assert(isset($this) && $this instanceof Template); ?>
<?php $has_errors = !empty($this->props['errors'] ?? []); ?>
<div class="col">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label" for="<?= e((string)$this->props['id']) ?>"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
	<input class="form-control<?= $has_errors ? ' is-invalid' : '' ?>" id="<?= e((string)$this->props['id']) ?>"<?= (string)($this->props['input_style_attr'] ?? '') ?> type="password" name="<?= e((string)$this->props['name']) ?>" value="">
	<?= $this->fetchContent('helper') ?>
</div>
