<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$field_refs = is_array($this->props['field_refs'] ?? null) ? $this->props['field_refs'] : [];
$html_attributes = is_array($this->props['html_attributes'] ?? null) ? $this->props['html_attributes'] : [];
$internal_link_type = 'belso';
$controllers = trim((string)($html_attributes['data-controller'] ?? 'form-timezone') . ' menu-link-type');
$html_attributes['data-controller'] = implode(' ', array_values(array_unique(array_filter(explode(' ', $controllers)))));
$html_attributes['data-menu-link-type-input-name-value'] = (string)($field_refs['type']['name'] ?? '');
$html_attributes['data-menu-link-type-url-row-id-value'] = (string)($field_refs['url']['row_id'] ?? '');
$html_attributes['data-menu-link-type-page-row-id-value'] = (string)($field_refs['page_id']['row_id'] ?? '');
$html_attributes['data-menu-link-type-internal-value'] = $internal_link_type;

$template = new Template('sdui.form', $this->getRenderer(), $this->getWidgetConnection());
$template->props = array_replace($this->props, [
	'html_attributes' => $html_attributes,
]);
$template->setContents([
	'hidden_fields' => $this->fetchContent('hidden_fields'),
	'rows' => $this->fetchContent('rows'),
]);
?>
<?= $template->fetch() ?>
