<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$ids = $this->props['id'];
$idsParam = implode(',', $ids);
?>

<h3 class="mb-3"><?= e($this->strings['selection.group']) ?></h3>

<div class="d-grid gap-2">
	<button class="btn btn-outline-danger btn-sm text-start" type="button"
		hx-get="<?= Url::getAjaxUrl('Jstree.adminMenuAjaxDeleteRecursive', ['id' => $idsParam, 'jstree_id' => $this->props['jstree_id']]); ?>"
		hx-confirm="<?= e($this->strings['selection.delete_selected_confirm']) ?>"
		hx-swap="none">
		<i class="bi bi-trash me-2"></i><?= e($this->strings['selection.delete_selected']) ?>
	</button>
</div>

<hr class="my-3 opacity-25">

<h4 class="h6"><?= e($this->strings['selection.selected_items']) ?>:</h4>

<ul class="list-unstyled small">
	<?php foreach ($this->props['selected_items'] as $item): ?>
		<li class="mb-2">
			<i class="bi bi-list me-1"></i>
			<strong><?= htmlspecialchars($item['title'], ENT_QUOTES); ?></strong>
			<br>
			<span class="text-muted ms-3"><?= htmlspecialchars($item['url'], ENT_QUOTES); ?></span>
		</li>
	<?php endforeach; ?>
</ul>
