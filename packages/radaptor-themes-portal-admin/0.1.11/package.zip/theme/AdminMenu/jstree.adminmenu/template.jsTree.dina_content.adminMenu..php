<?php assert(isset($this) && $this instanceof Template); ?>
<?php $id = $this->props['id'][0] ?? $this->props['id']; ?>

<h3 class="mb-3 text-warning"><?= e($this->strings['selection.invalid_entry']) ?></h3>

<div class="d-grid gap-2">
	<button class="btn btn-outline-danger btn-sm text-start" type="button"
		hx-get="<?= Url::getAjaxUrl('Jstree.adminMenuAjaxDeleteRecursive', ['id' => $id, 'jstree_id' => $this->props['jstree_id']]); ?>"
		hx-confirm="<?= e($this->strings['selection.delete_invalid_entry_confirm']) ?>"
		hx-swap="none">
		<i class="bi bi-trash me-2"></i><?= e($this->strings['common.delete']) ?>
	</button>
</div>
