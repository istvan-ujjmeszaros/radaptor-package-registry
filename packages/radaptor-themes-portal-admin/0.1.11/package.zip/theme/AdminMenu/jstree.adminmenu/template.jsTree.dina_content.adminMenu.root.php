<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$adminmenu = $this->props['data'][0] ?? false;
$refId = is_array($adminmenu) ? $adminmenu['node_id'] : 0;
$title = is_array($adminmenu) ? $adminmenu['node_name'] : $this->strings['admin.menu.admin_menu'];
?>

<h3 class="mb-3"><?= htmlspecialchars($title, ENT_QUOTES); ?></h3>

<div class="d-grid gap-2">
	<a href="<?= form_url(FormList::ADMINMENUMENUELEMENT, null, null, ['ref_id' => $refId]); ?>" class="btn btn-outline-primary btn-sm text-start">
		<i class="bi bi-plus-lg me-2"></i><?= e($this->strings['cms.menu.new_item']) ?>
	</a>
</div>

<hr class="my-3 opacity-25">

<p class="text-muted small">
	<i class="bi bi-info-circle me-1"></i>
	<?= e($this->strings['cms.menu.selection_help']) ?>
</p>
