<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$adminmenu = $this->props['data'][0] ?? false;

if (!is_array($adminmenu)) {
	return true;
}

$nodeId = $adminmenu['node_id'];
$hasLink = $adminmenu['has_link'];
?>

<h3 class="mb-3"><?= htmlspecialchars($adminmenu['node_name'], ENT_QUOTES); ?></h3>

<div class="d-grid gap-2">
	<?php if ($hasLink): ?>
		<a href="<?= htmlspecialchars($adminmenu['url'], ENT_QUOTES); ?>" target="_blank" class="btn btn-outline-secondary btn-sm text-start">
			<i class="bi bi-box-arrow-up-right me-2"></i><?= e($this->strings['common.preview']) ?>
		</a>
	<?php else: ?>
		<button class="btn btn-outline-secondary btn-sm text-start" disabled>
			<i class="bi bi-box-arrow-up-right me-2"></i><?= e($this->strings['common.preview']) ?>
		</button>
	<?php endif; ?>

	<a href="<?= form_url(FormList::ADMINMENUMENUELEMENT, $nodeId); ?>" class="btn btn-outline-secondary btn-sm text-start">
		<i class="bi bi-pencil me-2"></i><?= e($this->strings['common.edit']) ?>
	</a>

	<button class="btn btn-outline-danger btn-sm text-start" type="button"
		hx-get="<?= Url::getAjaxUrl('Jstree.adminMenuAjaxDeleteRecursive', ['id' => $nodeId, 'jstree_id' => $this->props['jstree_id']]); ?>"
		hx-confirm="<?= e($this->strings['cms.menu.delete_confirm']) ?>"
		hx-swap="none">
		<i class="bi bi-trash me-2"></i><?= e($this->strings['common.delete']) ?>
	</button>

	<a href="<?= form_url(FormList::ADMINMENUMENUELEMENT, null, null, ['ref_id' => $nodeId]); ?>" class="btn btn-outline-primary btn-sm text-start">
		<i class="bi bi-plus-lg me-2"></i><?= e($this->strings['cms.menu.new_child']) ?>
	</a>
</div>

<hr class="my-3 opacity-25">

<?php if ($adminmenu['is_external']): ?>
	<h4 class="h6"><?= e($this->strings['cms.menu.external_link']) ?></h4>
	<p class="text-muted small"><?= htmlspecialchars($adminmenu['url'], ENT_QUOTES); ?></p>
<?php elseif (is_null($adminmenu['page_id'])): ?>
	<h4 class="h6 text-danger"><?= e($this->strings['cms.menu.no_link_configured']) ?></h4>
<?php else: ?>
	<h4 class="h6"><?= e($this->strings['cms.menu.internal_link']) ?></h4>
	<p class="text-muted small"><?= htmlspecialchars($adminmenu['internal_url'], ENT_QUOTES); ?></p>
<?php endif; ?>
