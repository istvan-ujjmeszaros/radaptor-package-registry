<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->setDebugType(TemplateDebugType::DEBUG_HTML); ?>
<?php
/**
 * Admin Menu Tree using jsTree 3.3.17 + Stimulus Controller.
 *
 * Features:
 * - State persistence via localStorage (state plugin)
 * - Lazy-loading children via AJAX
 * - Drag-drop for reordering
 * - Stimulus controller handles all JS behavior
 *
 * Props:
 * - jstree_id: Widget instance ID
 */
$this->registerLibrary('__ADMIN_ADMINMENU');

$jstreeId = $this->props['jstree_id'];
$pageId = (string) $this->getPageId();

// Build URLs for the Stimulus controller
$ajaxUrl = Url::getAjaxUrl('jstree.adminMenuAjaxLoad');
$moveUrl = Url::getAjaxUrl('jstree.adminMenuAjaxMove');
$detailUrl = Url::getAjaxUrl('jstree.adminMenuAjaxDinaContent');
$deleteUrl = Url::getAjaxUrl('jstree.adminMenuAjaxDeleteRecursive');
?>

<div class="adminmenu-browser">
	<div class="row g-3">
		<!-- Detail Panel (Left) -->
		<div class="col-md-5 col-lg-4">
			<div class="adminmenu-detail-panel" id="dina_content<?= htmlspecialchars($jstreeId, ENT_QUOTES); ?>">
				<div class="text-muted small p-3">
					<i class="bi bi-arrow-left-circle me-2"></i><?= e($this->strings['cms.tree.select_menu_item']) ?>
				</div>
			</div>
		</div>

		<!-- Tree Panel (Right) -->
		<div class="col-md-7 col-lg-8">
			<div class="adminmenu-tree-panel">
				<div data-controller="jstree-adminmenu"
					 data-jstree-adminmenu-jstree-id-value="<?= htmlspecialchars($jstreeId, ENT_QUOTES); ?>"
					 data-jstree-adminmenu-page-id-value="<?= htmlspecialchars($pageId, ENT_QUOTES); ?>"
					 data-jstree-adminmenu-ajax-url-value="<?= htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>"
					 data-jstree-adminmenu-move-url-value="<?= htmlspecialchars($moveUrl, ENT_QUOTES); ?>"
					 data-jstree-adminmenu-detail-url-value="<?= htmlspecialchars($detailUrl, ENT_QUOTES); ?>"
					 data-jstree-adminmenu-delete-url-value="<?= htmlspecialchars($deleteUrl, ENT_QUOTES); ?>">
					<!-- jsTree will render here -->
				</div>
			</div>
		</div>
	</div>
</div>
