<?php assert(isset($this) && $this instanceof Template); ?>
<?php if (!empty($this->props['menuData'])): ?>
<ul class="nav flex-column sidebar-menu sidebar-menu-custom mt-3">
	<li class="nav-item sidebar-section-title">
		<small class="text-muted text-uppercase px-3"><?= e((string)($this->props['custom_menu_label'] ?? '')) ?></small>
	</li>
	<?php foreach ($this->props['menuData'] as $menu): ?>
	<?php if ($menu['node_type'] === 'root') {
		continue;
	} ?>
	<li class="nav-item">
		<a class="nav-link<?php if ($menu['is_active']): ?> active<?php endif; ?>" href="<?= htmlspecialchars($menu['href']); ?>">
			<span><?= htmlspecialchars($menu['node_name']); ?></span>
		</a>
	</li>
	<?php endforeach; ?>
</ul>
<?php endif; ?>
