<?php assert(isset($this) && $this instanceof Template); ?>
<?php if (User::getCurrentUserUsername()): ?>
<?php
	$available_locales = is_array($this->props['available_locales'] ?? null) ? $this->props['available_locales'] : [];
	$current_locale = (string)($this->props['current_locale'] ?? Kernel::getLocale());
	$current_locale_label = (string)($this->props['current_locale_label'] ?? LocaleRegistry::getDisplayLabel($current_locale));
	$locale_update_url = (string)($this->props['locale_update_url'] ?? Url::getUrl('user.set-locale', [
		'referer' => Url::getCurrentUrlForReferer(),
	]));
	?>
<div class="sidebar-footer">
	<div class="sidebar-user-dropdown" data-controller="dropdown">
		<button type="button" class="user-menu-toggle" data-action="click->dropdown#toggle">
			<span class="user-avatar-icon">
				<i class="bi bi-person-circle"></i>
			</span>
			<span class="user-menu-name"><?= htmlspecialchars(User::getCurrentUserUsername()); ?></span>
			<i class="bi bi-chevron-up dropdown-arrow"></i>
		</button>
		<div class="user-dropdown-menu" data-dropdown-target="menu">
			<?php if (count($available_locales) > 1): ?>
				<div class="user-dropdown-section">
					<div class="user-dropdown-label">
						<i class="bi bi-globe2 me-2"></i>
						<span><?= e($this->strings['user.locale.menu_label']) ?></span>
					</div>
					<div class="user-dropdown-current">
						<?= e($this->strings['user.locale.current_label']) ?>:
						<span><?= e($current_locale_label) ?></span>
					</div>
					<?php foreach ($available_locales as $locale): ?>
						<?php
							$locale_code = (string)($locale['value'] ?? '');
						$locale_label = (string)($locale['label'] ?? $locale_code);

						if ($locale_code === '') {
							continue;
						}
						?>
						<form method="post" action="<?= e($locale_update_url) ?>" class="user-locale-form">
							<input type="hidden" name="locale" value="<?= e($locale_code) ?>">
							<button
								type="submit"
								class="user-dropdown-item user-locale-option<?= $locale_code === $current_locale ? ' active' : '' ?>"
								<?= $locale_code === $current_locale ? 'aria-current="true"' : '' ?>
							>
								<span><?= e($locale_label) ?></span>
								<?php if ($locale_code === $current_locale): ?>
									<i class="bi bi-check2 ms-auto"></i>
								<?php endif; ?>
							</button>
						</form>
					<?php endforeach; ?>
				</div>
				<div class="user-dropdown-divider"></div>
			<?php endif; ?>
			<a href="<?= modify_url([
				'context' => 'user',
				'event' => 'logout',
				'referer' => Url::getCurrentUrlForReferer(),
			]); ?>" class="user-dropdown-item">
					<i class="bi bi-box-arrow-right me-2"></i>
					<?= e($this->strings['common.logout']) ?>
				</a>
			</div>
		</div>
</div>
<?php endif; ?>
