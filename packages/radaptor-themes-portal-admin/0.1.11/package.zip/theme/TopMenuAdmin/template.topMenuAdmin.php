<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$current_username = (string)($this->props['current_username'] ?? '');
$auth_url = (string)($this->props['auth_url'] ?? '');
$auth_label = (string)($this->props['auth_label'] ?? '');
?>
<div class="d-flex align-items-center gap-3">
	<?php if ($current_username === ''): ?>
		<a href="<?= e($auth_url) ?>" class="btn btn-outline-light btn-sm">
			<i class="bi bi-box-arrow-in-right me-1"></i>
			<span class="d-none d-sm-inline"><?= e($auth_label) ?></span>
		</a>
	<?php endif; ?>
</div>
