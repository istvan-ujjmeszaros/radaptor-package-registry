<?php

class ThemeDataRadaptorPortalAdmin extends AbstractThemeData
{
	public const string ID = 'radaptor_portal_admin';
	public const string SLUG = 'radaptor-portal-admin';
	public const string LIBRARIESCLASSNAME = 'LibrariesRadaptorPortalAdmin';

	public static function getName(): string
	{
		return t('theme.' . self::ID . '.name');
	}

	public static function getDescription(): string
	{
		return t('theme.' . self::ID . '.description');
	}

	public static function getSlug(): string
	{
		return self::SLUG;
	}

	public static function getListVisibility(): bool
	{
		return Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER);
	}

	public static function getLibrariesClassName(): string
	{
		return self::LIBRARIESCLASSNAME;
	}

	/**
	 * Use Bootstrap Icons as the default icon library.
	 */
	public static function getIconLibrary(): string
	{
		return 'Bootstrap';
	}
}
