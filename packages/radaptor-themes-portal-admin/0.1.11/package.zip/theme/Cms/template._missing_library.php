<?php assert(isset($this) && $this instanceof Template); ?>
<div style="background-color:yellow; padding: 10px; margin: 5px; border: 1px solid orange;">
	<strong><?= e($this->strings['cms.library.unknown']) ?>:</strong> <?= htmlspecialchars((string)($this->props['library_name'] ?? '')); ?><br>
	<small>
		<strong><?= e($this->strings['cms.library.folder']) ?>:</strong> <?= htmlspecialchars((string)($this->props['folder'] ?? $this->strings['common.not_set'])); ?><br>
		<strong><?= e($this->strings['cms.library.resource']) ?>:</strong> <?= htmlspecialchars((string)($this->props['resource'] ?? $this->strings['common.not_set'])); ?>
	</small>
</div>
