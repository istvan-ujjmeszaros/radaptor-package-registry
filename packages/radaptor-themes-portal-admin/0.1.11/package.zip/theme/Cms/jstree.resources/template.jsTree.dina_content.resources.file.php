<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$nodeData = $this->props['data'][0];
$nodeId = $nodeData['node_id'];
$title = ($nodeData['title'] ?? '') === '' ? $nodeData['resource_name'] : $nodeData['title'];
?>
<h6 class="mb-3">
	<i class="bi bi-file-earmark me-2"></i><?= htmlspecialchars($title, ENT_QUOTES); ?>
</h6>

<?php if (ResourceTypeFile::isImage($nodeId)): ?>
	<div class="thumbnail-holder mb-3">
		<img src="<?= event_url('resource.view', [
			'folder' => $nodeData['path'],
			'resource' => PredefinedImageHandler::rewriteFileName($nodeData['resource_name'], 'admin_thumbnail'),
			'domain_context' => ResourceTypeRoot::getDomainContextForResource($nodeId),
		]); ?>" alt="<?= htmlspecialchars($nodeData['resource_name'], ENT_QUOTES); ?>" title="<?= htmlspecialchars($nodeData['resource_name'], ENT_QUOTES); ?>" class="img-thumbnail bg-dark">
	</div>
<?php endif; ?>

<div class="d-grid gap-2">

	<?= $this->fetchContent('insert_button'); ?>

	<?php if (ResourceAcl::canAccessResource($nodeId, ResourceAcl::_ACL_VIEW)): ?>
		<a href="<?= event_url('resource.view', [
			'folder' => $nodeData['path'],
			'resource' => $nodeData['resource_name'],
			'domain_context' => ResourceTypeRoot::getDomainContextForResource($nodeId),
		]); ?>" target="_blank" class="btn btn-outline-secondary btn-sm text-start">
			<i class="bi bi-eye me-2"></i><?= e($this->strings['common.preview']) ?>
		</a>
		<a href="<?= event_url('resource.view', [
			'folder' => $nodeData['path'],
			'resource' => $nodeData['resource_name'],
			'download' => 1,
		]); ?>" class="btn btn-outline-secondary btn-sm text-start">
			<i class="bi bi-download me-2"></i><?= e($this->strings['common.download']) ?>
		</a>
	<?php endif; ?>

	<?php if (ResourceAcl::canAccessResource($nodeId, ResourceAcl::_ACL_EDIT)): ?>
		<a href="<?= form_url(FormList::WEBPAGEFILE, $nodeId); ?>" class="btn btn-outline-secondary btn-sm text-start">
			<i class="bi bi-gear me-2"></i><?= e($this->strings['resource.properties']) ?>
		</a>
	<?php endif; ?>

	<?php if (ResourceAcl::canAccessResource($nodeId, ResourceAcl::_ACL_DELETE)): ?>
		<button class="btn btn-outline-danger btn-sm text-start" type="button"
			hx-get="<?= ajax_url('Jstree.resourcesAjaxDeleteRecursive', ['id' => $nodeId, 'jstree_id' => $this->props['jstree_id']]); ?>"
			hx-confirm="<?= e($this->strings['cms.resource_browser.delete_file_confirm']) ?>"
			hx-swap="none">
			<i class="bi bi-trash me-2"></i><?= e($this->strings['common.delete']) ?>
		</button>
	<?php endif; ?>

	<?php if (ResourceAcl::canAccessResource(ResourceTreeHandler::getFolderId($nodeId), ResourceAcl::_ACL_CREATE)): ?>
		<a href="<?= widget_url(WidgetList::FILEUPLOAD) . '?ref_id=' . ResourceTreeHandler::getFolderId($nodeId); ?>" class="btn btn-outline-primary btn-sm text-start">
			<i class="bi bi-upload me-2"></i><?= e($this->strings['resource.upload_file']) ?>
		</a>
	<?php endif; ?>

	<?php if (Roles::hasRole(RoleList::ROLE_ACL_VIEWER) || Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER)): ?>
		<a href="<?= widget_url(WidgetList::RESOURCEACLSELECTOR) . 'resource--' . $nodeId; ?>" class="btn btn-outline-secondary btn-sm text-start">
			<i class="bi bi-shield-lock me-2"></i><?= e($this->strings['resource.security']) ?>
		</a>
	<?php endif; ?>

</div>

<hr class="my-3 opacity-25">

<?= $this->fetchContent('help'); ?>
