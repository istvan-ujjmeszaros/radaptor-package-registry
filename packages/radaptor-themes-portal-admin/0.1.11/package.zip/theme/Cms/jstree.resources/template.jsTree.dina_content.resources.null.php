<?php assert(isset($this) && $this instanceof Template); ?>
<?php $nodeId = $this->props['id'][0]; ?>
<h6 class="mb-3 text-danger">
	<i class="bi bi-exclamation-octagon me-2"></i><?= e($this->strings['cms.resource_browser.invalid_entry']) ?>
</h6>

<div class="d-grid gap-2">

	<button class="btn btn-outline-danger btn-sm text-start" type="button"
		hx-get="<?= ajax_url('Jstree.resourcesAjaxDeleteRecursive', ['id' => $nodeId, 'jstree_id' => $this->props['jstree_id']]); ?>"
		hx-confirm="<?= e($this->strings['cms.resource_browser.delete_invalid_confirm']) ?>"
		hx-swap="none">
		<i class="bi bi-trash me-2"></i><?= e($this->strings['common.delete']) ?>
	</button>

</div>
