<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->setDebugType(TemplateDebugType::DEBUG_HTML); ?>
<?php
$this->registerLibrary('__ADMIN_RESOURCES');

$jstreeId = $this->props['jstree_id'];
$pageId = (string) $this->getPageId();
$ajaxUrl = Url::getAjaxUrl("jstree.resourcesAjax", ["CKEditor" => Request::_GET("CKEditor")]);
?>
<?php if (Roles::hasRole(RoleList::ROLE_DOMAINS_ADMIN)): ?>
	<a href="<?= form_url(FormList::WEBPAGEDOMAIN); ?>" class="btn btn-outline-primary btn-sm mb-3">
		<i class="bi bi-plus-lg me-1"></i><?= e($this->strings['cms.resource_browser.new_domain']) ?>
	</a>
<?php endif; ?>
<div class="resource-browser">
	<div class="row g-3">
		<!-- Detail Panel (Left) -->
		<div class="col-md-4 col-lg-3">
			<div class="resource-detail-panel" id="dina_content<?= htmlspecialchars($jstreeId, ENT_QUOTES); ?>">
				<div class="text-muted small p-3">
					<i class="bi bi-arrow-left-circle me-2"></i><?= e($this->strings['cms.resource_browser.select_tree_item']) ?>
				</div>
			</div>
		</div>
		<!-- Tree Panel (Right) -->
		<div class="col-md-8 col-lg-9">
			<div class="resource-tree-panel">
				<h5 class="mb-3">
					<i class="bi bi-folder-tree me-2"></i><?= e($this->strings['cms.resource_browser.site_structure']) ?>
				</h5>
				<div class="jstree-wrapper">
					<div id="<?= htmlspecialchars($jstreeId, ENT_QUOTES); ?>"
						 data-controller="jstree-resources"
						 data-jstree-resources-jstree-id-value="<?= htmlspecialchars($jstreeId, ENT_QUOTES); ?>"
						 data-jstree-resources-page-id-value="<?= htmlspecialchars($pageId, ENT_QUOTES); ?>"
						 data-jstree-resources-ajax-url-value="<?= htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>Load"
						 data-jstree-resources-move-url-value="<?= htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>Move"
						 data-jstree-resources-detail-url-value="<?= htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>DinaContent"
						 data-jstree-resources-delete-url-value="<?= htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>DeleteRecursive">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
