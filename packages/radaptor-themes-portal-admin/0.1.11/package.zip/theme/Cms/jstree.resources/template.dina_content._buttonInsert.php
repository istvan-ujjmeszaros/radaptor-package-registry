<?php assert(isset($this) && $this instanceof Template); ?>
<?php if ($this->props['insertUrl'] !== false): ?>
	<button class="btn btn-success btn-sm text-start" type="button" onclick="window.SetUrl('<?= $this->props['insertUrl']; ?>',0,0,'');">
		<i class="bi bi-box-arrow-in-down me-2"></i><?= e($this->strings['cms.resource_browser.insert']) ?>
	</button>
<?php endif; ?>
