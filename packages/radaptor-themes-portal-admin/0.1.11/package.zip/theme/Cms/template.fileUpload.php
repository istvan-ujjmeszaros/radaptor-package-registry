<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$this->registerLibrary('STIMULUS_LOADER');
$this->registerLibrary('DROPZONE');

$upload_url = ajax_url('dropzone.PartitionedUploadHandler', [
	'ref_id' => $this->props['ref_id'],
]);
$destination_path = (string) ($this->props['destination_path'] ?? '');
$destination_attributes = is_array($this->props['destination_attributes'] ?? null) ? $this->props['destination_attributes'] : [];
$destination_title = trim((string) ($destination_attributes['title'] ?? ''));
$destination_label = $destination_title !== '' ? $destination_title : $destination_path;
?>
<div class="container py-4 py-lg-5">
	<div class="row justify-content-center">
		<div class="col-12 col-xl-9">
			<div class="card border-0 shadow-sm">
				<div class="card-body p-4 p-lg-5">
					<div class="mb-4">
						<h1 class="h3 mb-2"><?= e($this->strings['widget.file_upload.name']) ?></h1>
						<p class="text-body-secondary mb-0">
							<?= e($this->strings['cms.file_upload.destination_path']) ?>:
							<strong class="text-body-emphasis"><?= e($destination_label) ?></strong>
						</p>
						<?php if ($destination_label !== $destination_path && $destination_path !== ''): ?>
							<p class="small font-monospace text-body-secondary mt-2 mb-0"><?= e($destination_path) ?></p>
						<?php endif; ?>
					</div>

					<div
						data-controller="dropzone-upload"
						data-dropzone-upload-upload-url-value="<?= $upload_url ?>"
						data-dropzone-upload-default-message-value="<?= e($this->strings['common.upload']) ?>"
						data-dropzone-upload-uploaded-message-value="<?= e($this->strings['cms.file.uploaded']) ?>"
						data-dropzone-upload-upload-error-message-value="<?= e($this->strings['cms.file.upload_error']) ?>"
					>
						<form
							action="<?= $upload_url ?>"
							class="dropzone rounded-4 bg-body-tertiary border"
							data-dropzone-upload-target="form"
						>
							<div class="dz-message py-5">
								<div class="fs-5 fw-semibold mb-2"><?= e($this->strings['common.upload']) ?></div>
								<div class="text-body-secondary small"><?= e($destination_path) ?></div>
							</div>
						</form>

						<p class="small text-body-secondary mt-3 mb-0" data-dropzone-upload-target="status"></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
