<?php assert(isset($this) && $this instanceof Template); ?>
<?php $menu_id = 'widget-insert-menu-' . (int)($this->props['counter'] ?? 0); ?>
<div class="widget-insert-dropdown" data-widget-insert-dropdown>
	<button class="widget-insert-btn"
			type="button"
			aria-expanded="false"
			aria-controls="<?= e($menu_id) ?>"
			data-widget-insert-toggle>
		<?= Icons::get(IconNames::WIDGET_ADD, $this->strings['cms.widget.insert.icon_title'] ?? '') ?>
		<span class="widget-insert-text"><?= e($this->strings['cms.widget.insert.button']) ?></span>
	</button>
	<ul class="widget-insert-menu" id="<?= e($menu_id) ?>" data-widget-insert-menu>
		<?php foreach ($this->props['visibleWidgets'] as $widget): ?>
			<?php if (!is_array($widget) || empty($widget['type_name'])) {
				continue;
			} ?>
			<li>
				<form method="post" data-controller="form-timezone" action="<?= event_url('widgetConnection.add', [
					'pageid' => $this->getPageId(),
					'slot_name' => $this->props['slot_name'],
					'seq' => is_object($this->getWidgetConnection()) ? $this->getWidgetConnection()->seq() : null,
				]); ?>">
					<input type="hidden" name="widget_name" value="<?= htmlspecialchars((string)$widget['type_name']); ?>">
					<button type="submit" class="widget-insert-menu-item">
						<?= htmlspecialchars((string)($widget['name'] ?? $widget['type_name'])); ?>
					</button>
				</form>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
