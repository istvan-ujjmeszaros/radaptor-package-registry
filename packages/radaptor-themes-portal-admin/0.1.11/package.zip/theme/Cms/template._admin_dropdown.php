<?php
assert(isset($this) && $this instanceof Template);
$layout_commands = is_array($this->props['layout_commands'] ?? null) ? $this->props['layout_commands'] : [];
?>

<style>
	.radaptor-floating-admin {
		position: fixed;
		right: 20px;
		bottom: 20px;
		z-index: 9999999;
		font-family: Arial, Helvetica, sans-serif;
	}

	.radaptor-floating-admin__trigger {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 50px;
		height: 50px;
		padding: 0;
		color: #fff;
		background:
			linear-gradient(180deg, rgba(255, 255, 255, 0.15) 0%, rgba(255, 255, 255, 0) 50%),
			linear-gradient(135deg, rgba(139, 92, 246, 0.86), rgba(236, 72, 153, 0.86));
		border: 1px solid rgba(255, 255, 255, 0.22);
		border-radius: 50%;
		box-shadow: 0 0 18px rgba(139, 92, 246, 0.34), 0 0.5rem 1rem rgba(0, 0, 0, 0.18);
		cursor: pointer;
		transition: background 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease;
	}

	.radaptor-floating-admin__trigger:hover,
	.radaptor-floating-admin__trigger:focus,
	.radaptor-floating-admin[data-open="true"] .radaptor-floating-admin__trigger {
		background:
			linear-gradient(180deg, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0) 50%),
			linear-gradient(135deg, rgba(160, 122, 248, 0.94), rgba(240, 96, 168, 0.94));
		border-color: rgba(255, 255, 255, 0.32);
		box-shadow: 0 0 26px rgba(139, 92, 246, 0.46), 0 0.5rem 1rem rgba(0, 0, 0, 0.2);
		outline: none;
	}

	.radaptor-floating-admin__menu {
		position: absolute;
		right: 0;
		bottom: calc(100% + 8px);
		display: none;
		min-width: 220px;
		margin: 0;
		padding: 0.35rem 0;
		list-style: none;
		background: #fff;
		border: 1px solid rgba(0, 0, 0, 0.15);
		border-radius: 0.375rem;
		box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
	}

	.radaptor-floating-admin[data-open="true"] .radaptor-floating-admin__menu {
		display: block;
	}

	.radaptor-floating-admin__item {
		display: grid;
		grid-template-columns: 1.25rem auto;
		align-items: center;
		gap: 0.5rem;
		padding: 0.45rem 1rem;
		color: #212529;
		text-decoration: none;
		white-space: nowrap;
	}

	.radaptor-floating-admin__item:hover,
	.radaptor-floating-admin__item:focus {
		color: #1e2125;
		background: #f8f9fa;
	}

	.radaptor-floating-admin__icon {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 1.25rem;
		min-width: 1.25rem;
	}

	.radaptor-floating-admin__separator {
		height: 0;
		margin: 0.35rem 0;
		border: 0;
		border-top: 1px solid rgba(0, 0, 0, 0.15);
	}
</style>

<div class="radaptor-floating-admin" data-floating-admin data-open="false">
	<button
		class="radaptor-floating-admin__trigger"
		type="button"
		aria-expanded="false"
		aria-controls="radaptor-floating-admin-menu"
		data-floating-admin-trigger
	>
		<?= Icons::get(IconNames::ADMIN_WRENCH); ?>
	</button>
	<ul id="radaptor-floating-admin-menu" class="radaptor-floating-admin__menu" data-floating-admin-menu>
		<li>
			<a class="radaptor-floating-admin__item" href="<?= e((string)($this->props['page_edit_url'] ?? '')) ?>">
				<span class="radaptor-floating-admin__icon"><?= Icons::get(IconNames::GEAR); ?></span><span><?= e((string)($this->props['page_edit_label'] ?? '')) ?></span>
			</a>
		</li>
		<li>
			<a
				class="radaptor-floating-admin__item"
				href="<?= e((string)($this->props['edit_mode_url'] ?? '')) ?>"
				data-floating-admin-current-page-action
				data-floating-admin-context="Page"
				data-floating-admin-event="EditmodeSwitch"
			>
				<span class="radaptor-floating-admin__icon"><?= Icons::get(IconNames::EDIT); ?></span><span><?= e((string)($this->props['edit_mode_action_label'] ?? $this->props['edit_mode_label'] ?? '')) ?></span>
			</a>
		</li>

		<?php foreach ($layout_commands as $command): ?>
			<?php $icon = isset($command['icon']) ? IconNames::tryFrom((string)$command['icon']) : null; ?>
			<?php $icon ??= IconNames::MENUBAR; ?>
			<li>
				<a class="radaptor-floating-admin__item" href="<?= e((string)($command['url'] ?? '')) ?>">
					<span class="radaptor-floating-admin__icon"><?= Icons::get($icon); ?></span><span><?= e((string)($command['title'] ?? '')) ?></span>
				</a>
			</li>
		<?php endforeach; ?>

		<li class="radaptor-floating-admin__separator" aria-hidden="true"></li>
		<li>
			<a class="radaptor-floating-admin__item" href="<?= e((string)($this->props['home_url'] ?? '')) ?>">
				<span class="radaptor-floating-admin__icon"><?= Icons::get(IconNames::HOME); ?></span><span><?= e((string)($this->props['home_label'] ?? '')) ?></span>
			</a>
		</li>
		<li>
			<a class="radaptor-floating-admin__item" href="<?= e((string)($this->props['logout_url'] ?? '')) ?>">
				<span class="radaptor-floating-admin__icon"><?= Icons::get(IconNames::LOGOUT); ?></span><span><?= e((string)($this->props['logout_label'] ?? '')) ?></span>
			</a>
		</li>
	</ul>
</div>

<script>
	(function () {
		var containers = document.querySelectorAll('[data-floating-admin]');

		for (var i = 0; i < containers.length; i++) {
			(function (container) {
				if (container.getAttribute('data-floating-admin-bound') === 'true') {
					return;
				}

				container.setAttribute('data-floating-admin-bound', 'true');

				var trigger = container.querySelector('[data-floating-admin-trigger]');
				var menu = container.querySelector('[data-floating-admin-menu]');

				if (!trigger || !menu) {
					return;
				}

				var stripRuntimeParameters = function (url) {
					url.searchParams.delete('context');
					url.searchParams.delete('event');
					url.searchParams.delete('set');
					url.searchParams.delete('referer');
					url.searchParams.delete('targets');
					url.searchParams.delete('targets[]');

					return url;
				};

				var refreshCurrentPageActionUrls = function () {
					var currentUrl = stripRuntimeParameters(new URL(window.location.href));
					var refererUrl = stripRuntimeParameters(new URL(window.location.href));
					var links = container.querySelectorAll('[data-floating-admin-current-page-action]');

					for (var j = 0; j < links.length; j++) {
						var link = links[j];
						var previousUrl = new URL(link.getAttribute('href') || '', window.location.href);
						var nextUrl = new URL(currentUrl.href);
						var context = link.getAttribute('data-floating-admin-context') || previousUrl.searchParams.get('context');
						var eventName = link.getAttribute('data-floating-admin-event') || previousUrl.searchParams.get('event');
						var setValue = previousUrl.searchParams.get('set');

						if (context) {
							nextUrl.searchParams.set('context', context);
						}

						if (eventName) {
							nextUrl.searchParams.set('event', eventName);
						}

						if (setValue !== null) {
							nextUrl.searchParams.set('set', setValue);
						}

						nextUrl.searchParams.set('referer', refererUrl.href);
						link.setAttribute('href', nextUrl.href);
					}
				};

				var setOpen = function (open) {
					if (open) {
						refreshCurrentPageActionUrls();
					}

					container.setAttribute('data-open', open ? 'true' : 'false');
					trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
				};

				trigger.addEventListener('click', function (event) {
					event.preventDefault();
					event.stopPropagation();
					setOpen(container.getAttribute('data-open') !== 'true');
				});

				trigger.addEventListener('keydown', function (event) {
					if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') {
						return;
					}

					event.preventDefault();
					setOpen(true);
					var firstItem = menu.querySelector('a');

					if (firstItem) {
						firstItem.focus();
					}
				});

				document.addEventListener('click', function (event) {
					if (!container.contains(event.target)) {
						setOpen(false);
					}
				});

				document.addEventListener('keydown', function (event) {
					if (event.key === 'Escape' && container.getAttribute('data-open') === 'true') {
						setOpen(false);
						trigger.focus();
					}
				});
			})(containers[i]);
		}
	})();
</script>
