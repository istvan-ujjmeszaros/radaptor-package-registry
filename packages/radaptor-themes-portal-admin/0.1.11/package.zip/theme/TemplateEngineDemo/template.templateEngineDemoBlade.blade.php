{{-- Blade Template Demo --}}
{{-- Laravel Blade template syntax --}}

<table class="table table-sm table-striped">
	<thead>
		<tr>
			<th>{{ t('theme.template_engine_demo.col.name') }}</th>
			<th>{{ t('theme.template_engine_demo.col.email') }}</th>
			<th>{{ t('theme.template_engine_demo.col.role') }}</th>
			<th>{{ t('common.actions') }}</th>
		</tr>
	</thead>
	<tbody>
		@foreach($users as $user)
			<tr>
				<td>{{ $user['name'] }}</td>
				<td>
					<a href="mailto:{{ $user['email'] }}">
						{{ $user['email'] }}
					</a>
				</td>
				<td>
					@php
						$badgeClass = match($user['role']) {
							'Admin' => 'danger',
							'Editor' => 'warning',
							default => 'info'
						};
					@endphp
					<span class="badge bg-{{ $badgeClass }}">
						{{ $user['role'] }}
					</span>
				</td>
				<td>
					<a href="@formUrl('User', $user['user_id'])">{{ t('common.edit') }}</a>
				</td>
			</tr>
		@endforeach
	</tbody>
</table>
