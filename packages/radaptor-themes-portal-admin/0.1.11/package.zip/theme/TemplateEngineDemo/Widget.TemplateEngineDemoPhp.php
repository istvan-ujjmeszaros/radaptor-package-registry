<?php

declare(strict_types=1);

class WidgetTemplateEngineDemoPhp extends AbstractWidget implements iMockable
{
	public const string ID = 'template_engine_demo_php';

	public static function getName(): string
	{
		return t('widget.' . static::ID . '.name');
	}

	public static function getDescription(): string
	{
		return t('widget.' . static::ID . '.description');
	}

	public static function getListVisibility(): bool
	{
		return Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER);
	}

	public static function getDefaultPathForCreation(): array
	{
		return [
			'path' => '/admin/demo/',
			'resource_name' => 'template-engines.html',
			'layout' => 'admin_default',
		];
	}

	protected function buildAuthorizedTree(iTreeBuildContext $tree_build_context, WidgetConnection $connection, array $build_context = []): array
	{
		return $this->buildDemoTree('PHP', TemplateRendererPhp::class, '.php', 'templateEngineDemoPhp');
	}

	public function buildMockTree(iTreeBuildContext $tree_build_context, WidgetConnection $connection, array $build_context = []): array
	{
		return $this->buildAuthorizedTree($tree_build_context, $connection, $build_context);
	}

	public function canAccess(iTreeBuildContext $tree_build_context, WidgetConnection $connection): bool
	{
		return Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER);
	}

	private function buildDemoTree(string $engine_name, string $engine_class, string $file_extension, string $template_name): array
	{
		$users = self::getDemoUsers();

		return $this->createComponentTree('templateEngineDemoWrapper', [
			'engineName' => $engine_name,
			'engineClass' => $engine_class,
			'fileExtension' => $file_extension,
			'sourceCode' => self::getTemplateSource($template_name, $file_extension),
			'users' => $users,
		], contents: [
			'demo' => [
				SduiNode::create($template_name, [
					'users' => $users,
				]),
			],
		]);
	}

	/**
	 * @return list<array{user_id: int, name: string, email: string, role: string}>
	 */
	private static function getDemoUsers(): array
	{
		return [
			['user_id' => 1, 'name' => 'Ada Lovelace', 'email' => 'ada@example.test', 'role' => 'Admin'],
			['user_id' => 2, 'name' => 'Grace Hopper', 'email' => 'grace@example.test', 'role' => 'Editor'],
			['user_id' => 3, 'name' => 'Katherine Johnson', 'email' => 'katherine@example.test', 'role' => 'Viewer'],
		];
	}

	private static function getTemplateSource(string $template_name, string $file_extension): string
	{
		$path = __DIR__ . '/template.' . $template_name . $file_extension;

		return is_readable($path) ? (string) file_get_contents($path) : '';
	}
}
