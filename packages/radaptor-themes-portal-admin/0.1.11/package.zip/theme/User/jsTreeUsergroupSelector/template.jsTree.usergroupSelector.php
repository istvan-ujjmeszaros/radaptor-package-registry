<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->setDebugType(TemplateDebugType::DEBUG_HTML); ?>
<?php
/**
 * Usergroup Selector Tree using jsTree 3.3.17 + Stimulus Controller.
 *
 * Features:
 * - Checkbox-based usergroup selection
 * - Immediate save on check/uncheck
 * - Bootstrap Icons for node types
 * - Stimulus controller handles all JS behavior
 *
 * Props:
 * - title: Title for the selector panel
 * - jstree_id: Widget instance ID
 * - jstree_type: Type of tree (usergroupSelector)
 * - selectorId: ID of the user
 */
$this->registerLibrary('__ADMIN_USERGROUP_SELECTOR');

$ajaxUrl = Url::getAjaxUrl("jstree.{$this->props['jstree_type']}Ajax", [
	"for_id" => $this->props['selectorId'],
]) . 'Load';
$addUrl = Url::getAjaxUrl("jstree.{$this->props['jstree_type']}Ajax", [
	"for_id" => $this->props['selectorId'],
]) . 'AddUsergroup';
$removeUrl = Url::getAjaxUrl("jstree.{$this->props['jstree_type']}Ajax", [
	"for_id" => $this->props['selectorId'],
]) . 'RemoveUsergroup';
?>
<div class="usergroup-selector-browser">
	<div class="row g-4">
		<!-- Left: Info panel -->
		<div class="col-md-4">
			<div class="usergroup-info-panel">
				<h5><?= e($this->strings['user.usergroup_selector.title']) ?></h5>
				<h6 class="mt-3 text-muted"><?= htmlspecialchars($this->props['title'], ENT_QUOTES | ENT_SUBSTITUTE); ?></h6>

				<div class="usergroup-help mt-4">
					<small class="text-muted">
						<i class="bi bi-info-circle me-1"></i>
						<?= e($this->strings['user.usergroup_selector.help']) ?>
					</small>
				</div>
			</div>
		</div>

		<!-- Right: Usergroup tree -->
		<div class="col-md-8">
			<div class="usergroup-tree-panel">
				<h5><?= e($this->strings['user.usergroup_selector.available_usergroups']) ?></h5>
				<div data-controller="jstree-usergroup-selector"
					 data-jstree-usergroup-selector-ajax-url-value="<?= htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>"
					 data-jstree-usergroup-selector-add-url-value="<?= htmlspecialchars($addUrl, ENT_QUOTES); ?>"
					 data-jstree-usergroup-selector-remove-url-value="<?= htmlspecialchars($removeUrl, ENT_QUOTES); ?>">
					<!-- jsTree will render here -->
				</div>
			</div>
		</div>
	</div>
</div>
