<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$this->registerLibrary('__ADMIN_USERLIST');

$connectionId = $this->getWidgetConnection()?->connection_id ?? 0;
$tableId = 'userlist-' . $connectionId;
$urlEdit = Form::getSeoUrl(FormList::USER);
$urlDatasheet = Url::getSeoUrl(ResourceTypeWebpage::findWebpageIdWithWidget(WidgetList::USERDESCRIPTION)) ?? '';
$urlRoles = Url::getSeoUrl(ResourceTypeWebpage::findWebpageIdWithWidget(WidgetList::ROLESELECTOR)) ?? '';
$urlUsergroups = Url::getSeoUrl(ResourceTypeWebpage::findWebpageIdWithWidget(WidgetList::USERGROUPSELECTOR)) ?? '';
$config = [
	'ajaxBaseUrl' => Url::getAjaxUrl('users.userListAjax'),
	'url_edit' => $urlEdit,
	'url_datasheet' => $urlDatasheet,
	'url_roles' => $urlRoles !== '' ? $urlRoles . 'user--' : '',
	'url_usergroups' => $urlUsergroups !== '' ? $urlUsergroups . 'user--' : '',
	'userListTableId' => $tableId,
	'icon_edit' => '<i class="bi bi-pencil-square operation-icon" aria-hidden="true"></i>',
	'icon_datasheet' => '<i class="bi bi-person-vcard operation-icon" aria-hidden="true"></i>',
	'icon_roles' => '<i class="bi bi-shield-check operation-icon" aria-hidden="true"></i>',
	'icon_usergroups' => '<i class="bi bi-people operation-icon" aria-hidden="true"></i>',
	'label_edit' => $this->strings['user.action.edit'],
	'label_datasheet' => $this->strings['user.action.datasheet'],
	'label_roles' => $this->strings['user.action.roles'],
	'label_usergroups' => $this->strings['user.action.usergroups'],
	'operation_edit' => Roles::hasRole(RoleList::ROLE_USERS_ADMIN) && $urlEdit !== '',
	'operation_datasheet' => $urlDatasheet !== '',
	'operation_roles' => Roles::hasRole(RoleList::ROLE_USERS_ROLE_ADMIN) && $urlRoles !== '',
	'operation_usergroups' => Roles::hasRole(RoleList::ROLE_USERGROUPS_ADMIN) && $urlUsergroups !== '',
];
?>
<script type="text/javascript">
	$(document).ready(function () {
		widgettype.userList.init(<?= json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>);
	});
</script>

<div class="card shadow-sm">
	<div class="card-body">
		<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
			<h1 class="h4 mb-0"><?= e($this->strings['user.list.title']) ?></h1>
			<a href="<?= form_url(FormList::USER); ?>" class="btn btn-primary btn-sm">
				<i class="bi bi-plus-lg me-1"></i><?= e($this->strings['user.list.new']) ?>
			</a>
		</div>

		<div class="table-responsive">
			<table class="display highlight_row commonDataTable w-100" id="<?= e($tableId) ?>">
				<thead>
				<tr>
					<th style="width:1px"><?= e($this->strings['common.id']) ?></th>
					<th><?= e($this->strings['user.col.username']) ?></th>
					<th style="width:10px"><?= e($this->strings['user.col.actions']) ?></th>
				</tr>
				</thead>
			</table>
		</div>
	</div>
</div>
