<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->setDebugType(TemplateDebugType::DEBUG_HTML); ?>
<?php
/**
 * Role Selector Tree using jsTree 3.3.17 + Stimulus Controller.
 *
 * Features:
 * - Checkbox-based role selection
 * - Immediate save on check/uncheck
 * - Bootstrap Icons for node types
 * - Stimulus controller handles all JS behavior
 *
 * Props:
 * - title: Title for the selector panel
 * - jstree_type: Type of tree (roleSelector)
 * - selectorType: Type of entity (user, usergroup)
 * - selectorId: ID of the entity
 */
$this->registerLibrary('__ADMIN_ROLE_SELECTOR');

$ajaxUrl = Url::getAjaxUrl("jstree.{$this->props['jstree_type']}Ajax", [
	"for_type" => $this->props['selectorType'],
	"for_id" => $this->props['selectorId'],
]) . 'Load';
$addUrl = Url::getAjaxUrl("jstree.{$this->props['jstree_type']}Ajax", [
	"for_type" => $this->props['selectorType'],
	"for_id" => $this->props['selectorId'],
]) . 'AddRole';
$removeUrl = Url::getAjaxUrl("jstree.{$this->props['jstree_type']}Ajax", [
	"for_type" => $this->props['selectorType'],
	"for_id" => $this->props['selectorId'],
]) . 'RemoveRole';
?>
<div class="role-selector-browser">
	<div class="row g-4">
		<!-- Left: Info panel -->
		<div class="col-md-4">
			<div class="role-info-panel">
				<h5><?= e($this->strings['user.role_selector.title']) ?></h5>
				<h6 class="mt-3 text-muted"><?= htmlspecialchars($this->props['title'], ENT_QUOTES | ENT_SUBSTITUTE); ?></h6>

				<div class="role-help mt-4">
					<small class="text-muted">
						<?= e($this->strings['user.role_selector.help']) ?>
					</small>
				</div>
			</div>
		</div>

		<!-- Right: Role tree -->
		<div class="col-md-8">
			<div class="role-tree-panel">
				<h5><?= e($this->strings['user.role_selector.available_roles']) ?></h5>
				<div data-controller="jstree-role-selector"
					 data-jstree-role-selector-ajax-url-value="<?= htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>"
					 data-jstree-role-selector-add-url-value="<?= htmlspecialchars($addUrl, ENT_QUOTES); ?>"
					 data-jstree-role-selector-remove-url-value="<?= htmlspecialchars($removeUrl, ENT_QUOTES); ?>">
					<!-- jsTree will render here -->
				</div>
			</div>
		</div>
	</div>
</div>
