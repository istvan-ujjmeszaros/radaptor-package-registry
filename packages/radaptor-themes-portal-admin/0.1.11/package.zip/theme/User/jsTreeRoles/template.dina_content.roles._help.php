<?php assert(isset($this) && $this instanceof Template); ?>
<p class="small text-muted mb-2">
	<i class="bi bi-info-circle me-1"></i>
	<?= e($this->strings['user.role.help_create']) ?>
</p>
<p class="small text-muted">
	<i class="bi bi-arrows-move me-1"></i>
	<?= e($this->strings['user.role.help_move']) ?>
</p>
