<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$nodeData = $this->props['data'][0];
$nodeId = $nodeData['node_id'] ?? 0;
?>
<h6 class="mb-3">
	<i class="bi bi-shield me-2"></i><?= e($this->strings['user.role.all']) ?>
</h6>

<div class="d-grid gap-2">

	<?php if (Roles::hasRole(RoleList::ROLE_ROLES_ADMIN)): ?>
		<a href="<?= form_url(FormList::ROLE, null, null, ['ref_id' => ($nodeId | 0)]); ?>" class="btn btn-outline-primary btn-sm text-start">
			<i class="bi bi-shield-plus me-2"></i><?= e($this->strings['user.role.new']) ?>
		</a>
	<?php endif; ?>

</div>

<hr class="my-3 opacity-25">

<?= $this->fetchContent('help'); ?>
