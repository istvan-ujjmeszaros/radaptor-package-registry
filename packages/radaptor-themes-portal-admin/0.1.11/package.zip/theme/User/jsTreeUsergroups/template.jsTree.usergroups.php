<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->setDebugType(TemplateDebugType::DEBUG_HTML); ?>
<?php
/**
 * Usergroups Tree using jsTree 3.3.17 + Stimulus Controller.
 *
 * Features:
 * - State persistence via localStorage (state plugin)
 * - Lazy-loading children via AJAX
 * - Drag-drop with type validation
 * - Bootstrap Icons for node types
 * - Stimulus controller handles all JS behavior
 *
 * Props:
 * - jstree_id: Widget instance ID
 * - jstree_type: Type of tree (usergroups)
 */
$this->registerLibrary('__ADMIN_USERGROUPS');

$jstreeId = $this->props['jstree_id'];
$pageId = (string) $this->getPageId();

// Build URLs for the Stimulus controller
$ajaxUrl = Url::getAjaxUrl('jstree.usergroupsAjaxLoad');
$moveUrl = Url::getAjaxUrl('jstree.usergroupsAjaxMove');
$detailUrl = Url::getAjaxUrl('jstree.usergroupsAjaxDinaContent');
$deleteUrl = Url::getAjaxUrl('jstree.usergroupsAjaxDeleteRecursive');
?>
<?php if (Roles::hasRole(RoleList::ROLE_USERGROUPS_ADMIN)): ?>
	<a href="<?= form_url(FormList::USERGROUP); ?>" class="btn btn-outline-primary btn-sm mb-3">
		<i class="bi bi-plus-lg me-1"></i><?= e($this->strings['user.usergroup.new']) ?>
	</a>
<?php endif; ?>

<div class="resource-browser">
	<div class="row g-3">
		<!-- Detail Panel (Left) -->
		<div class="col-md-4 col-lg-3">
			<div class="resource-detail-panel" id="dina_content<?= htmlspecialchars($jstreeId, ENT_QUOTES); ?>">
				<div class="text-muted small p-3">
					<i class="bi bi-arrow-left-circle me-2"></i><?= e($this->strings['cms.resource_browser.select_tree_item']) ?>
				</div>
			</div>
		</div>

		<!-- Tree Panel (Right) -->
		<div class="col-md-8 col-lg-9">
			<div class="resource-tree-panel">
				<h5 class="mb-3">
					<i class="bi bi-people me-2"></i><?= e($this->strings['admin.menu.usergroups']) ?>
				</h5>
				<div data-controller="jstree-usergroups"
					 data-jstree-usergroups-jstree-id-value="<?= htmlspecialchars($jstreeId, ENT_QUOTES); ?>"
					 data-jstree-usergroups-page-id-value="<?= htmlspecialchars($pageId, ENT_QUOTES); ?>"
					 data-jstree-usergroups-ajax-url-value="<?= htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>"
					 data-jstree-usergroups-move-url-value="<?= htmlspecialchars($moveUrl, ENT_QUOTES); ?>"
					 data-jstree-usergroups-detail-url-value="<?= htmlspecialchars($detailUrl, ENT_QUOTES); ?>"
					 data-jstree-usergroups-delete-url-value="<?= htmlspecialchars($deleteUrl, ENT_QUOTES); ?>">
					<!-- jsTree will render here -->
				</div>
			</div>
		</div>
	</div>
</div>
