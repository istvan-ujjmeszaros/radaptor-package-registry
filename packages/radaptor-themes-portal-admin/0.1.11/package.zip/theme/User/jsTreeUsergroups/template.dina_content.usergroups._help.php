<?php assert(isset($this) && $this instanceof Template); ?>
<p class="text-muted small mb-2">
	<i class="bi bi-info-circle me-1"></i><?= e($this->strings['user.usergroup.help_create']) ?>
</p>
<p class="text-muted small mb-0">
	<i class="bi bi-arrows-move me-1"></i><?= e($this->strings['user.usergroup.help_move']) ?>
</p>
