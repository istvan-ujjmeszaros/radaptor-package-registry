<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$nodeData = $this->props['data'][0];
$nodeId = $nodeData['node_id'];
$title = $nodeData['title'] ?? '';
?>
<h6 class="mb-3">
	<i class="bi bi-gear-wide-connected me-2"></i><?= htmlspecialchars($title, ENT_QUOTES); ?>
</h6>

<div class="d-grid gap-2 mb-3">
	<?php if (Roles::hasRole(RoleList::ROLE_USERGROUPS_ROLE_ADMIN)): ?>
		<a href="<?= widget_url(WidgetList::ROLESELECTOR); ?>usergroup--<?= $nodeId; ?>" class="btn btn-outline-secondary btn-sm text-start">
			<i class="bi bi-shield-lock me-2"></i><?= e($this->strings['user.usergroup.roles']) ?>
		</a>
	<?php endif; ?>
</div>

<div class="alert alert-info small mb-3" role="alert">
	<i class="bi bi-info-circle me-2"></i><?= e($this->strings['user.usergroup.system_managed_help']) ?>
</div>

<hr class="my-3 opacity-25">

<?= $this->fetchContent('help'); ?>
