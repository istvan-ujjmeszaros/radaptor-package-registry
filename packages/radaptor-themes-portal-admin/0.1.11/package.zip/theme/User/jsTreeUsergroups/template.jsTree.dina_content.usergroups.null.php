<?php assert(isset($this) && $this instanceof Template); ?>
<?php
// Build delete URL with array params for multi-select support
$deleteUrl = Url::getAjaxUrl('Jstree.usergroupsAjaxDeleteRecursive', ['jstree_id' => $this->props['jstree_id']]);
$deleteUrl .= '&' . http_build_query(['id' => $this->props['id']]);
?>
<h6 class="mb-3 text-danger">
	<i class="bi bi-exclamation-octagon me-2"></i><?= e($this->strings['selection.invalid_entry']) ?>
</h6>

<div class="d-grid gap-2">

	<?php if (Roles::hasRole(RoleList::ROLE_USERGROUPS_ADMIN)): ?>
		<button class="btn btn-outline-danger btn-sm text-start" type="button"
			hx-get="<?= htmlspecialchars($deleteUrl, ENT_QUOTES); ?>"
			hx-confirm="<?= e($this->strings['selection.delete_invalid_entry_confirm']) ?>"
			hx-swap="none">
			<i class="bi bi-trash me-2"></i><?= e($this->strings['common.delete']) ?>
		</button>
	<?php endif; ?>

</div>
