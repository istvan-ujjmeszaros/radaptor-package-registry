<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->setDebugType(TemplateDebugType::DEBUG_HTML); ?>
<?php
$this->registerLibrary('__ADMIN_RESOURCE_ACL_SELECTOR');

$selectorId = $this->props['selectorId'];
$title = $this->props['title'];
$isInheritingAcl = $this->props['is_inheriting_acl'];
$inheritedSubjects = $this->props['inherited_subjects'] ?? [];
$specificSubjects = $this->props['specific_subjects'] ?? [];
$ajaxBaseUrl = Url::getAjaxUrl("resource.AclSelectorAjax", ["for_id" => $selectorId]);
?>

<div class="acl-selector"
     data-controller="acl-selector"
     data-acl-selector-ajax-url-value="<?= htmlspecialchars($ajaxBaseUrl, ENT_QUOTES); ?>"
     data-acl-selector-inheriting-value="<?= $isInheritingAcl ? 'true' : 'false'; ?>">

	<div class="row">
		<!-- Left Column: Resource Info Panel (sticky) -->
		<div class="col-lg-4 col-md-5">
			<div class="acl-panel acl-info-panel">
				<h5 class="panel-title">
					<i class="bi bi-shield-lock me-2"></i><?= e($this->strings['cms.resource_acl.title']) ?>
				</h5>

				<div class="resource-path"><?= htmlspecialchars($title, ENT_QUOTES); ?></div>

				<hr class="my-3 opacity-25">

				<div class="form-check">
					<input type="checkbox" class="form-check-input" id="inherit-checkbox"
					       data-acl-selector-target="inheritCheckbox"
					       data-action="change->acl-selector#toggleInheritance"
						<?= $isInheritingAcl ? 'checked' : ''; ?>>
					<label class="form-check-label" for="inherit-checkbox">
						<?= e($this->strings['cms.resource_acl.inherit_label']) ?>
					</label>
				</div>

				<hr class="my-3 opacity-25">

				<div class="info-help text-muted small">
					<p class="mb-2">
						<i class="bi bi-info-circle me-1"></i>
						<?= e($this->strings['cms.resource_acl.inherit_help']) ?>
					</p>
					<p class="mb-0">
						<?= e($this->strings['cms.resource_acl.specific_help']) ?>
					</p>
				</div>
			</div>
		</div>

		<!-- Right Column: Permission Panels -->
		<div class="col-lg-8 col-md-7">
			<!-- Inherited Permissions Panel (animated) -->
			<div class="acl-panel acl-inherited-panel <?= $isInheritingAcl ? 'is-visible' : ''; ?>"
			     data-acl-selector-target="inheritedPanel">
				<h6 class="panel-subtitle">
					<i class="bi bi-arrow-down-circle me-2"></i><?= e($this->strings['cms.resource_acl.inherited_title']) ?>
				</h6>

				<div class="table-responsive">
					<table class="table table-sm acl-table" data-acl-selector-target="inheritedTable">
						<thead>
							<tr>
								<th class="col-subject"><?= e($this->strings['cms.resource_acl.subject']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.list']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.view']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.create']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.edit']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.delete']) ?></th>
							</tr>
						</thead>
						<tbody data-acl-selector-target="inheritedBody">
							<!-- Populated via AJAX -->
						</tbody>
					</table>
				</div>
			</div>

			<!-- Own Permissions Panel -->
			<div class="acl-panel acl-specific-panel">
				<h6 class="panel-subtitle">
					<i class="bi bi-person-lock me-2"></i><?= e($this->strings['cms.resource_acl.specific_title']) ?>
				</h6>

				<!-- Add new subject -->
				<div class="add-subject-row mb-3">
					<label class="form-label"><?= e($this->strings['cms.resource_acl.new_assignment']) ?></label>
					<div class="input-group">
						<input type="text" class="form-control" placeholder="<?= e($this->strings['cms.resource_acl.search_placeholder']) ?>"
						       data-acl-selector-target="autocompleteInput"
						       autocomplete="off">
						<button type="button" class="btn btn-outline-primary btn-sm"
						        data-acl-selector-target="addButton"
						        data-action="click->acl-selector#addSubject">
							<i class="bi bi-plus-lg me-1"></i><?= e($this->strings['cms.resource_acl.assign']) ?>
						</button>
					</div>
					<div class="acl-input-error" data-acl-selector-target="inputError"></div>
				</div>

				<div class="table-responsive">
					<table class="table table-sm acl-table" data-acl-selector-target="specificTable">
						<thead>
							<tr>
								<th class="col-subject"><?= e($this->strings['cms.resource_acl.subject']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.list']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.view']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.create']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.edit']) ?></th>
								<th class="col-perm text-center"><?= e($this->strings['cms.resource_acl.permission.delete']) ?></th>
								<th class="col-actions text-center"></th>
							</tr>
						</thead>
						<tbody data-acl-selector-target="specificBody">
							<!-- Populated via AJAX -->
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>

</div>
