<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class PackageSmokeTest extends TestCase
{
	public function testRegistryPackageMetadataIsValid(): void
	{
		$root = dirname(__DIR__);
		$metadata_path = $root . '/.registry-package.json';
		$this->assertFileExists($metadata_path);

		$decoded = json_decode((string) file_get_contents($metadata_path), true);
		$this->assertIsArray($decoded);
		$this->assertSame('radaptor/themes/portal-admin', $decoded['package'] ?? null);
		$this->assertSame('theme', $decoded['type'] ?? null);
		$this->assertSame('portal-admin', $decoded['id'] ?? null);
		$this->assertIsString($decoded['dependencies']['radaptor/core/cms'] ?? null);
		$this->assertMatchesRegularExpression('/^\^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $decoded['dependencies']['radaptor/core/cms']);
	}

	public function testThemeEntrypointsExist(): void
	{
		$root = dirname(__DIR__);

		$this->assertFileExists($root . '/theme/_layouts/template.layout_admin_default.php');
		$this->assertFileExists($root . '/theme/Cms/template._admin_dropdown.php');
		$this->assertDirectoryExists($root . '/public/assets/radaptor-portal-admin');
	}
}
