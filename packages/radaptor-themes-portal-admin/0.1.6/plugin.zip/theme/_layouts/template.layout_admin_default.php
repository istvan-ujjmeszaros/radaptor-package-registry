<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->registerLibrary('__RADAPTOR_PORTAL_ADMIN_SITE'); ?>
<?php
$lang = (string)($this->props['lang'] ?? substr(Kernel::getLocale(), 0, 2));
$site_name = (string)($this->props['site_name'] ?? Config::APP_SITE_NAME->value());
$administration_label = (string)($this->props['administration_label'] ?? '');
$document_title = (string)($this->props['document_title'] ?? ($administration_label !== '' ? $administration_label . ' - ' . $site_name : $site_name));
$saved_short_label = (string)($this->props['saved_short_label'] ?? '');
?>
<!DOCTYPE html>
<html lang="<?= e($lang) ?>" data-bs-theme="dark">
<head>
	<meta charset="utf-8">
	<title><?= e($document_title) ?></title>
	<meta name="robots" content="NOINDEX, NOFOLLOW">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="shortcut icon" href="/favicon.ico">
	<link rel="icon" href="/favicon.ico" type="image/x-icon">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?= $this->getRenderer()->getLibraryDebugInfo(); ?>
	<?= $this->getRenderer()->getCss(); ?>
	<?= $this->getRenderer()->getJsTop(); ?>
</head>
<body class="admin-layout" data-controller="sidebar">
<?= $this->getRenderer()->fetchInnerHtml(); ?>

<div class="admin-wrapper">
	<!-- Sidebar -->
	<aside class="admin-sidebar" data-sidebar-target="sidebar">
		<div class="sidebar-brand">
			<a href="/" class="d-flex align-items-center text-decoration-none">
				<span class="brand-text"><?= e($site_name); ?></span>
			</a>
		</div>

		<nav class="sidebar-nav">
			<?= $this->fetchSlot('side_menu_admin'); ?>
			<?= $this->fetchSlot('admin_menu'); ?>
		</nav>

		<?= $this->fetchSlot('user_menu'); ?>
	</aside>

	<!-- Sidebar overlay for mobile -->
	<div class="sidebar-overlay" data-action="click->sidebar#close"></div>

	<!-- Main content -->
	<main class="admin-main">
		<!-- Top bar -->
		<header class="admin-topbar">
			<div class="topbar-left">
				<button type="button" class="sidebar-toggle d-lg-none" data-action="click->sidebar#toggle">
					<i class="bi bi-list fs-5"></i>
				</button>
			</div>

			<div class="topbar-right" data-controller="saved-indicator">
				<!-- Global saved indicator -->
				<div class="topbar-saved-indicator" data-saved-indicator-target="indicator">
					<i class="bi bi-check-lg"></i><?= e($saved_short_label) ?>
				</div>
				<?= $this->fetchSlot('top_menu_admin'); ?>
			</div>
		</header>

		<!-- Page content -->
		<div class="admin-content">
			<?= $this->fetchSlot('content'); ?>
		</div>
	</main>
</div>

<!-- Flash messages container -->
<div class="flash-messages" id="flash-messages"></div>

<?= $this->fetchSlot('page_chrome'); ?>
<?= $this->getRenderer()->getJs(); ?>
<script>
	(function initTimezoneAndDateFormatting() {
		let clientTimezone = 'UTC';
		try {
			clientTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
		} catch (e) {
			clientTimezone = 'UTC';
		}

		window.radaptorDateTime = {
			clientTimezone: clientTimezone,
			formatUtc: function (utcIsoString, options, locale) {
				if (!utcIsoString) {
					return '';
				}
				const date = new Date(utcIsoString);
				if (Number.isNaN(date.getTime())) {
					return '';
				}
				return new Intl.DateTimeFormat(locale || undefined, options || {
					year: 'numeric',
					month: '2-digit',
					day: '2-digit',
					hour: '2-digit',
					minute: '2-digit',
					second: '2-digit',
				}).format(date);
			},
			timeAgoUtc: function (utcIsoString, locale) {
				if (!utcIsoString) {
					return '';
				}
				const date = new Date(utcIsoString);
				if (Number.isNaN(date.getTime())) {
					return '';
				}
				const diffSeconds = Math.round((date.getTime() - Date.now()) / 1000);
				const abs = Math.abs(diffSeconds);
				const rtf = new Intl.RelativeTimeFormat(locale || undefined, {numeric: 'auto'});

				if (abs < 60) return rtf.format(diffSeconds, 'second');
				if (abs < 3600) return rtf.format(Math.round(diffSeconds / 60), 'minute');
				if (abs < 86400) return rtf.format(Math.round(diffSeconds / 3600), 'hour');
				if (abs < 604800) return rtf.format(Math.round(diffSeconds / 86400), 'day');
				if (abs < 2629800) return rtf.format(Math.round(diffSeconds / 604800), 'week');
				if (abs < 31557600) return rtf.format(Math.round(diffSeconds / 2629800), 'month');
				return rtf.format(Math.round(diffSeconds / 31557600), 'year');
			}
		};
		document.dispatchEvent(new Event('radaptorDateTimeReady'));
	})();

	// Initialize system messages if the function exists
	if (typeof renderSystemMessages === 'function') {
		renderSystemMessages();
	}
</script>
<?= $this->getRenderer()->fetchClosingHtml(); ?>
</body>
</html>
