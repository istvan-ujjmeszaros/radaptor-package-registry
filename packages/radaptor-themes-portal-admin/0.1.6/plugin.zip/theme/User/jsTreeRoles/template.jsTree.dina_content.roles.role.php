<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$nodeData = $this->props['data'][0];
$nodeId = $nodeData['node_id'];
$title = $nodeData['title'] ?? '';

// Build delete URL with array params for multi-select support
$deleteUrl = Url::getAjaxUrl('Jstree.rolesAjaxDeleteRecursive', ['jstree_id' => $this->props['jstree_id']]);
$deleteUrl .= '&' . http_build_query(['id' => $this->props['id']]);
?>
<h6 class="mb-3">
	<i class="bi bi-shield-check me-2"></i><?= htmlspecialchars($title, ENT_QUOTES); ?>
</h6>

<div class="d-grid gap-2">

	<?php if (Roles::hasRole(RoleList::ROLE_ROLES_ADMIN)): ?>
		<a href="<?= form_url(FormList::ROLE, null, null, ['ref_id' => ($nodeId | 0)]); ?>" class="btn btn-outline-primary btn-sm text-start">
			<i class="bi bi-shield-plus me-2"></i><?= e($this->strings['user.role.new_child']) ?>
		</a>

		<a href="<?= form_url(FormList::ROLE, $nodeId); ?>" class="btn btn-outline-secondary btn-sm text-start">
			<i class="bi bi-pencil me-2"></i><?= e($this->strings['common.edit']) ?>
		</a>

		<button class="btn btn-outline-danger btn-sm text-start" type="button"
			hx-get="<?= htmlspecialchars($deleteUrl, ENT_QUOTES); ?>"
			hx-confirm="<?= e($this->strings['user.role.delete_confirm']) ?>"
			hx-swap="none">
			<i class="bi bi-trash me-2"></i><?= e($this->strings['common.delete']) ?>
		</button>
	<?php endif; ?>

</div>

<hr class="my-3 opacity-25">

<?= $this->fetchSlot('help'); ?>
