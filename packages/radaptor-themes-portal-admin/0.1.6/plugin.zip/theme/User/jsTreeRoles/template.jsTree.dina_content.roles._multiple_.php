<?php assert(isset($this) && $this instanceof Template); ?>
<?php
// Build delete URL with array params for multi-select
$deleteUrl = Url::getAjaxUrl('Jstree.rolesAjaxDeleteRecursive', ['jstree_id' => $this->props['jstree_id']]);
$deleteUrl .= '&' . http_build_query(['id' => $this->props['id']]);
?>
<h6 class="mb-3">
	<i class="bi bi-shield-check me-2"></i><?= e($this->strings['selection.multiple']) ?>
</h6>

<div class="d-grid gap-2">

	<?php if (Roles::hasRole(RoleList::ROLE_ROLES_ADMIN)): ?>
		<button class="btn btn-outline-danger btn-sm text-start" type="button"
			hx-get="<?= htmlspecialchars($deleteUrl, ENT_QUOTES); ?>"
			hx-confirm="<?= e($this->strings['selection.delete_selected_confirm']) ?>"
			hx-swap="none">
			<i class="bi bi-trash me-2"></i><?= e($this->strings['selection.delete_selected']) ?>
		</button>
	<?php endif; ?>

</div>

<hr class="my-3 opacity-25">

<p class="small text-muted mb-2"><?= e($this->strings['selection.selected_items']) ?>:</p>
<ul class="small">
	<?php foreach ($this->props['selected_items'] as $item): ?>
		<li><?= htmlspecialchars($item['title'], ENT_QUOTES); ?></li>
	<?php endforeach; ?>
</ul>

<hr class="my-3 opacity-25">

<?= $this->fetchSlot('help'); ?>
