<?php assert(isset($this) && $this instanceof Template); ?>
<?php
// Root node has node_id = 0, used as parent for new root-level usergroups
$nodeId = $this->props['data'][0]['node_id'] ?? 0;
?>
<h6 class="mb-3">
	<i class="bi bi-people me-2"></i><?= e($this->strings['user.usergroup.all']) ?>
</h6>

<div class="d-grid gap-2">

	<?php if (Roles::hasRole(RoleList::ROLE_USERGROUPS_ADMIN)): ?>
		<a href="<?= form_url(FormList::USERGROUP, null, null, ['ref_id' => $nodeId]); ?>" class="btn btn-outline-primary btn-sm text-start">
			<i class="bi bi-people-fill me-2"></i><?= e($this->strings['user.usergroup.new']) ?>
		</a>
	<?php endif; ?>

</div>

<hr class="my-3 opacity-25">

<?= $this->fetchSlot('help'); ?>
