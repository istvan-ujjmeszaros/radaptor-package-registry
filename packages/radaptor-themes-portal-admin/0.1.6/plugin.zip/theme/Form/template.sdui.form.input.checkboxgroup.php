<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$values = is_array($this->props['values'] ?? null) ? $this->props['values'] : [];
$current_values = is_array($this->props['value'] ?? null) ? $this->props['value'] : [];
?>
<div class="col-12">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label d-block"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
	<div class="d-flex flex-column gap-2">
		<?php $i = 0; ?>
		<?php foreach ($values as $key => $label): ?>
			<?php $checkbox_id = (string)$this->props['id'] . '_' . ++$i; ?>
			<div class="form-check">
				<input type="checkbox" class="form-check-input<?= !empty($this->props['errors'] ?? []) ? ' is-invalid' : '' ?>" name="<?= e((string)$this->props['name']) ?>[<?= e((string)$key) ?>]" id="<?= e($checkbox_id) ?>" value="1"<?= !empty($current_values[$key]) ? ' checked' : '' ?>>
				<label class="form-check-label" for="<?= e($checkbox_id) ?>"><?= e((string)$label) ?></label>
			</div>
		<?php endforeach; ?>
	</div>
	<?= $this->fetchSlot('helper') ?>
</div>
