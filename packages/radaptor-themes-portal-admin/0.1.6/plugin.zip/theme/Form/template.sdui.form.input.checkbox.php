<?php assert(isset($this) && $this instanceof Template); ?>
<?php $has_errors = !empty($this->props['errors'] ?? []); ?>
<div class="col-12">
	<div class="form-check mt-2">
		<input type="checkbox" class="form-check-input<?= $has_errors ? ' is-invalid' : '' ?>" name="<?= e((string)$this->props['name']) ?>" id="<?= e((string)$this->props['id']) ?>" value="1"<?= !empty($this->props['checked']) ? ' checked' : '' ?>>
		<label class="form-check-label" for="<?= e((string)$this->props['id']) ?>"><?= e((string)($this->props['label'] ?? '')) ?></label>
	</div>
	<?= $this->fetchSlot('helper') ?>
</div>
