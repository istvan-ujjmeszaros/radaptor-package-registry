<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$values = is_array($this->props['values'] ?? null) ? $this->props['values'] : [];
$current_value = (string)($this->props['value'] ?? '');
$required = (bool)($this->props['required'] ?? true);
$placeholder_label = (string)($this->props['placeholder_label'] ?? '');
$has_errors = !empty($this->props['errors'] ?? []);
?>
<div class="col">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label" for="<?= e((string)$this->props['id']) ?>"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
	<select class="form-select<?= $has_errors ? ' is-invalid' : '' ?>" id="<?= e((string)$this->props['id']) ?>"<?= (string)($this->props['input_style_attr'] ?? '') ?> name="<?= e((string)$this->props['name']) ?>">
		<?php if ($required): ?>
			<option value=""><?= e($placeholder_label) ?></option>
		<?php endif; ?>
		<?php foreach ($values as $value): ?>
			<?php $value['inputtype'] ??= 'option'; ?>
			<?php if ($value['inputtype'] === 'option'): ?>
				<?php
				$option_value = (string)($value['value'] ?? '');
				$option_label = (string)($value['label'] ?? $placeholder_label);
				?>
				<option value="<?= e($option_value) ?>"<?= $option_value === $current_value ? ' selected' : '' ?>><?= e($option_label) ?></option>
			<?php elseif ($value['inputtype'] === 'optgroup_begin'): ?>
				<optgroup label="<?= e((string)($value['label'] ?? '')) ?>">
			<?php elseif ($value['inputtype'] === 'optgroup_end'): ?>
				</optgroup>
			<?php endif; ?>
		<?php endforeach; ?>
	</select>
	<?= $this->fetchSlot('helper') ?>
</div>
