<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$values = is_array($this->props['values'] ?? null) ? $this->props['values'] : [];
$current_value = (string)($this->props['value'] ?? '');
?>
<div class="col-12">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label d-block"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
	<div class="d-flex flex-column gap-2">
		<?php $i = 0; ?>
		<?php foreach ($values as $label => $value): ?>
			<?php $radio_id = (string)$this->props['id'] . '_' . ++$i; ?>
			<div class="form-check">
				<input type="radio" class="form-check-input<?= !empty($this->props['errors'] ?? []) ? ' is-invalid' : '' ?>" name="<?= e((string)$this->props['name']) ?>" id="<?= e($radio_id) ?>" value="<?= e((string)$value) ?>"<?= (string)$value === $current_value ? ' checked' : '' ?>>
				<label class="form-check-label" for="<?= e($radio_id) ?>"><?= e((string)$label) ?></label>
			</div>
		<?php endforeach; ?>
	</div>
	<?= $this->fetchSlot('helper') ?>
</div>
