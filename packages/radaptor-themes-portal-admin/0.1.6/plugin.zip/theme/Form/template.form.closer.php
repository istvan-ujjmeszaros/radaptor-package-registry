<!DOCTYPE html>
<html>
<head>
	<title>-- closer page --</title>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="/favicon.ico">
</head>
<body>
<script>window.close();</script>
<div class="alert alert-warning m-3">
	<strong>Zard be ezt az ablakot!</strong>
</div>
</body>
</html>
