<?php

declare(strict_types=1);

class WidgetTemplateEngineDemoBlade extends WidgetTemplateEngineDemoPhp
{
	public const string ID = 'template_engine_demo_blade';

	protected function buildAuthorizedTree(iTreeBuildContext $tree_build_context, WidgetConnection $connection, array $build_context = []): array
	{
		return $this->buildBladeDemoTree();
	}

	private function buildBladeDemoTree(): array
	{
		$users = [
			['user_id' => 1, 'name' => 'Ada Lovelace', 'email' => 'ada@example.test', 'role' => 'Admin'],
			['user_id' => 2, 'name' => 'Grace Hopper', 'email' => 'grace@example.test', 'role' => 'Editor'],
			['user_id' => 3, 'name' => 'Katherine Johnson', 'email' => 'katherine@example.test', 'role' => 'Viewer'],
		];
		$path = __DIR__ . '/template.templateEngineDemoBlade.blade.php';

		return $this->createComponentTree('templateEngineDemoWrapper', [
			'engineName' => 'Blade',
			'engineClass' => TemplateRendererBlade::class,
			'fileExtension' => '.blade.php',
			'sourceCode' => is_readable($path) ? (string) file_get_contents($path) : '',
			'users' => $users,
		], slots: [
			'demo' => [
				SduiNode::create('templateEngineDemoBlade', [
					'users' => $users,
				]),
			],
		]);
	}
}
