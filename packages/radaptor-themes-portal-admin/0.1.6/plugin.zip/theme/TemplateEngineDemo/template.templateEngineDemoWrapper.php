<?php
/**
 * Wrapper template for template engine demos.
 * Shows source code with syntax highlighting and rendered output.
 *
 * @var string $engineName   Display name (e.g., 'PHP', 'Blade', 'Twig')
 * @var string $engineClass
 * @var string $fileExtension
 * @var string $sourceCode
 * @var array $users
 * @var Template $this
 */

// Register Prism.js for syntax highlighting
$this->registerLibrary(LibrariesRadaptorPortalAdmin::PRISM);

// Determine language for Prism.js
$prismLang = match ($fileExtension) {
	'.blade.php' => 'php',
	'.twig' => 'twig',
	default => 'php',
};
?>
<div class="card mb-4">
	<div class="card-header d-flex justify-content-between align-items-center">
		<h5 class="mb-0">
			<i class="bi bi-file-code me-2"></i>
			<?= htmlspecialchars($engineName) ?> Template Engine
		</h5>
		<span class="badge bg-secondary"><?= htmlspecialchars($engineClass) ?></span>
	</div>
	<div class="card-body">
		<div class="row">
			<!-- Source Code Panel -->
			<div class="col-lg-6 mb-3 mb-lg-0">
				<h6 class="text-muted mb-2">
					<i class="bi bi-code-slash me-1"></i>
					Template Source
					<code class="ms-2"><?= htmlspecialchars($fileExtension) ?></code>
				</h6>
				<pre class="rounded"><code class="language-<?= $prismLang ?>"><?= htmlspecialchars($sourceCode) ?></code></pre>
			</div>

			<!-- Rendered Output Panel -->
			<div class="col-lg-6">
				<h6 class="text-muted mb-2">
					<i class="bi bi-eye me-1"></i>
					Rendered Output
				</h6>
				<div class="border rounded p-3 bg-light">
					<?= $this->fetchSlot('demo'); ?>
				</div>
			</div>
		</div>
	</div>
</div>
