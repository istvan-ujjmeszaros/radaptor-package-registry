<?php
/**
 * PHP Template Demo
 * Native PHP template syntax.
 *
 * @var array $users
 */
?>
<table class="table table-sm table-striped">
	<thead>
		<tr>
			<th>Name</th>
			<th>Email</th>
			<th>Role</th>
			<th>Actions</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($users as $user): ?>
			<tr>
				<td><?= e($user['name']) ?></td>
				<td>
					<a href="mailto:<?= e($user['email']) ?>">
						<?= e($user['email']) ?>
					</a>
				</td>
				<td>
					<?php
					$badgeClass = match ($user['role']) {
						'Admin' => 'danger',
						'Editor' => 'warning',
						default => 'info',
					};
			?>
					<span class="badge bg-<?= $badgeClass ?>">
						<?= e($user['role']) ?>
					</span>
				</td>
				<td>
					<a href="<?= form_url('User', $user['user_id']) ?>">Edit</a>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
