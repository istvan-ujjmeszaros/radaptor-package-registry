<?php assert(isset($this) && $this instanceof Template); ?>
<?php if (User::getCurrentUserUsername()): ?>
<div class="sidebar-footer">
	<div class="sidebar-user-dropdown" data-controller="dropdown">
		<button type="button" class="user-menu-toggle" data-action="click->dropdown#toggle">
			<span class="user-avatar-icon">
				<i class="bi bi-person-circle"></i>
			</span>
			<span class="user-menu-name"><?= htmlspecialchars(User::getCurrentUserUsername()); ?></span>
			<i class="bi bi-chevron-up dropdown-arrow"></i>
		</button>
		<div class="user-dropdown-menu" data-dropdown-target="menu">
			<a href="<?= modify_url([
				'context' => 'user',
				'event' => 'logout',
				'referer' => Url::getCurrentUrlForReferer(),
			]); ?>" class="user-dropdown-item">
					<i class="bi bi-box-arrow-right me-2"></i>
					<?= e($this->strings['common.logout']) ?>
				</a>
			</div>
		</div>
</div>
<?php endif; ?>
