<?php
assert(isset($this) && $this instanceof Template);
$layout_commands = is_array($this->props['layout_commands'] ?? null) ? $this->props['layout_commands'] : [];
?>

<style>
	.admin-dropdown-container {
		position: fixed;
		right: 20px;
		bottom: 20px;
		z-index: 1050;
		font-family: Arial, Helvetica, sans-serif;
	}

	.admin-dropdown-container .dropdown {
		position: relative;
	}

	.admin-dropdown-container .btn {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 50px;
		height: 50px;
		padding: 0;
		color: #fff;
		background: #0d6efd;
		border: 1px solid #0d6efd;
		border-radius: 50%;
		box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
		cursor: pointer;
	}

	.admin-dropdown-container .dropdown-menu {
		position: absolute;
		right: 0;
		bottom: calc(100% + 8px);
		display: none;
		min-width: 220px;
		margin: 0;
		padding: 0.35rem 0;
		list-style: none;
		background: #fff;
		border: 1px solid rgba(0, 0, 0, 0.15);
		border-radius: 0.375rem;
		box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
	}

	.admin-dropdown-container:hover .dropdown-menu,
	.admin-dropdown-container:focus-within .dropdown-menu {
		display: block;
	}

	.admin-dropdown-container .dropdown-item {
		display: block;
		padding: 0.45rem 1rem;
		color: #212529;
		text-decoration: none;
		white-space: nowrap;
	}

	.admin-dropdown-container .dropdown-item:hover,
	.admin-dropdown-container .dropdown-item:focus {
		color: #1e2125;
		background: #f8f9fa;
	}

	.admin-dropdown-container .dropdown-divider {
		height: 0;
		margin: 0.35rem 0;
		border: 0;
		border-top: 1px solid rgba(0, 0, 0, 0.15);
	}

	.admin-dropdown-container .me-2,
	.admin-dropdown-container .ms-2 {
		margin-inline-end: 0.5rem;
	}
</style>

<div class="admin-dropdown-container position-fixed" style="bottom: 20px; right: 20px; z-index: 1050;">
	<div class="dropdown dropup">
		<button class="btn btn-primary rounded-circle shadow-lg" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="width: 50px; height: 50px;">
			<?= Icons::get(IconNames::ADMIN_WRENCH); ?>
		</button>
		<ul class="dropdown-menu dropdown-menu-end shadow">
			<li>
				<a class="dropdown-item" href="<?= e((string)($this->props['page_edit_url'] ?? '')) ?>">
					<i class="bi bi-gear me-2"></i><?= e((string)($this->props['page_edit_label'] ?? '')) ?>
				</a>
			</li>
			<li>
				<a class="dropdown-item" href="<?= e((string)($this->props['edit_mode_url'] ?? '')) ?>">
					<i class="bi bi-pencil me-2"></i><?= e((string)($this->props['edit_mode_action_label'] ?? $this->props['edit_mode_label'] ?? '')) ?>
				</a>
			</li>

			<?php foreach ($layout_commands as $command): ?>
				<?php $icon = isset($command['icon']) ? IconNames::tryFrom((string)$command['icon']) : null; ?>
				<li>
					<a class="dropdown-item" href="<?= e((string)($command['url'] ?? '')) ?>">
						<?= Icons::get($icon); ?>
						<span class="ms-2"><?= e((string)($command['title'] ?? '')) ?></span>
					</a>
				</li>
			<?php endforeach; ?>

			<li><hr class="dropdown-divider"></li>
			<li>
				<a class="dropdown-item" href="<?= e((string)($this->props['home_url'] ?? '')) ?>">
					<i class="bi bi-house me-2"></i><?= e((string)($this->props['home_label'] ?? '')) ?>
				</a>
			</li>
			<li>
				<a class="dropdown-item" href="<?= e((string)($this->props['logout_url'] ?? '')) ?>">
					<i class="bi bi-box-arrow-right me-2"></i><?= e((string)($this->props['logout_label'] ?? '')) ?>
				</a>
			</li>
		</ul>
	</div>
</div>
