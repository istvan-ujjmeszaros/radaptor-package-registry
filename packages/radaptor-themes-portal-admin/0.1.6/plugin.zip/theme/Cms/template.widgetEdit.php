<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->registerLibrary(LibrariesRadaptorPortalAdmin::__ADMIN_EDIT_MODE); ?>
<div id="widget-<?= $this->getWidgetConnection()->connection_id; ?>"
	 class="widget-area<?php if ($this->props['class'] != ''): ?> <?= $this->props['class']; ?><?php endif; ?>"
	 <?php if ($this->props['style'] != ''): ?>style="<?= $this->props['style']; ?>"<?php endif; ?>
 data-controller="widget"
	 data-action="click->widget#select">
	<div id="edit-<?= $this->getWidgetConnection()->connection_id; ?>" class="widget-edit">
		<?= $this->fetchSlot('edit_bar'); ?>
	</div>
	<?= $this->fetchSlot('widget_content'); ?>
	<div style="clear:both;"></div>
</div>
