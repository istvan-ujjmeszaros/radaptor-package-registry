<?php assert(isset($this) && $this instanceof Template); ?>
<?php $this->registerLibrary(LibrariesRadaptorPortalAdmin::__ADMIN_EDIT_MODE); ?>
<?php
$this->props['float'] = false;
$this->props['extra_style'] = 'clear:both;';

if (is_object($this->getWidgetConnection()) && $this->getWidgetConnection()->getExtraparam('float')) {
	switch ($this->getWidgetConnection()->getExtraparam('float')) {
		case 'left':
			$this->props['float'] = 'left';

			break;

		case 'right':
			$this->props['float'] = 'right';

			break;
	}

	if ($this->props['float']) {
		$this->props['extra_style'] = 'float: ' . $this->props['float'] . '; width:30px; height:auto;';
	}
}
?>
<?php $this->props['clipboard'] = WidgetConnection::getClipboard(); ?>
<div style="clear:both"></div>
	<div class="widget-insert d-flex align-items-center gap-2 py-2">
		<?php if (!is_null($this->props['clipboard']) && $this->props['clipboard'] !== false): ?>
			<a class="btn btn-sm btn-outline-secondary" title="<?= e($this->strings['cms.widget.insert_from_clipboard']) ?>" href="<?= event_url('widgetConnection.add', [
				'pageid' => $this->getPageId(),
				'slot_name' => $this->props['slot_name'],
				'widget_name' => $this->props['clipboard'],
				'seq' => is_object($this->getWidgetConnection()) ? $this->getWidgetConnection()->seq() : null,
			]); ?>">
			<i class="bi bi-clipboard-plus"></i>
		</a>
	<?php endif; ?>
	<?= $this->fetchSlot('add_widget_from_list'); ?>
</div>
