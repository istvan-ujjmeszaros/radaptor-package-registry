<?php assert(isset($this) && $this instanceof Template); ?>
<div class="dropdown widget-insert-dropdown">
	<button class="btn btn-sm widget-insert-btn rounded-pill"
			type="button"
			data-bs-toggle="dropdown"
			aria-expanded="false">
		<i class="bi bi-plus-lg"></i>
		<span class="widget-insert-text"><?= e($this->strings['cms.widget.insert.button']) ?></span>
	</button>
	<ul class="dropdown-menu widget-insert-menu">
		<?php foreach ($this->props['visibleWidgets'] as $widget): ?>
			<?php if (!is_array($widget) || empty($widget['type_name'])) {
				continue;
			} ?>
			<li>
				<form method="post" data-controller="form-timezone" action="<?= event_url('widgetConnection.add', [
					'pageid' => $this->getPageId(),
					'slot_name' => $this->props['slot_name'],
					'seq' => is_object($this->getWidgetConnection()) ? $this->getWidgetConnection()->seq() : null,
				]); ?>">
					<input type="hidden" name="widget_name" value="<?= htmlspecialchars((string)$widget['type_name']); ?>">
					<button type="submit" class="dropdown-item">
						<?= htmlspecialchars((string)($widget['name'] ?? $widget['type_name'])); ?>
					</button>
				</form>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
