<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$nodeData = $this->props['data'][0];
$nodeId = $nodeData['node_id'];
?>
<h6 class="mb-3">
	<i class="bi bi-globe me-2"></i><?= Config::APP_SITE_NAME->value(); ?>
</h6>

<div class="d-grid gap-2">

	<?php if ($this->props['indexpage_node_id'] === false): ?>
		<a href="<?= form_url(FormList::WEBPAGEPAGE, null, null, [
			'formdata-resource_name' => 'index',
			'ref_id' => ($nodeId | 0),
		]); ?>" class="btn btn-warning btn-sm text-start">
			<i class="bi bi-exclamation-triangle me-2"></i><?= e($this->strings['cms.resource_browser.create_index_page']) ?>
		</a>
	<?php else: ?>
		<?php if (ResourceAcl::canAccessResource($this->props['indexpage_data']['node_id'], ResourceAcl::_ACL_VIEW)): ?>
			<a href="<?= event_url('resource.view', [
				'folder' => $this->props['indexpage_data']['path'],
				'resource' => $this->props['indexpage_data']['resource_name'],
				'domain_context' => ResourceTypeRoot::getDomainContextForResource($nodeId),
			]); ?>" target="_blank" class="btn btn-outline-secondary btn-sm text-start">
				<i class="bi bi-eye me-2"></i><?= e($this->strings['cms.resource_browser.preview_index_page']) ?>
			</a>
		<?php endif; ?>
	<?php endif; ?>

	<?php if (ResourceAcl::canAccessResource($nodeId, ResourceAcl::_ACL_EDIT) && Roles::hasRole(RoleList::ROLE_DOMAINS_ADMIN)): ?>
		<a href="<?= form_url(FormList::WEBPAGEDOMAIN, $nodeId); ?>" class="btn btn-outline-secondary btn-sm text-start">
			<i class="bi bi-gear me-2"></i><?= e($this->strings['resource.properties']) ?>
		</a>
	<?php endif; ?>

	<?php if (ResourceAcl::canAccessResource($nodeId, ResourceAcl::_ACL_CREATE)): ?>
		<a href="<?= form_url(FormList::WEBPAGEFOLDER, null, null, ['ref_id' => ($nodeId | 0)]); ?>" class="btn btn-outline-primary btn-sm text-start">
			<i class="bi bi-folder-plus me-2"></i><?= e($this->strings['resource.new_folder']) ?>
		</a>
		<a href="<?= form_url(FormList::WEBPAGEPAGE, null, null, ['ref_id' => ($nodeId | 0)]); ?>" class="btn btn-outline-primary btn-sm text-start">
			<i class="bi bi-file-earmark-plus me-2"></i><?= e($this->strings['resource.new_webpage']) ?>
		</a>
	<?php endif; ?>

	<?php if (ResourceAcl::canAccessResource(ResourceTreeHandler::getFolderId($nodeId), ResourceAcl::_ACL_CREATE)): ?>
		<a href="<?= widget_url(WidgetList::FILEUPLOAD) . '?ref_id=' . ResourceTreeHandler::getFolderId($nodeId); ?>" class="btn btn-outline-primary btn-sm text-start">
			<i class="bi bi-upload me-2"></i><?= e($this->strings['resource.upload_file']) ?>
		</a>
	<?php endif; ?>

	<?php if (Roles::hasRole(RoleList::ROLE_ACL_VIEWER) || Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER)): ?>
		<a href="<?= widget_url(WidgetList::RESOURCEACLSELECTOR) . 'resource--' . $nodeId; ?>" class="btn btn-outline-secondary btn-sm text-start">
			<i class="bi bi-shield-lock me-2"></i><?= e($this->strings['resource.security']) ?>
		</a>
	<?php endif; ?>

</div>

<hr class="my-3 opacity-25">

<?= $this->fetchSlot('help'); ?>
