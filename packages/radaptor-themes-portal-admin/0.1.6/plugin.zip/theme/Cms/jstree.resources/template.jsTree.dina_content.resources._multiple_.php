<?php assert(isset($this) && $this instanceof Template); ?>
<?php
// Build delete URL with array params for multi-select
$deleteUrl = Url::getAjaxUrl('Jstree.resourcesAjaxDeleteRecursive', ['jstree_id' => $this->props['jstree_id']]);
$deleteUrl .= '&' . http_build_query(['id' => $this->props['id']]);
?>
<h6 class="mb-3">
	<i class="bi bi-check2-square me-2"></i><?= e($this->strings['selection.group']) ?>
</h6>

<div class="d-grid gap-2">

	<button class="btn btn-outline-danger btn-sm text-start" type="button"
		hx-get="<?= htmlspecialchars($deleteUrl, ENT_QUOTES); ?>"
		hx-confirm="<?= e($this->strings['selection.delete_selected_confirm']) ?>"
		hx-swap="none">
		<i class="bi bi-trash me-2"></i><?= e($this->strings['selection.delete_selected']) ?>
	</button>

</div>

<hr class="my-3 opacity-25">

<h6 class="small text-muted mb-2"><?= e($this->strings['selection.selected_items']) ?>:</h6>

<ul class="list-unstyled small">
	<?php foreach ($this->props['id'] as $id): ?>
		<?php $data = ResourceTreeHandler::getResourceTreeEntryDataById($id); ?>
		<?php if ($data): ?>
			<li class="mb-1">
				<i class="bi bi-dot me-1"></i><?= htmlspecialchars($data['title'] ?? $data['resource_name']); ?>
			</li>
		<?php endif; ?>
	<?php endforeach; ?>
</ul>

<hr class="my-3 opacity-25">

<?= $this->fetchSlot('help'); ?>
