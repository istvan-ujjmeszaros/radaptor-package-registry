<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$widgetName = $this->props['widgetName'];
$templateName = $this->props['templateName'];
$currentTheme = $this->props['currentTheme'];
$templateScopeNote = (string)($this->props['templateScopeNote'] ?? '');
$themesWithWidgetTemplate = $this->props['themesWithWidgetTemplate'];
$allThemes = $this->props['allThemes'];
$themesWithoutWidgetTemplate = array_diff($allThemes, $themesWithWidgetTemplate);
$jsonPreviewUrl = (string)($this->props['jsonPreviewUrl'] ?? '');
$serverPreviewTitle = (string)($this->props['serverPreviewTitle'] ?? 'Server HTML preview');
$jsonPreviewTitle = (string)($this->props['jsonPreviewTitle'] ?? 'Widget subtree JSON');
$jsonPreviewDescription = (string)($this->props['jsonPreviewDescription'] ?? '');
$openJsonLabel = (string)($this->props['openJsonLabel'] ?? 'Open JSON');
?>
<div class="widget-preview-info mb-4 p-3 bg-body-tertiary border rounded">
	<h5 class="mb-2"><?= e($this->strings['cms.widget_preview.info.title']) ?></h5>
	<table class="table table-sm mb-3">
		<tr>
			<th style="width: 150px;"><?= e($this->strings['cms.widget_preview.info.widget']) ?>:</th>
			<td><code><?= htmlspecialchars($widgetName, ENT_QUOTES | ENT_SUBSTITUTE); ?></code></td>
		</tr>
		<tr>
			<th><?= e($this->strings['cms.widget_preview.info.template']) ?>:</th>
			<td><code><?= htmlspecialchars($templateName, ENT_QUOTES | ENT_SUBSTITUTE); ?></code></td>
		</tr>
		<tr>
			<th><?= e($this->strings['cms.widget_preview.info.current_theme']) ?>:</th>
			<td><strong><?= htmlspecialchars($currentTheme, ENT_QUOTES | ENT_SUBSTITUTE); ?></strong></td>
		</tr>
	</table>
	<?php if (count($themesWithWidgetTemplate) > 0): ?>
		<div class="mb-2">
			<small class="text-muted"><?= e($this->strings['cms.widget_preview.info.implemented']) ?>:</small>
			<?php foreach ($themesWithWidgetTemplate as $theme): ?>
				<?php if ($theme === $currentTheme): ?>
					<strong class="ms-2"><?= htmlspecialchars($theme, ENT_QUOTES | ENT_SUBSTITUTE); ?></strong>
				<?php else: ?>
					<a class="ms-2" href="?<?= http_build_query(['widget' => $widgetName, 'theme' => $theme]); ?>"><?= htmlspecialchars($theme, ENT_QUOTES | ENT_SUBSTITUTE); ?></a>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<?php if (count($themesWithoutWidgetTemplate) > 0): ?>
		<div class="mb-2">
			<small class="text-muted"><?= e($this->strings['cms.widget_preview.info.fallback']) ?>:</small>
			<?php foreach ($themesWithoutWidgetTemplate as $theme): ?>
				<?php if ($theme === $currentTheme): ?>
					<strong class="text-secondary ms-2"><?= htmlspecialchars($theme, ENT_QUOTES | ENT_SUBSTITUTE); ?></strong>
				<?php else: ?>
					<a class="text-secondary ms-2" href="?<?= http_build_query(['widget' => $widgetName, 'theme' => $theme]); ?>"><?= htmlspecialchars($theme, ENT_QUOTES | ENT_SUBSTITUTE); ?></a>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<?php if ($templateScopeNote !== ''): ?>
		<div class="small text-body-secondary"><?= e($templateScopeNote) ?></div>
	<?php endif; ?>
</div>
<div class="card shadow-sm mb-4">
	<div class="card-header">
		<h6 class="mb-0"><?= e($serverPreviewTitle) ?></h6>
	</div>
	<div class="card-body">
		<?= $this->fetchSlot('preview'); ?>
	</div>
</div>
<div class="card shadow-sm" data-controller="sdui-json-preview" data-sdui-json-preview-json-url-value="<?= e($jsonPreviewUrl) ?>" data-sdui-json-preview-preview-component-value="widgetPreviewInfo" data-sdui-json-preview-preview-slot-value="preview">
	<div class="card-header d-flex justify-content-between align-items-center">
		<div>
			<h6 class="mb-0"><?= e($jsonPreviewTitle) ?></h6>
			<?php if ($jsonPreviewDescription !== ''): ?>
				<small class="text-body-secondary"><?= e($jsonPreviewDescription) ?></small>
			<?php endif; ?>
		</div>
		<?php if ($jsonPreviewUrl !== ''): ?>
			<a class="btn btn-sm btn-outline-secondary" href="<?= e($jsonPreviewUrl) ?>" target="_blank" rel="noreferrer"><?= e($openJsonLabel) ?></a>
		<?php endif; ?>
	</div>
	<div class="card-body">
		<div class="alert alert-secondary mb-3" data-sdui-json-preview-target="status">Loading JSON preview…</div>
		<div class="small text-body-secondary mb-3">
			<?= e('Showing the widget subtree extracted from the full SDUI JSON document.') ?>
		</div>
		<pre class="small bg-dark text-light rounded p-3 mb-0" style="overflow: auto; min-height: 480px;" data-sdui-json-preview-target="source"></pre>
	</div>
</div>
