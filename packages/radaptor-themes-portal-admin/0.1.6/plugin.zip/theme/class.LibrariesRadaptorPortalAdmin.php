<?php

/**
 * Libraries for RadaptorPortalAdmin theme.
 *
 * Uses Bootstrap 5, htmx, and Stimulus for modern frontend.
 * jQuery is only loaded when DataTables/jsTree are needed.
 *
 * Stimulus controllers are auto-loaded via ES modules when data-controller
 * attributes are detected in the DOM. No manual controller registration needed.
 */
class LibrariesRadaptorPortalAdmin extends LibrariesCommon
{
	/**
	 * Base CSS for the admin theme.
	 * Loads shared base (Bootstrap + overrides) then theme-specific styles.
	 */
	public const string __RADAPTOR_PORTAL_ADMIN_BASE = '
		/assets/packages/themes/radaptor-portal-admin/css/radaptor-base.css,
		/assets/packages/themes/radaptor-portal-admin/css/radaptor-portal-admin.css,
		/assets/packages/themes/radaptor-portal-admin/css/forms.css,
	';

	/**
	 * Stimulus auto-loader (ES module).
	 *
	 * Uses a MutationObserver to automatically load controllers when
	 * data-controller attributes appear in the DOM. Works with:
	 * - Initial page load
	 * - AJAX-loaded content
	 * - htmx swaps
	 *
	 * Controllers are loaded from /assets/packages/radaptor-portal-admin/controllers/{name}-controller.js
	 * Path is configured via window.__RADAPTOR__ injected by PHP.
	 *
	 * Note: ES modules are always deferred, so they render in <head> automatically.
	 */
	public const string STIMULUS_LOADER = '
		module:/assets/packages/radaptor-portal-admin/js/stimulus-loader.js,
	';

	/**
	 * Utility scripts for the admin theme.
	 * These are regular scripts (not Stimulus controllers):
	 * - system-messages.js: renderSystemMessages() global function
	 * - htmx-config.js: htmx configuration and event handlers.
	 */
	public const string STIMULUS_UTILITIES = '
		/assets/packages/radaptor-portal-admin/js/system-messages.js,
		/assets/packages/radaptor-portal-admin/js/htmx-config.js,
	';

	/**
	 * Core admin site bundle: CSS + htmx + Stimulus auto-loader + utilities.
	 *
	 * Controllers (sidebar, dropdown, flash, saved-indicator) auto-load
	 * when data-controller attributes are found in HTML.
	 */
	public const string __RADAPTOR_PORTAL_ADMIN_SITE = '
		__RADAPTOR_PORTAL_ADMIN_BASE,
		css:https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css,
		js:https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js,
		js:https://unpkg.com/htmx.org@2.0.4,
		STIMULUS_LOADER,
		STIMULUS_UTILITIES,
	';

	/**
	 * Bundle for pages that need DataTables.
	 */
	public const string __RADAPTOR_PORTAL_ADMIN_DATATABLES = '
		__RADAPTOR_PORTAL_ADMIN_SITE,
		JQUERY,
		DATATABLES_FILTER,
	';

	/**
	 * jsTree 3.3.17 - modern version from CDN.
	 * Overrides the old jsTree 1.0-rc3 from LibrariesCommon.
	 * Used by __ADMIN_RESOURCES, __ADMIN_USERGROUPS, __ADMIN_ROLE_SELECTOR.
	 * Includes htmx for infopanel buttons (hx-get, hx-confirm, etc.).
	 */
	public const string JSTREE = '
		JQUERY,
		js:https://unpkg.com/htmx.org@2.0.4,
		js:https://cdnjs.cloudflare.com/ajax/libs/jstree/3.3.17/jstree.min.js,
	';

	/**
	 * Resource tree browser using jsTree 3.3.17.
	 * Stimulus controllers (jstree-base, jstree-resources) auto-load.
	 */
	public const string __ADMIN_RESOURCES = '
		__RADAPTOR_PORTAL_ADMIN_SITE,
		JSTREE,
	';

	/**
	 * Usergroups tree browser using jsTree 3.3.17.
	 * Stimulus controllers (jstree-base, jstree-usergroups) auto-load.
	 */
	public const string __ADMIN_USERGROUPS = '
		__RADAPTOR_PORTAL_ADMIN_SITE,
		JSTREE,
	';

	/**
	 * Roles tree browser using jsTree 3.3.17.
	 * Stimulus controllers (jstree-base, jstree-roles) auto-load.
	 */
	public const string __ADMIN_ROLES = '
		__RADAPTOR_PORTAL_ADMIN_SITE,
		JSTREE,
	';

	/**
	 * Role selector tree using jsTree 3.3.17 with checkboxes.
	 * Stimulus controllers (jstree-selector-base, jstree-role-selector) auto-load.
	 */
	public const string __ADMIN_ROLE_SELECTOR = '
		__RADAPTOR_PORTAL_ADMIN_SITE,
		JSTREE,
	';

	/**
	 * Usergroup selector tree using jsTree 3.3.17 with checkboxes.
	 * Stimulus controllers (jstree-selector-base, jstree-usergroup-selector) auto-load.
	 */
	public const string __ADMIN_USERGROUP_SELECTOR = '
		__RADAPTOR_PORTAL_ADMIN_SITE,
		JSTREE,
	';

	/**
	 * Admin menu tree browser using jsTree 3.3.17.
	 * Stimulus controller (jstree-adminmenu) auto-loads.
	 */
	public const string __ADMIN_ADMINMENU = '
		__RADAPTOR_PORTAL_ADMIN_SITE,
		JSTREE,
	';

	/**
	 * Edit mode CSS - widget editing, insert blocks, editBar toolbar.
	 * This is theme-specific (each theme has its own edit mode styling).
	 */
	public const string __ADMIN_EDIT_MODE = '
		/assets/packages/themes/radaptor-portal-admin/css/edit-mode.css,
	';

	/**
	 * jQuery 3.7.x - modern version (no jquery-migrate needed).
	 * DataTables 2.x avoids the removed $.browser API.
	 * The ^ prefix loads in <head> so inline scripts can use jQuery.
	 */
	public const string JQUERY = '
		js:^https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js,
	';

	/**
	 * jQuery UI 1.14.x - compatible with jQuery 3.7.x.
	 * Overrides the old JQUERY_UI_10 from LibrariesCommon.
	 * Used for autocomplete in ACL selector.
	 */
	public const string JQUERY_UI = '
		JQUERY,
		css:https://cdn.jsdelivr.net/npm/jquery-ui@1.14.1/dist/themes/base/jquery-ui.min.css,
		js:https://cdn.jsdelivr.net/npm/jquery-ui@1.14.1/dist/jquery-ui.min.js,
	';

	/**
	 * DataTables 2.2.x with Bootstrap 5 integration.
	 * Custom styling in _datatables.scss (compiled into radaptor-portal-admin.css).
	 * Theme CSS loads after CDN CSS via __RADAPTOR_PORTAL_ADMIN_DATATABLES bundle.
	 */
	public const string DATATABLES = '
		JQUERY,
		css:https://cdn.datatables.net/2.2.0/css/dataTables.bootstrap5.min.css,
		js:https://cdn.datatables.net/2.2.0/js/dataTables.min.js,
		js:https://cdn.datatables.net/2.2.0/js/dataTables.bootstrap5.min.js,
	';

	/**
	 * DataTables with filter functionality.
	 * DataTables 2.x has built-in filtering, no extra plugin needed.
	 */
	public const string DATATABLES_FILTER = '
		DATATABLES,
	';

	/**
	 * User list with DataTables 2.x.
	 */
	public const string __ADMIN_USERLIST = '
		__RADAPTOR_PORTAL_ADMIN_DATATABLES,
		/assets/packages/themes/radaptor-portal-admin/js/widgettype.userList.js,
	';

	/**
	 * Resource ACL selector with htmx + Stimulus.
	 * Uses jQuery UI autocomplete for user/usergroup search.
	 * The acl-selector controller auto-loads via data-controller attribute.
	 */
	public const string __ADMIN_RESOURCE_ACL_SELECTOR = '
		__RADAPTOR_PORTAL_ADMIN_SITE,
		JQUERY_UI,
	';

	public const string __ADMIN_SITE = '';

	public const string __COMMON_ADMIN = '';

	/**
	 * Keep jQuery and jQuery UI for widgets that need them.
	 */
	public const string _ADMINISTER = '
		JQUERY,
		JQUERY_UI_10,
	';

	// =========================================================================
	// Modern form component libraries (no jQuery dependency)
	// =========================================================================

	/**
	 * Flatpickr date/time picker - no jQuery dependency
	 * https://flatpickr.js.org/
	 * The flatpickr controller auto-loads via data-controller attribute.
	 */
	public const string FLATPICKR = '
		css:https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.css,
		js:https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.js,
		js:https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/l10n/hu.js,
	';

	/**
	 * Override old CALENDAR to use Flatpickr instead of JSCalendar.
	 */
	public const string CALENDAR = '
		FLATPICKR,
	';

	/**
	 * CKEditor 5 Classic Build - no jQuery dependency (default WYSIWYG editor)
	 * https://ckeditor.com/ckeditor-5/
	 * Using jsDelivr CDN (no license key required for classic build)
	 * The ckeditor controller auto-loads via data-controller attribute.
	 */
	public const string CKEDITOR = '
		js:https://cdn.jsdelivr.net/npm/@ckeditor/ckeditor5-build-classic@43.0.0/build/ckeditor.js,
	';

	/**
	 * CKEditor source version (same as CKEDITOR for CKEditor 5).
	 */
	public const string CKEDITOR_SOURCE = '
		CKEDITOR,
	';

	/**
	 * CodeMirror 6 - no jQuery dependency (for code editing)
	 * https://codemirror.net/
	 * Uses ES modules loaded dynamically via the controller.
	 * The codemirror controller auto-loads via data-controller attribute.
	 */
	public const string CODEMIRROR = '';

	/**
	 * Prism.js syntax highlighter with common languages.
	 * https://prismjs.com/
	 * Includes: PHP, Twig, markup, CSS, JavaScript.
	 */
	public const string PRISM = '
		css:https://cdn.jsdelivr.net/npm/prismjs@1.29.0/themes/prism-tomorrow.min.css,
		js:https://cdn.jsdelivr.net/npm/prismjs@1.29.0/prism.min.js,
		js:https://cdn.jsdelivr.net/npm/prismjs@1.29.0/components/prism-markup-templating.min.js,
		js:https://cdn.jsdelivr.net/npm/prismjs@1.29.0/components/prism-php.min.js,
		js:https://cdn.jsdelivr.net/npm/prismjs@1.29.0/components/prism-twig.min.js,
	';
}
