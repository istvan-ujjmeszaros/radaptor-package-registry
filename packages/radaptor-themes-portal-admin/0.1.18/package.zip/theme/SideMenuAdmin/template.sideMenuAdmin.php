<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$phpinfoUrl = defined(WidgetList::class . '::PHPINFOFRAME')
	? widget_url((string) constant(WidgetList::class . '::PHPINFOFRAME'))
	: event_url('system.phpinfo');
$mcpTokensUrl = defined(WidgetList::class . '::MCPTOKENS')
	? widget_url((string) constant(WidgetList::class . '::MCPTOKENS'))
	: '';
$mailpitWidget = defined(WidgetList::class . '::MAILPIT')
	? (string) constant(WidgetList::class . '::MAILPIT')
	: null;
$hasEmailsAdminRole = defined(RoleList::class . '::ROLE_EMAILS_ADMIN')
	&& Roles::hasRole((string) constant(RoleList::class . '::ROLE_EMAILS_ADMIN'));
$canShowMailpit = $mailpitWidget !== null
	&& Kernel::getEnvironment() !== 'production'
	&& (
		Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER)
		|| $hasEmailsAdminRole
	);
$canShowDeveloperTools = Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER) || $canShowMailpit;
$captureFormBuilderWidget = defined(WidgetList::class . '::CAPTUREFORMBUILDER')
	? trim((string) constant(WidgetList::class . '::CAPTUREFORMBUILDER'))
	: '';
$hasContentAdminRole = defined(RoleList::class . '::ROLE_CONTENT_ADMIN')
	&& Roles::hasRole((string) constant(RoleList::class . '::ROLE_CONTENT_ADMIN'));
?>
<ul class="nav flex-column sidebar-menu">
		<!-- Administration -->
		<li class="nav-item sidebar-section-title">
			<small class="text-muted text-uppercase px-3"><?= e($this->strings['admin.menu.section.administration']) ?></small>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::USERLIST); ?>">
				<i class="bi bi-people me-2"></i>
				<span><?= e($this->strings['user.list.title']) ?></span>
			</a>
		</li>
	<?php if ($mcpTokensUrl !== ''): ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= $mcpTokensUrl; ?>">
				<i class="bi bi-key me-2"></i>
				<span><?= e($this->strings['admin.menu.mcp_tokens']) ?></span>
			</a>
		</li>
	<?php endif; ?>
	<?php if (Roles::hasRole(RoleList::ROLE_USERGROUPS_ADMIN)): ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::USERGROUPLIST); ?>">
				<i class="bi bi-person-badge me-2"></i>
				<span><?= e($this->strings['admin.menu.usergroups']) ?></span>
			</a>
		</li>
	<?php endif; ?>
	<?php if (Roles::hasRole(RoleList::ROLE_ROLES_ADMIN)): ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::ROLELIST); ?>">
				<i class="bi bi-shield-check me-2"></i>
				<span><?= e($this->strings['admin.menu.roles']) ?></span>
			</a>
		</li>
	<?php endif; ?>

		<?php if ($captureFormBuilderWidget !== '' && $hasContentAdminRole): ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url($captureFormBuilderWidget); ?>">
				<i class="bi bi-ui-checks-grid me-2"></i>
				<span><?= e($this->strings['admin.menu.forms'] ?? t('admin.menu.forms')) ?></span>
			</a>
		</li>
	<?php endif; ?>

	<?php if (Roles::hasRole(RoleList::ROLE_SYSTEM_ADMINISTRATOR)): ?>
		<!-- Configuration -->
		<li class="nav-item sidebar-section-title">
			<small class="text-muted text-uppercase px-3"><?= e($this->strings['admin.menu.section.configuration']) ?></small>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::RESOURCETREE); ?>">
				<i class="bi bi-diagram-3 me-2"></i>
				<span><?= e($this->strings['admin.menu.resource_tree']) ?></span>
			</a>
		</li>
	<li class="nav-item">
		<a class="nav-link" href="<?= widget_url('I18nWorkbench'); ?>">
			<i class="bi bi-translate me-2"></i>
			<span><?= e($this->strings['admin.menu.translations']) ?></span>
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?= widget_url(WidgetList::IMPORTEXPORT); ?>">
			<i class="bi bi-arrow-down-up me-2"></i>
			<span><?= e($this->strings['admin.menu.import_export']) ?></span>
		</a>
	</li>
	<?php endif; ?>
	<?php if (Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER)): ?>
	<?php if (!Roles::hasRole(RoleList::ROLE_SYSTEM_ADMINISTRATOR)): ?>
		<!-- Configuration (header for developers without admin) -->
		<li class="nav-item sidebar-section-title">
			<small class="text-muted text-uppercase px-3"><?= e($this->strings['admin.menu.section.configuration']) ?></small>
		</li>
	<?php endif; ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::LOCALEADMIN); ?>">
				<i class="bi bi-globe2 me-2"></i>
				<span><?= e($this->strings['admin.menu.locales']) ?></span>
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::ADMINMENU); ?>">
				<i class="bi bi-list me-2"></i>
				<span><?= e($this->strings['admin.menu.admin_menu']) ?></span>
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= form_url(FormList::THEMESELECTOR, -1); ?>">
				<i class="bi bi-palette me-2"></i>
				<span><?= e($this->strings['admin.menu.theme_selector']) ?></span>
			</a>
		</li>
	<?php endif; ?>

	<?php if ($canShowDeveloperTools): ?>
		<!-- Developer Tools -->
		<li class="nav-item sidebar-section-title">
			<small class="text-muted text-uppercase px-3"><?= e($this->strings['admin.menu.section.developer_tools']) ?></small>
		</li>
		<?php if ($canShowMailpit): ?>
			<li class="nav-item">
				<a class="nav-link" href="<?= widget_url($mailpitWidget); ?>">
					<i class="bi bi-envelope-paper me-2"></i>
					<span><?= e($this->strings['admin.menu.mailpit'] ?? t('admin.menu.mailpit')) ?></span>
				</a>
			</li>
		<?php endif; ?>
	<?php endif; ?>

	<?php if (Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER)): ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::WIDGETPREVIEW); ?>">
				<i class="bi bi-puzzle me-2"></i>
				<span><?= e($this->strings['admin.menu.widget_preview']) ?></span>
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= $phpinfoUrl; ?>">
				<i class="bi bi-info-circle me-2"></i>
				<span><?= e($this->strings['admin.menu.phpinfo']) ?></span>
			</a>
		</li>
		<?php if (defined(WidgetList::class . '::RUNTIMEDIAGNOSTICS')): ?>
			<li class="nav-item">
				<a class="nav-link" href="<?= widget_url((string) constant(WidgetList::class . '::RUNTIMEDIAGNOSTICS')); ?>">
					<i class="bi bi-activity me-2"></i>
					<span><?= e($this->strings['admin.menu.runtime_diagnostics'] ?? t('admin.menu.runtime_diagnostics')) ?></span>
				</a>
			</li>
		<?php endif; ?>
		<li class="nav-item">
			<a class="nav-link" href="/admin/demo/template-engines.html">
				<i class="bi bi-file-earmark-code me-2"></i>
				<span><?= e($this->strings['admin.menu.template_engines']) ?></span>
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="/admin/developer/cli-runner.html">
				<i class="bi bi-terminal me-2"></i>
				<span><?= e($this->strings['admin.menu.cli_runner']) ?></span>
			</a>
		</li>
	<?php endif; ?>
</ul>
