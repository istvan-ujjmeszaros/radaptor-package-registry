import { Controller } from "/assets/packages/radaptor-portal-admin/js/stimulus.js"

export default class extends Controller {
    static targets = [
        "status",
        "definitionSelect",
        "previewFrame",
        "undoButton",
        "redoButton",
        "moveUpButton",
        "moveDownButton",
        "deleteButton",
        "saveButton",
        "publishButton",
        "usageButton",
        "draftsButton",
        "conflictActions",
        "propertiesPanel",
        "emptyProperties",
        "fieldProperties",
        "formTabButton",
        "inputTabButton",
        "formPropertiesPane",
        "inputPropertiesPane",
        "usageModal",
        "draftsModal",
        "draftsList",
        "previewOverlay",
        "formTitleInput",
        "formDescriptionInput",
        "submitLabelInput",
        "formTitleTranslationLink",
        "formDescriptionTranslationLink",
        "submitLabelTranslationLink",
        "i18nModeInput",
        "translationsLink",
        "fieldLabelInput",
        "fieldLabelTranslationLink",
        "fieldNameInput",
        "fieldKeyInput",
        "fieldRequiredInput",
        "fieldRequiredTranslationLink",
        "fieldOptionsGroup",
        "fieldOptionsInput",
        "fieldOptionsTranslationLink",
    ]

    static values = {
        state: Object,
        strings: Object,
        createUrl: String,
        previewUrl: String,
        saveUrl: String,
        publishUrl: String,
        loadDraftUrl: String,
        updateDraftNoteUrl: String,
        csrfToken: String,
    }

    connect() {
        this.state = this.stateValue || {}
        this.strings = this.stringsValue || {}
        this.descriptor = this.clone(this.state.descriptor || { kind: "capture", fields: [] })
        this.serverDescriptor = this.clone(this.state.server_descriptor || this.descriptor)
        this.serverDescriptorJson = this.descriptorJson(this.serverDescriptor)
        this.definitionSlug = String(this.state.definition_slug || "")
        this.baseServerHash = String(this.state.base_server_hash || "")
        this.readOnly = Boolean(this.state.read_only)
        this.activeDraft = this.state.active_draft || null
        this.publishedVersion = this.state.published_version || null
        this.hasPublishedVersion = Boolean(this.publishedVersion)
        this.versions = Array.isArray(this.state.versions) ? this.state.versions : []
        this.loadedVersion = this.state.loaded_version || null
        this.usage = Array.isArray(this.state.usage) ? this.state.usage : []
        this.i18nAvailable = Boolean(this.state.i18n_available)
        this.defaultLocale = String(this.state.default_locale || "")
        this.translationUrl = String(this.state.translation_url || "")
        this.i18nWorkbenchUrl = String(this.state.i18n_workbench_url || "")
        this.activePanel = this.normalizePanel(this.state.initial_panel || "form")
        this.palette = new Map((this.state.palette || []).map((item) => [item.type, item]))
        this.selectedIndex = null
        this.undoStack = []
        this.redoStack = []
        this.dragPayload = null
        this.previewHoverDropIndex = null
        this.dirty = false
        this.localConflict = false
        this.saving = false
        this.loadingDraftVersion = false
        this.localStateBaseServerHash = ""
        this.undoScope = ""
        this.undoScopeTimer = 0
        this.previewTimer = 0
        this.previewRequestId = 0
        this.initialPreview = this.state.initial_preview || {}
        this.initialPreviewHtml = String(this.initialPreview.html || this.state.initial_preview_html || "")
        if (this.initialPreviewHtml !== "") {
            this.initialPreview = { ...this.initialPreview, html: this.initialPreviewHtml }
        }
        this.previewAssets = {
            css: String(this.initialPreview.css || ""),
            jsTop: String(this.initialPreview.js_top || ""),
            js: String(this.initialPreview.js || ""),
        }
        this.boundPreviewMessage = (event) => this.receivePreviewMessage(event)
        this.boundPreviewFrameLoad = () => this.bindPreviewFrame()
        window.addEventListener("message", this.boundPreviewMessage)

        const restoredLocalState = this.loadLocalState()
        this.syncFormProperties()
        this.renderProperties()
        this.renderPanelTabs()
        this.renderDraftsList()
        if (restoredLocalState) {
            this.renderLocalPreview()
        } else {
            this.renderPreview(this.initialPreview)
        }
        this.updateButtons()
        this.element.dataset.formBuilderReady = "1"
    }

    disconnect() {
        window.clearTimeout(this.previewTimer)
        window.clearTimeout(this.undoScopeTimer)
        window.removeEventListener("message", this.boundPreviewMessage)
        if (this.hasPreviewFrameTarget) {
            this.previewFrameTarget.removeEventListener("load", this.boundPreviewFrameLoad)
        }
    }

    selectDefinition() {
        const slug = this.definitionSelectTarget.value
        const url = new URL(window.location.href)
        url.searchParams.set("definition_slug", slug)
        window.location.href = url.toString()
    }

    showFormPanel() {
        this.setActivePanel("form")
    }

    showInputPanel() {
        this.setActivePanel("input")
    }

    showPropertiesPanel() {
        this.showFormPanel()
    }

    showUsagePanel() {
        this.showUsageModal()
    }

    showUsageModal() {
        if (!this.hasUsageModalTarget) {
            return
        }

        this.usageModalTarget.hidden = false
        this.usageModalTarget.querySelector("a,button")?.focus()
    }

    closeUsageModal() {
        if (!this.hasUsageModalTarget) {
            return
        }

        if (this.usageModalTarget.hidden) {
            return
        }

        this.usageModalTarget.hidden = true
        if (this.hasUsageButtonTarget) {
            this.usageButtonTarget.focus()
        }
    }

    closeUsageModalOnBackdrop(event) {
        if (event.target === this.usageModalTarget) {
            this.closeUsageModal()
        }
    }

    showDraftsModal() {
        if (!this.hasDraftsModalTarget) {
            return
        }

        this.renderDraftsList()
        this.draftsModalTarget.hidden = false
        this.draftsModalTarget.querySelector("button,textarea")?.focus()
    }

    closeDraftsModal() {
        if (!this.hasDraftsModalTarget) {
            return
        }

        if (this.draftsModalTarget.hidden) {
            return
        }

        this.draftsModalTarget.hidden = true
        if (this.hasDraftsButtonTarget) {
            this.draftsButtonTarget.focus()
        }
    }

    closeDraftsModalOnBackdrop(event) {
        if (event.target === this.draftsModalTarget) {
            this.closeDraftsModal()
        }
    }

    async create(event) {
        event.preventDefault()
        const formData = new FormData(event.currentTarget)
        formData.set("csrf_token", this.csrfTokenValue)

        try {
            const payload = await this.postForm(this.createUrlValue, formData)
            const slug = payload?.data?.definition?.definition_slug || formData.get("definition_slug")
            const url = new URL(window.location.href)
            url.searchParams.set("definition_slug", slug)
            window.location.href = url.toString()
        } catch (error) {
            this.setStatus(this.errorMessage(error, "form.builder.error_create"))
        }
    }

    preparePaletteDrag(event) {
        if (this.readOnly) {
            return
        }

        this.dragPayload = {
            kind: "palette",
            fieldType: event.params.paletteType,
        }
    }

    dragPaletteItem(event) {
        if (this.readOnly) {
            event.preventDefault()

            return
        }

        this.preparePaletteDrag(event)
        event.dataTransfer?.setData("text/plain", JSON.stringify(this.dragPayload))
        if (event.dataTransfer) {
            event.dataTransfer.effectAllowed = "copy"
        }
        this.showPreviewDropOverlay()
    }

    endPaletteDrag() {
        this.clearPreviewDropZones()
        this.hidePreviewDropOverlay()
        this.dragPayload = null
    }

    addPaletteItem(event) {
        if (this.readOnly) {
            return
        }

        this.addField(event.params.paletteType, this.descriptor.fields.length)
        this.clearPreviewDropZones()
        this.hidePreviewDropOverlay()
        this.dragPayload = null
    }

    undo() {
        if (this.undoStack.length === 0 || this.readOnly) {
            return
        }

        this.redoStack.push(this.snapshot())
        this.resetUndoScope()
        this.restoreSnapshot(this.undoStack.pop())
        this.markDirty(false)
    }

    redo() {
        if (this.redoStack.length === 0 || this.readOnly) {
            return
        }

        this.undoStack.push(this.snapshot())
        this.resetUndoScope()
        this.restoreSnapshot(this.redoStack.pop())
        this.markDirty(false)
    }

    moveSelectedUp() {
        this.moveSelected(-1)
    }

    moveSelectedDown() {
        this.moveSelected(1)
    }

    deleteSelected() {
        if (this.readOnly || this.selectedIndex === null) {
            return
        }

        this.pushUndo()
        this.descriptor.fields.splice(this.selectedIndex, 1)
        this.selectedIndex = null
        this.setActivePanel("form")
        this.markDirty()
    }

    updateFormText(event) {
        if (this.readOnly) {
            return
        }

        this.pushUndo(this.undoScopeForEvent("form", event))
        this.descriptor.title = this.textDefinition("title", this.formTitleInputTarget.value)
        this.descriptor.description = this.textDefinition("description", this.formDescriptionInputTarget.value)
        this.descriptor.submit_label = this.textDefinition("submit_label", this.submitLabelInputTarget.value)
        this.markDirty()
    }

    toggleI18nMode(event) {
        if (this.readOnly) {
            return
        }

        const enabled = Boolean(event?.target?.checked)
        this.pushUndo("form:i18n_mode")
        this.descriptor.i18n_mode = enabled ? "keyed" : "literal"

        if (enabled) {
            this.normalizeDescriptorI18n()
        } else {
            this.literalizeDescriptorI18n()
        }

        this.markDirty()
    }

    updateSelectedField(event) {
        if (this.readOnly || this.selectedIndex === null) {
            return
        }

        const field = this.descriptor.fields[this.selectedIndex]
        if (!field) {
            return
        }

        const nextName = this.fieldNameInputTarget.value
        if ((field.key || "") === "" && this.hasFieldIdentifierConflict(nextName, this.selectedIndex)) {
            this.fieldNameInputTarget.value = field.name || ""
            this.setStatus(this.s("form.builder.error_duplicate_field_key"))
            return
        }

        this.pushUndo(this.undoScopeForEvent(`field:${this.selectedIndex}`, event))
        field.name = nextName
        field.label = this.textDefinition(`fields.${this.fieldI18nSegment(field)}.label`, this.fieldLabelInputTarget.value)
        field.required = this.fieldRequiredInputTarget.checked
        this.syncRequiredValidator(field)

        if (this.isOptionField(field.type)) {
            const options = this.parseOptions(this.fieldOptionsInputTarget.value, field)
            field.values = options
            this.syncEnumValidator(field, options.map((option) => option.value))
        }

        this.markDirty()
    }

    confirmAndUpdateFieldKey() {
        if (this.readOnly || this.selectedIndex === null) {
            return
        }

        const field = this.descriptor.fields[this.selectedIndex]
        if (!field) {
            return
        }

        const nextKey = this.fieldKeyInputTarget.value
        const oldKey = field.key || field.name || ""

        if (this.hasFieldIdentifierConflict(nextKey, this.selectedIndex)) {
            this.fieldKeyInputTarget.value = oldKey
            this.setStatus(this.s("form.builder.error_duplicate_field_key"))
            return
        }

        if (this.hasPublishedVersion && oldKey !== "" && nextKey !== oldKey && !window.confirm(this.s("form.builder.warning.key_change"))) {
            this.fieldKeyInputTarget.value = oldKey
            return
        }

        this.pushUndo(`field:${this.selectedIndex}:key`)
        field.key = nextKey
        this.normalizeFieldI18n(field)
        this.markDirty()
    }

    saveDraftAction(event) {
        event?.preventDefault()
        this.saveDraft(false)
    }

    async saveDraft(overwrite = false) {
        const shouldOverwrite = overwrite === true

        if (this.readOnly || this.definitionSlug === "") {
            return false
        }

        if (this.localConflict && !shouldOverwrite) {
            this.showConflict()

            return false
        }

        if (this.saving) {
            return false
        }

        this.saving = true
        this.updateButtons()
        this.setStatus(this.s("form.builder.status.saving"))
        const formData = this.baseFormData()
        formData.set("base_server_hash", this.baseServerHash)
        formData.set("overwrite", shouldOverwrite ? "1" : "0")

        try {
            const payload = await this.postForm(this.saveUrlValue, formData, true)
            const result = payload.data || {}

            if (result.status === "conflict") {
                this.showConflict()
                return false
            }

            this.applyServerState(result)
            this.dirty = false
            this.clearLocalState()
            this.setStatus(result.action === "matches_published" ? this.s("form.builder.status.clean") : this.s("form.builder.status.saved"))
            this.updateButtons()
            this.dispatchDirtyChange()
            this.dispatchBuilderChanged("save_draft", result)
            return true
        } catch {
            this.setStatus(this.s("form.builder.error_save"))
            return false
        } finally {
            this.saving = false
            this.updateButtons()
            this.renderDraftsList()
        }
    }

    async publish() {
        if (this.readOnly || this.definitionSlug === "") {
            return
        }

        if (this.localConflict) {
            this.showConflict()

            return
        }

        if (this.dirty) {
            const saved = await this.saveDraft(false)

            if (!saved) {
                return
            }
        }

        const formData = new FormData()
        formData.set("definition_slug", this.definitionSlug)
        formData.set("csrf_token", this.csrfTokenValue)

        if (this.activeDraft?.version_id) {
            formData.set("version_id", this.activeDraft.version_id)
        }

        try {
            const payload = await this.postForm(this.publishUrlValue, formData)
            this.applyServerState(payload.data || {})
            this.hasPublishedVersion = true
            this.dirty = false
            this.clearLocalState()
            this.setStatus(this.s("form.builder.status.published"))
            this.updateButtons()
            this.dispatchDirtyChange()
            this.dispatchBuilderChanged("publish", payload.data || {})
        } catch {
            this.setStatus(this.s("form.builder.error_publish"))
        }
    }

    reloadServer() {
        this.clearLocalState()
        window.location.reload()
    }

    overwriteLocal() {
        this.localConflict = false
        this.localStateBaseServerHash = ""
        this.hideConflictActions()
        this.saveDraft(true)
    }

    async loadDraftVersion(event) {
        event?.preventDefault()

        if (this.readOnly || this.definitionSlug === "" || this.saving || this.loadingDraftVersion) {
            return
        }

        if (this.dirty && !window.confirm(this.s("form.builder.warning.load_draft_discard_unsaved"))) {
            return
        }

        const versionId = Number(event?.currentTarget?.dataset?.versionId || 0)

        if (!Number.isInteger(versionId) || versionId <= 0) {
            return
        }

        const formData = new FormData()
        formData.set("definition_slug", this.definitionSlug)
        formData.set("version_id", String(versionId))
        formData.set("csrf_token", this.csrfTokenValue)

        this.loadingDraftVersion = true
        this.updateButtons()
        this.renderDraftsList()

        try {
            const payload = await this.postForm(this.loadDraftUrlValue, formData)
            this.applyLoadedDraftState(payload.data || {})
            this.closeDraftsModal()
            this.setStatus(this.s("form.builder.status.loaded_draft"))
        } catch {
            this.setStatus(this.s("form.builder.error_load_draft"))
        } finally {
            this.loadingDraftVersion = false
            this.updateButtons()
            this.renderDraftsList()
        }
    }

    async updateDraftNote(event) {
        if (this.readOnly || this.definitionSlug === "" || this.saving || this.loadingDraftVersion) {
            return
        }

        const versionId = Number(event?.currentTarget?.dataset?.versionId || 0)

        if (!Number.isInteger(versionId) || versionId <= 0) {
            return
        }

        const formData = new FormData()
        formData.set("definition_slug", this.definitionSlug)
        formData.set("version_id", String(versionId))
        formData.set("author_note", String(event.currentTarget.value || ""))
        formData.set("csrf_token", this.csrfTokenValue)

        try {
            const payload = await this.postForm(this.updateDraftNoteUrlValue, formData)
            const state = payload.data || {}
            this.versions = Array.isArray(state.versions) ? state.versions : this.versions
            this.activeDraft = state.active_draft || this.activeDraft
            this.publishedVersion = state.published_version || this.publishedVersion
            this.hasPublishedVersion = this.hasPublishedVersion || Boolean(this.publishedVersion)
            this.renderDraftsList()
            this.setStatus(this.s("form.builder.status.draft_note_saved"))
        } catch {
            this.setStatus(this.s("form.builder.error_draft_note"))
        }
    }

    addField(type, index) {
        if (this.readOnly) {
            return
        }

        const item = this.palette.get(type)
        if (!item) {
            return
        }

        const field = this.clone(item.defaults || { type })
        const identifier = this.uniqueIdentifier(type)
        field.name = identifier
        field.key = identifier

        if (!field.label) {
            field.label = { text: item.label || identifier }
        }

        this.normalizeFieldI18n(field)

        this.pushUndo()
        this.descriptor.fields.splice(index, 0, field)
        this.selectedIndex = index
        this.setActivePanel("input")
        this.markDirty()
    }

    moveSelected(offset) {
        if (this.readOnly || this.selectedIndex === null) {
            return
        }

        const nextIndex = this.selectedIndex + offset
        const fields = this.descriptor.fields

        if (nextIndex < 0 || nextIndex >= fields.length) {
            return
        }

        this.pushUndo()
        const [field] = fields.splice(this.selectedIndex, 1)
        fields.splice(nextIndex, 0, field)
        this.selectedIndex = nextIndex
        this.setActivePanel("input")
        this.markDirty()
    }

    reorderField(fromIndex, toIndex) {
        if (this.readOnly || fromIndex === toIndex || fromIndex < 0 || toIndex < 0) {
            return
        }

        const fields = this.descriptor.fields

        if (fromIndex >= fields.length || toIndex > fields.length) {
            return
        }

        this.pushUndo()
        const [field] = fields.splice(fromIndex, 1)
        const adjustedTo = fromIndex < toIndex ? toIndex - 1 : toIndex
        fields.splice(adjustedTo, 0, field)
        this.selectedIndex = adjustedTo
        this.setActivePanel("input")
        this.markDirty()
    }

    markDirty(debounce = true) {
        this.dirty = this.descriptorJson(this.descriptor) !== this.serverDescriptorJson

        if (!this.dirty) {
            this.localConflict = false
            this.localStateBaseServerHash = ""
            this.hideConflictActions()
        }

        this.setStatus(this.s(this.localConflict ? "form.builder.status.conflict" : (this.dirty ? "form.builder.status.dirty" : "form.builder.status.clean")))
        this.dispatchDirtyChange()

        if (this.dirty) {
            this.persistLocalState()
        } else {
            this.clearLocalState()
        }

        this.syncFormProperties()
        this.renderProperties()
        this.updateButtons()

        window.clearTimeout(this.previewTimer)
        if (debounce) {
            this.previewTimer = window.setTimeout(() => this.renderLocalPreview(), 120)
        } else {
            this.renderLocalPreview()
        }
    }

    async renderPreview(initialPreview = null) {
        const initialHtml = typeof initialPreview === "string" ? initialPreview : String(initialPreview?.html || "")

        if (initialHtml !== "") {
            this.writePreviewDocument(
                initialHtml,
                String(initialPreview?.css || ""),
                String(initialPreview?.js_top || ""),
                String(initialPreview?.js || "")
            )
            this.previewAssets = {
                css: String(initialPreview?.css || ""),
                jsTop: String(initialPreview?.js_top || ""),
                js: String(initialPreview?.js || ""),
            }
            this.initialPreview = {}
            this.initialPreviewHtml = ""
            return
        }

        if (this.definitionSlug === "") {
            this.writePreviewDocument("")
            return
        }

        const formData = this.baseFormData()
        const requestId = ++this.previewRequestId
        const requestedDescriptorJson = this.descriptorJson(this.descriptor)

        try {
            const payload = await this.postForm(this.previewUrlValue, formData)
            const data = payload.data || {}

            if (requestId !== this.previewRequestId || requestedDescriptorJson !== this.descriptorJson(this.descriptor)) {
                return
            }

            this.descriptor = data.descriptor || this.descriptor
            this.previewAssets = {
                css: String(data.css || ""),
                jsTop: String(data.js_top || ""),
                js: String(data.js || ""),
            }
            this.writePreviewDocument(
                String(data.html || ""),
                this.previewAssets.css,
                this.previewAssets.jsTop,
                this.previewAssets.js
            )
        } catch {
            this.setStatus(this.s("form.builder.error_preview"))
        }
    }

    writePreviewDocument(html, css = "", jsTop = "", js = "") {
        const selectedCss = "html{color-scheme:dark}html,body{min-height:100%;background:#0f0f1a;color:#f8fafc}.radaptor-form-builder-field{outline:1px dashed transparent;outline-offset:4px}.radaptor-form-builder-field:hover{outline-color:#8b5cf6}.radaptor-form-builder-field-selected{outline:2px solid #8b5cf6!important}.radaptor-form-builder-drop{min-height:calc(100vh - 32px);border:1px dashed rgba(248,250,252,.28);border-radius:6px;padding:1rem;background:rgba(255,255,255,.03)}.radaptor-form-builder-drop-zone{box-sizing:border-box;height:0;margin:0;border:0 solid transparent;border-radius:6px;overflow:hidden;transition:height .12s ease,margin .12s ease,background-color .12s ease,border-color .12s ease}.radaptor-form-builder-drop-active .radaptor-form-builder-drop-zone{height:14px;margin:6px 0;border:1px dashed #8b5cf6;background:rgba(139,92,246,.12)}.radaptor-form-builder-drop-active .radaptor-form-builder-drop-zone-active{height:24px;margin:8px 0;background:rgba(139,92,246,.22);border-color:#a78bfa}"
        this.previewFrameTarget.removeEventListener("load", this.boundPreviewFrameLoad)
        this.previewFrameTarget.addEventListener("load", this.boundPreviewFrameLoad, { once: true })
        this.previewFrameTarget.srcdoc = `<!doctype html><html><head><meta charset="utf-8"><style>body{padding:16px}${selectedCss}</style>${css}${jsTop}</head><body><div data-controller="form-builder-preview-drop" data-action="dragenter->form-builder-preview-drop#dragEnter dragover->form-builder-preview-drop#dragOver dragleave->form-builder-preview-drop#dragLeave drop->form-builder-preview-drop#drop" data-form-builder-drop-root="1" class="radaptor-form-builder-drop">${html}</div>${js}</body></html>`
    }

    renderLocalPreview() {
        const doc = this.previewFrameTarget.contentDocument
        const dropRoot = doc?.querySelector("[data-form-builder-drop-root]")

        if (!doc || !dropRoot) {
            this.writePreviewDocument(
                this.localPreviewHtml(),
                this.previewAssets.css,
                this.previewAssets.jsTop,
                this.previewAssets.js
            )

            return
        }

        dropRoot.innerHTML = this.localPreviewHtml()
        this.bindPreviewFrame()
    }

    localPreviewHtml() {
        const title = this.displayTextValue(this.descriptor.title)
        const description = this.displayTextValue(this.descriptor.description)
        const submitLabel = this.displayTextValue(this.descriptor.submit_label) || this.s("form.capture.submit")
        const fields = Array.isArray(this.descriptor.fields) ? this.descriptor.fields : []

        return `<form id="fform_builder_preview" action="#" method="post" class="autogenerated sdui-form" data-form-id="${this.escapeAttr(this.definitionSlug || "capture-preview")}">`
            + `<div class="mb-4">`
            + (title !== "" ? `<h1 class="h4 mb-2">${this.escapeHtml(title)}</h1>` : "")
            + (description !== "" ? `<p class="text-body-secondary mb-0">${this.escapeHtml(description)}</p>` : "")
            + `</div>`
            + `<input type="hidden" name="form_id" value="${this.escapeAttr(this.definitionSlug || "capture-preview")}">`
            + `<input type="hidden" name="form_instance_id" value="form_builder_preview">`
            + `<div class="sdui-form-honeypot" aria-hidden="true" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;"><label for="fform_builder_preview_honeypot">${this.escapeHtml(this.s("form.capture.honeypot.label"))}</label><input id="fform_builder_preview_honeypot" type="text" name="company_website" value="" tabindex="-1" autocomplete="off"></div>`
            + fields.map((field, index) => this.localFieldHtml(field, index)).join("")
            + `<div class="d-flex flex-wrap gap-2 mt-4"><button class="btn btn-primary positive" type="submit" name="submit_button" value="save">${this.escapeHtml(submitLabel)}</button></div>`
            + `</form>`
    }

    localFieldHtml(field, index) {
        const type = String(field?.type || "text")
        const key = String(field?.key || field?.name || type)
        const name = String(field?.name || key)
        const label = this.displayTextValue(field?.label) || name
        const required = this.hasValidator(field, "required") ? " required" : ""
        const id = `fform_builder_preview_input_${index + 1}`
        const common = `id="${this.escapeAttr(id)}" name="${this.escapeAttr(key)}" data-field-key="${this.escapeAttr(key)}" data-form-builder-field-preview-index="${index}"${required}`

        if (type === "textarea") {
            return `<div id="row_${this.escapeAttr(id)}" class="row g-3 mb-1"><div class="col"><label class="form-label" for="${this.escapeAttr(id)}">${this.escapeHtml(label)}</label><textarea class="form-control" ${common}></textarea></div></div>`
        }

        if (type === "select") {
            const options = this.optionEntries(field).map((option) => {
                const value = typeof option === "string" ? option : String(option.value || "")
                const optionLabel = typeof option === "string" ? option : this.displayTextValue(option.label)
                return `<option value="${this.escapeAttr(value)}">${this.escapeHtml(optionLabel || value)}</option>`
            }).join("")

            return `<div id="row_${this.escapeAttr(id)}" class="row g-3 mb-1"><div class="col"><label class="form-label" for="${this.escapeAttr(id)}">${this.escapeHtml(label)}</label><select class="form-select" ${common}>${options}</select></div></div>`
        }

        if (type === "radiogroup") {
            const options = this.optionEntries(field).map((option, optionIndex) => {
                const value = typeof option === "string" ? option : String(option.value || "")
                const optionLabel = typeof option === "string" ? option : this.displayTextValue(option.label)
                const optionId = `${id}_${optionIndex + 1}`
                return `<div class="form-check"><input class="form-check-input" id="${this.escapeAttr(optionId)}" type="radio" name="${this.escapeAttr(key)}" data-field-key="${this.escapeAttr(key)}" data-form-builder-field-preview-index="${index}" value="${this.escapeAttr(value)}"${required}><label class="form-check-label" for="${this.escapeAttr(optionId)}">${this.escapeHtml(optionLabel || value)}</label></div>`
            }).join("")

            return `<div id="row_${this.escapeAttr(id)}" class="row g-3 mb-1"><div class="col"><fieldset><legend class="form-label">${this.escapeHtml(label)}</legend>${options}</fieldset></div></div>`
        }

        if (type === "checkbox") {
            return `<div id="row_${this.escapeAttr(id)}" class="row g-3 mb-1"><div class="col"><div class="form-check"><input class="form-check-input" type="checkbox" ${common} value="1"><label class="form-check-label" for="${this.escapeAttr(id)}">${this.escapeHtml(label)}</label></div></div></div>`
        }

        if (type === "checkboxgroup") {
            const options = this.optionEntries(field).map((option, optionIndex) => {
                const value = typeof option === "string" ? option : String(option.value || "")
                const optionLabel = typeof option === "string" ? option : this.displayTextValue(option.label)
                const optionId = `${id}_${optionIndex + 1}`
                return `<div class="form-check"><input class="form-check-input" id="${this.escapeAttr(optionId)}" type="checkbox" name="${this.escapeAttr(`${key}[${value}]`)}" data-field-key="${this.escapeAttr(key)}" data-form-builder-field-preview-index="${index}" value="1"${required}><label class="form-check-label" for="${this.escapeAttr(optionId)}">${this.escapeHtml(optionLabel || value)}</label></div>`
            }).join("")

            return `<div id="row_${this.escapeAttr(id)}" class="row g-3 mb-1"><div class="col"><fieldset><legend class="form-label">${this.escapeHtml(label)}</legend>${options}</fieldset></div></div>`
        }

        if (type === "date" || type === "datetime") {
            return `<div id="row_${this.escapeAttr(id)}" class="row g-3 mb-1"><div class="col"><label class="form-label" for="${this.escapeAttr(id)}">${this.escapeHtml(label)}</label><input class="form-control" type="text" ${common}></div></div>`
        }

        return `<div id="row_${this.escapeAttr(id)}" class="row g-3 mb-1"><div class="col"><label class="form-label" for="${this.escapeAttr(id)}">${this.escapeHtml(label)}</label><input class="form-control" type="text" ${common}></div></div>`
    }

    bindPreviewFrame() {
        const doc = this.previewFrameTarget.contentDocument
        if (!doc) {
            return
        }

        doc.querySelectorAll("form").forEach((form) => {
            form.addEventListener("submit", (event) => event.preventDefault())
        })
        doc.querySelectorAll('button[type="submit"],button[name="submit_button"]').forEach((button) => {
            button.disabled = true
        })

        const dropRoot = doc.querySelector("[data-form-builder-drop-root]") || doc.body
        if (dropRoot.dataset.formBuilderRootBound !== "1") {
            dropRoot.addEventListener("dragover", (event) => {
                event.preventDefault()
                this.previewHoverDropIndex = this.previewInsertIndexFromFramePoint(event.clientX, event.clientY)
            })
            dropRoot.addEventListener("drop", (event) => {
                const payload = this.dragPayload || this.payloadFromDataTransfer(event)

                if (payload?.kind === "field") {
                    this.handlePreviewDrop(event, null)
                }
            })
            dropRoot.addEventListener("click", (event) => {
                if (event.target?.closest?.(".radaptor-form-builder-field")) {
                    return
                }

                this.clearSelectedField()
            })
            dropRoot.dataset.formBuilderRootBound = "1"
        }
        if (doc.body?.dataset.formBuilderBodyBound !== "1") {
            doc.body.addEventListener("click", (event) => {
                if (event.target?.closest?.(".radaptor-form-builder-field")) {
                    return
                }

                this.clearSelectedField()
            })
            doc.body.dataset.formBuilderBodyBound = "1"
        }

        const fieldRows = []

        ;(this.descriptor.fields || []).forEach((field, index) => {
            const control = this.findFieldControl(doc, field, index)
            const row = this.findFieldRow(control)

            if (!row) {
                return
            }

            row.classList.add("radaptor-form-builder-field")
            if (index === this.selectedIndex) {
                row.classList.add("radaptor-form-builder-field-selected")
            }
            row.draggable = !this.readOnly
            row.dataset.formBuilderFieldIndex = String(index)
            row.addEventListener("click", (event) => {
                event.preventDefault()
                this.selectedIndex = index
                this.setActivePanel("input")
                this.renderProperties()
                this.updatePreviewSelection()
            })
            row.addEventListener("dragstart", (event) => {
                this.dragPayload = { kind: "field", index }
                event.dataTransfer?.setData("text/plain", JSON.stringify(this.dragPayload))
                this.showPreviewDropOverlay()
            })
            row.addEventListener("dragend", () => {
                this.clearPreviewDropZones()
                this.hidePreviewDropOverlay()
                this.dragPayload = null
            })
            row.addEventListener("dragover", (event) => event.preventDefault())
            row.addEventListener("drop", (event) => this.handlePreviewDrop(event, index))
            fieldRows.push({ index, row })
        })

        this.insertPreviewDropZones(doc, dropRoot, fieldRows)
    }

    updatePreviewSelection() {
        const doc = this.previewFrameTarget.contentDocument

        if (!doc) {
            return
        }

        doc.querySelectorAll(".radaptor-form-builder-field").forEach((row) => {
            row.classList.toggle("radaptor-form-builder-field-selected", Number(row.dataset.formBuilderFieldIndex) === this.selectedIndex)
        })
    }

    clearSelectedField() {
        if (this.selectedIndex === null && this.activePanel === "form") {
            return
        }

        this.selectedIndex = null
        this.setActivePanel("form")
        this.renderProperties()
        this.updatePreviewSelection()
    }

    handlePreviewDrop(event, targetIndex) {
        event.preventDefault()
        event.stopPropagation()
        let payload = this.dragPayload || this.payloadFromDataTransfer(event)

        if (!payload) {
            return
        }

        const index = targetIndex === null ? this.descriptor.fields.length : targetIndex

        if (payload.kind === "palette") {
            this.addField(payload.fieldType, index)
        } else if (payload.kind === "field") {
            this.reorderField(payload.index, index)
        }

        this.clearPreviewDropZones()
        this.hidePreviewDropOverlay()
        this.dragPayload = null
    }

    previewOverlayDrag(event) {
        event.preventDefault()
        event.stopPropagation()

        if (!this.dragPayload) {
            return
        }

        this.showPreviewDropOverlay()
        const framePoint = this.previewFramePointFromPagePoint(event.clientX, event.clientY)
        const dropZoneIndex = this.previewDropZoneIndexFromFramePoint(framePoint.clientX, framePoint.clientY)
        this.previewHoverDropIndex = Number.isInteger(dropZoneIndex)
            ? dropZoneIndex
            : this.previewInsertIndexFromFramePoint(framePoint.clientX, framePoint.clientY)
        this.activatePreviewDropZoneByIndex(this.previewHoverDropIndex)

        if (!Number.isInteger(dropZoneIndex)) {
            this.autoScrollPreview(event.clientY)
        }

        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = this.dragPayload.kind === "field" ? "move" : "copy"
        }
    }

    previewOverlayDrop(event) {
        const framePoint = this.previewFramePointFromPagePoint(event.clientX, event.clientY)
        const dropZoneIndex = this.previewDropZoneIndexFromFramePoint(framePoint.clientX, framePoint.clientY)
        const index = Number.isInteger(dropZoneIndex)
            ? dropZoneIndex
            : (this.previewHoverDropIndex ?? this.previewInsertIndexFromFramePoint(framePoint.clientX, framePoint.clientY))
        this.handlePreviewDrop(event, index)
    }

    previewOverlayLeave(event) {
        if (event.relatedTarget && this.previewOverlayTarget.contains(event.relatedTarget)) {
            return
        }

        if (this.dragPayload && this.isPointAtPreviewVerticalEdge(event.clientX, event.clientY)) {
            this.autoScrollPreview(event.clientY)
            this.previewHoverDropIndex = event.clientY > this.previewFrameTarget.getBoundingClientRect().bottom
                ? this.descriptor.fields.length
                : 0
            this.activatePreviewDropZoneByIndex(this.previewHoverDropIndex)

            return
        }

        this.clearPreviewDropZones()
    }

    autoScrollPreview(clientY) {
        const doc = this.previewFrameTarget.contentDocument
        const scroller = doc?.scrollingElement || doc?.documentElement

        if (!doc || !scroller || !Number.isFinite(clientY)) {
            return
        }

        const rect = this.previewFrameTarget.getBoundingClientRect()
        const threshold = 90
        let delta = 0

        if (clientY > rect.bottom - threshold) {
            delta = Math.ceil((threshold - Math.max(0, rect.bottom - clientY)) / threshold * 36)
        } else if (clientY < rect.top + threshold) {
            delta = -Math.ceil((threshold - Math.max(0, clientY - rect.top)) / threshold * 36)
        }

        if (delta !== 0) {
            scroller.scrollTop += delta
        }
    }

    isPointAtPreviewVerticalEdge(clientX, clientY) {
        if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) {
            return false
        }

        const rect = this.previewFrameTarget.getBoundingClientRect()

        return clientX >= rect.left
            && clientX <= rect.right
            && clientY >= rect.top - 48
            && clientY <= rect.bottom + 96
    }

    receivePreviewMessage(event) {
        if (event.source !== this.previewFrameTarget.contentWindow) {
            return
        }

        const data = event.data || {}

        if (data.type === "radaptor:form-builder-preview-hover") {
            this.previewHoverDropIndex = Number.isInteger(data.dropIndex) ? data.dropIndex : this.previewInsertIndexFromFramePoint(data.clientX, data.clientY)

            return
        }

        if (data.type !== "radaptor:form-builder-preview-drop") {
            return
        }

        const payload = data.payload || this.dragPayload || null

        if (!payload || !["palette", "field"].includes(payload.kind)) {
            return
        }

        // The preview iframe is srcdoc, so server-rendered preview HTML is inside
        // the editor trust boundary and may ask the parent to mutate local state.
        const index = Number.isInteger(data.dropIndex) ? data.dropIndex : this.previewInsertIndexFromFramePoint(data.clientX, data.clientY)
        if (payload.kind === "palette") {
            this.addField(payload.fieldType, index)
        } else {
            this.reorderField(payload.index, index)
        }
        this.clearPreviewDropZones()
        this.hidePreviewDropOverlay()
        this.dragPayload = null
    }

    insertPreviewDropZones(doc, dropRoot, fieldRows) {
        doc.querySelectorAll(".radaptor-form-builder-drop-zone").forEach((zone) => zone.remove())

        const sortedRows = fieldRows
            .filter((entry) => entry.row?.parentNode)
            .sort((left, right) => left.index - right.index)

        sortedRows.forEach((entry) => {
            entry.row.parentNode.insertBefore(this.createPreviewDropZone(doc, entry.index), entry.row)
        })

        const endZone = this.createPreviewDropZone(doc, this.descriptor.fields.length)

        if (sortedRows.length > 0) {
            const lastRow = sortedRows[sortedRows.length - 1].row
            lastRow.parentNode.insertBefore(endZone, lastRow.nextSibling)
            return
        }

        const form = doc.querySelector("form")
        if (form) {
            form.appendChild(endZone)
            return
        }

        dropRoot.appendChild(endZone)
    }

    createPreviewDropZone(doc, index) {
        const zone = doc.createElement("div")
        zone.className = "radaptor-form-builder-drop-zone"
        zone.dataset.formBuilderDropIndex = String(index)
        zone.setAttribute("aria-hidden", "true")
        zone.addEventListener("dragenter", (event) => this.handlePreviewZoneDrag(event, zone))
        zone.addEventListener("dragover", (event) => this.handlePreviewZoneDrag(event, zone))
        zone.addEventListener("dragleave", (event) => {
            if (event.relatedTarget && zone.contains(event.relatedTarget)) {
                return
            }

            zone.classList.remove("radaptor-form-builder-drop-zone-active")
        })
        zone.addEventListener("drop", (event) => this.handlePreviewDrop(event, index))

        return zone
    }

    handlePreviewZoneDrag(event, zone) {
        event.preventDefault()
        this.activatePreviewDropZone(zone)

        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = this.dragPayload?.kind === "field" ? "move" : "copy"
        }
    }

    activatePreviewDropZone(zone) {
        const index = Number(zone.dataset.formBuilderDropIndex)
        this.previewHoverDropIndex = Number.isInteger(index) ? index : null
        zone.ownerDocument.querySelectorAll(".radaptor-form-builder-drop-zone-active").forEach((activeZone) => {
            activeZone.classList.remove("radaptor-form-builder-drop-zone-active")
        })
        zone.closest("[data-form-builder-drop-root]")?.classList.add("radaptor-form-builder-drop-active")
        zone.classList.add("radaptor-form-builder-drop-zone-active")
    }

    activatePreviewDropZoneByIndex(index) {
        const doc = this.previewFrameTarget.contentDocument

        if (!doc || !Number.isInteger(index)) {
            return
        }

        const zone = doc.querySelector(`[data-form-builder-drop-index="${index}"]`)

        if (zone) {
            this.activatePreviewDropZone(zone)
        }
    }

    showPreviewDropOverlay() {
        if (this.hasPreviewOverlayTarget) {
            this.previewOverlayTarget.hidden = false
        }

        const doc = this.previewFrameTarget.contentDocument
        const dropRoot = doc?.querySelector("[data-form-builder-drop-root]")

        if (!doc || !dropRoot) {
            return
        }

        if (dropRoot.classList.contains("radaptor-form-builder-drop-active")) {
            return
        }

        const scroller = doc.scrollingElement || doc.documentElement
        const bottomOffset = scroller ? scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight : null
        const shouldAnchorBottom = Number.isFinite(bottomOffset) && bottomOffset <= 160
        const anchor = this.previewScrollAnchor(doc)
        const anchorTop = anchor?.getBoundingClientRect().top ?? null

        dropRoot.classList.add("radaptor-form-builder-drop-active")

        if (!scroller) {
            return
        }

        if (shouldAnchorBottom) {
            scroller.scrollTop = Math.max(0, scroller.scrollHeight - scroller.clientHeight - bottomOffset)

            return
        }

        if (!anchor || !Number.isFinite(anchorTop)) {
            return
        }

        const nextTop = anchor.getBoundingClientRect().top

        if (Number.isFinite(nextTop)) {
            scroller.scrollTop += nextTop - anchorTop
        }
    }

    previewScrollAnchor(doc) {
        const viewportBottom = doc.documentElement?.clientHeight || this.previewFrameTarget.clientHeight || 0

        for (const row of doc.querySelectorAll(".radaptor-form-builder-field")) {
            const rect = row.getBoundingClientRect()

            if (rect.bottom > 0 && rect.top < viewportBottom) {
                return row
            }
        }

        return null
    }

    hidePreviewDropOverlay() {
        if (this.hasPreviewOverlayTarget) {
            this.previewOverlayTarget.hidden = true
        }
    }

    clearPreviewDropZones(doc = null) {
        const previewDocument = doc || this.previewFrameTarget.contentDocument

        if (!previewDocument) {
            return
        }

        previewDocument.querySelector("[data-form-builder-drop-root]")?.classList.remove("radaptor-form-builder-drop-active")
        previewDocument.querySelectorAll(".radaptor-form-builder-drop-zone-active").forEach((zone) => {
            zone.classList.remove("radaptor-form-builder-drop-zone-active")
        })
        this.previewHoverDropIndex = null
    }

    previewInsertIndexFromPagePoint(clientX, clientY) {
        const framePoint = this.previewFramePointFromPagePoint(clientX, clientY)

        return this.previewInsertIndexFromFramePoint(framePoint.clientX, framePoint.clientY)
    }

    previewFramePointFromPagePoint(clientX, clientY) {
        const rect = this.previewFrameTarget.getBoundingClientRect()

        return {
            clientX: clientX - rect.left,
            clientY: clientY - rect.top,
        }
    }

    activePreviewDropIndex() {
        const activeZone = this.previewFrameTarget.contentDocument?.querySelector(".radaptor-form-builder-drop-zone-active")

        if (!activeZone) {
            return null
        }

        const index = Number(activeZone.dataset.formBuilderDropIndex)

        return Number.isInteger(index) ? index : null
    }

    previewInsertIndexFromFramePoint(clientX, clientY) {
        const zoneIndex = this.previewDropZoneIndexFromFramePoint(clientX, clientY)

        if (Number.isInteger(zoneIndex)) {
            return zoneIndex
        }

        const doc = this.previewFrameTarget.contentDocument

        if (!doc || !Number.isFinite(clientX) || !Number.isFinite(clientY)) {
            return this.descriptor.fields.length
        }

        for (const row of doc.querySelectorAll(".radaptor-form-builder-field")) {
            const rect = row.getBoundingClientRect()
            const index = Number(row.dataset.formBuilderFieldIndex)

            if (Number.isFinite(index) && clientY < rect.top + rect.height / 2) {
                return index
            }
        }

        return this.descriptor.fields.length
    }

    previewDropZoneIndexFromFramePoint(clientX, clientY) {
        const doc = this.previewFrameTarget.contentDocument

        if (!doc || !Number.isFinite(clientX) || !Number.isFinite(clientY)) {
            return null
        }

        for (const zone of doc.querySelectorAll(".radaptor-form-builder-drop-zone")) {
            const rect = zone.getBoundingClientRect()

            if (clientX >= rect.left && clientX <= rect.right && clientY >= rect.top && clientY <= rect.bottom) {
                return Number(zone.dataset.formBuilderDropIndex || this.descriptor.fields.length)
            }
        }

        return null
    }

    payloadFromDataTransfer(event) {
        if (!event.dataTransfer?.getData("text/plain")) {
            return null
        }

        try {
            return JSON.parse(event.dataTransfer.getData("text/plain"))
        } catch {
            return null
        }
    }

    findFieldControl(doc, field, index = null) {
        if (Number.isInteger(index)) {
            const indexedControl = doc.querySelector(`[data-form-builder-field-preview-index="${index}"]`)
            if (indexedControl) {
                return indexedControl
            }
        }

        const names = new Set([field.key, field.name].filter(Boolean).map((name) => String(name)))

        for (const control of doc.querySelectorAll("[name], [data-field-key]")) {
            if (names.has(String(control.getAttribute("name") || "")) || names.has(String(control.dataset.fieldKey || ""))) {
                return control
            }
        }

        return null
    }

    hasFieldIdentifierConflict(identifier, selectedIndex) {
        const normalized = String(identifier || "").trim()

        if (normalized === "") {
            return false
        }

        return (this.descriptor.fields || []).some((field, index) => {
            if (index === selectedIndex) {
                return false
            }

            return [field?.key, field?.name]
                .filter(Boolean)
                .map((value) => String(value).trim())
                .includes(normalized)
        })
    }

    findFieldRow(control) {
        if (!control) {
            return null
        }

        return control.closest(".input-row")
            || control.closest(".row")
            || control.closest(".col,label,div")
            || control
    }

    renderProperties() {
        const field = this.selectedIndex !== null ? this.descriptor.fields[this.selectedIndex] : null
        this.emptyPropertiesTarget.hidden = Boolean(field)
        this.propertiesPanelTarget.hidden = false
        this.fieldPropertiesTarget.hidden = !field
        this.syncFormProperties()
        this.renderPanelTabs()

        if (!field) {
            this.setPropertyDisabled(this.readOnly)
            this.updateButtons()

            return
        }

        this.fieldLabelInputTarget.value = this.displayTextValue(field.label)
        this.fieldNameInputTarget.value = field.name || ""
        this.fieldKeyInputTarget.value = field.key || field.name || ""
        this.fieldRequiredInputTarget.checked = this.hasValidator(field, "required")
        this.fieldOptionsGroupTarget.hidden = !this.isOptionField(field.type)
        this.fieldOptionsInputTarget.value = this.optionsText(field)
        this.syncFieldTranslationLinks(field)
        this.setPropertyDisabled(this.readOnly)
        this.updateButtons()
    }

    syncFormProperties() {
        this.formTitleInputTarget.value = this.displayTextValue(this.descriptor.title)
        this.formDescriptionInputTarget.value = this.displayTextValue(this.descriptor.description)
        this.submitLabelInputTarget.value = this.displayTextValue(this.descriptor.submit_label)

        if (this.hasI18nModeInputTarget) {
            this.i18nModeInputTarget.checked = this.displayKeyedI18nMode()
        }

        if (this.hasTranslationsLinkTarget) {
            this.translationsLinkTarget.href = this.translationUrl || "#"
            this.translationsLinkTarget.classList.toggle("disabled", this.translationUrl === "")
            this.translationsLinkTarget.setAttribute("aria-disabled", this.translationUrl === "" ? "true" : "false")
        }

        this.syncFormTranslationLinks()
    }

    syncFormTranslationLinks() {
        this.setTranslationLink(this.hasFormTitleTranslationLinkTarget ? this.formTitleTranslationLinkTarget : null, this.translationUrlForTextDefinition(this.descriptor.title))
        this.setTranslationLink(this.hasFormDescriptionTranslationLinkTarget ? this.formDescriptionTranslationLinkTarget : null, this.translationUrlForTextDefinition(this.descriptor.description))
        this.setTranslationLink(this.hasSubmitLabelTranslationLinkTarget ? this.submitLabelTranslationLinkTarget : null, this.translationUrlForTextDefinition(this.descriptor.submit_label))
    }

    syncFieldTranslationLinks(field) {
        this.setTranslationLink(this.hasFieldLabelTranslationLinkTarget ? this.fieldLabelTranslationLinkTarget : null, this.translationUrlForTextDefinition(field?.label))
        this.setTranslationLink(this.hasFieldRequiredTranslationLinkTarget ? this.fieldRequiredTranslationLinkTarget : null, this.translationUrlForRequiredValidator(field))
        this.setTranslationLink(this.hasFieldOptionsTranslationLinkTarget ? this.fieldOptionsTranslationLinkTarget : null, this.translationUrlForOptions(field))
    }

    setTranslationLink(link, url) {
        if (!link) {
            return
        }

        const href = String(url || "")
        link.href = href || "#"
        link.hidden = href === ""
        link.setAttribute("aria-disabled", href === "" ? "true" : "false")
    }

    stopPropertyLinkClick(event) {
        event.stopPropagation()
    }

    setPropertyDisabled(disabled) {
        this.propertiesPanelTarget.querySelectorAll("input,textarea,select,button").forEach((control) => {
            control.disabled = disabled
        })
    }

    updateButtons() {
        const disabled = this.readOnly || this.saving || this.loadingDraftVersion
        this.undoButtonTarget.disabled = disabled || this.undoStack.length === 0
        this.redoButtonTarget.disabled = disabled || this.redoStack.length === 0
        this.moveUpButtonTarget.disabled = disabled || this.selectedIndex === null || this.selectedIndex <= 0
        this.moveDownButtonTarget.disabled = disabled || this.selectedIndex === null || this.selectedIndex >= this.descriptor.fields.length - 1
        this.deleteButtonTarget.disabled = disabled || this.selectedIndex === null
        this.saveButtonTarget.disabled = disabled || this.definitionSlug === "" || !this.dirty || this.localConflict
        this.publishButtonTarget.disabled = disabled || this.definitionSlug === "" || this.localConflict
    }

    applyServerState(state) {
        this.definitionSlug = state.definition?.definition_slug || this.definitionSlug
        this.descriptor = this.clone(state.descriptor || this.descriptor)
        this.serverDescriptor = this.clone(state.server_descriptor || state.descriptor || this.descriptor)
        this.serverDescriptorJson = this.descriptorJson(this.serverDescriptor)
        this.baseServerHash = String(state.base_server_hash || this.baseServerHash)
        this.readOnly = Boolean(state.read_only)
        this.activeDraft = state.active_draft || null
        if (Object.prototype.hasOwnProperty.call(state, "published_version")) {
            this.publishedVersion = state.published_version || null
            this.hasPublishedVersion = Boolean(this.publishedVersion)
        } else {
            this.hasPublishedVersion = this.hasPublishedVersion || Boolean(this.publishedVersion)
        }
        this.versions = Array.isArray(state.versions) ? state.versions : this.versions
        this.loadedVersion = state.loaded_version || null
        this.translationUrl = String(state.translation_url || this.translationUrl || "")
        this.i18nWorkbenchUrl = String(state.i18n_workbench_url || this.i18nWorkbenchUrl || "")
        this.localConflict = false
        this.localStateBaseServerHash = ""
        this.hideConflictActions()
        this.selectedIndex = null
        this.setActivePanel("form")
        this.undoStack = []
        this.redoStack = []
        this.renderProperties()
        this.renderPanelTabs()
        this.renderDraftsList()
        this.renderPreview()
    }

    applyLoadedDraftState(state) {
        this.definitionSlug = state.definition?.definition_slug || this.definitionSlug
        this.descriptor = this.clone(state.descriptor || this.descriptor)
        this.serverDescriptor = this.clone(state.server_descriptor || state.descriptor || this.descriptor)
        this.serverDescriptorJson = this.descriptorJson(this.serverDescriptor)
        this.baseServerHash = String(state.base_server_hash || this.baseServerHash)
        this.readOnly = Boolean(state.read_only)
        this.activeDraft = state.active_draft || null
        if (Object.prototype.hasOwnProperty.call(state, "published_version")) {
            this.publishedVersion = state.published_version || null
            this.hasPublishedVersion = Boolean(this.publishedVersion)
        } else {
            this.hasPublishedVersion = this.hasPublishedVersion || Boolean(this.publishedVersion)
        }
        this.versions = Array.isArray(state.versions) ? state.versions : this.versions
        this.loadedVersion = state.loaded_version || null
        this.translationUrl = String(state.translation_url || this.translationUrl || "")
        this.i18nWorkbenchUrl = String(state.i18n_workbench_url || this.i18nWorkbenchUrl || "")
        this.localConflict = false
        this.localStateBaseServerHash = ""
        this.hideConflictActions()
        this.selectedIndex = null
        this.setActivePanel("form")
        this.undoStack = []
        this.redoStack = []
        this.dirty = this.descriptorJson(this.descriptor) !== this.serverDescriptorJson

        if (this.dirty) {
            this.persistLocalState()
        } else {
            this.clearLocalState()
        }

        this.syncFormProperties()
        this.renderProperties()
        this.renderPanelTabs()
        this.renderDraftsList()
        this.renderLocalPreview()
        this.updateButtons()
        this.dispatchDirtyChange()
        this.dispatchBuilderChanged("load_draft_version", state)
    }

    renderDraftsList() {
        this.updateDraftsButton()

        if (!this.hasDraftsListTarget) {
            return
        }

        if (this.versions.length === 0) {
            this.draftsListTarget.innerHTML = `<div class="form-builder__empty-properties">${this.escapeHtml(this.s("form.builder.drafts.empty"))}</div>`
            return
        }

        const activeDraftId = Number(this.activeDraft?.version_id || 0)
        const loadedVersionId = Number(this.loadedVersion?.version_id || 0)

        this.draftsListTarget.innerHTML = this.versions.map((version) => {
            const versionId = Number(version.version_id || 0)
            const versionNumber = Number(version.version_number || 0)
            const status = String(version.status || "")
            const note = String(version.author_note || "")
            const badges = [
                this.draftBadge(this.draftStatusLabel(status), "secondary"),
                activeDraftId === versionId ? this.draftBadge(this.s("form.builder.drafts.current"), "primary") : "",
                loadedVersionId === versionId ? this.draftBadge(this.s("form.builder.drafts.loaded"), "info") : "",
            ].filter(Boolean).join("")
            const publishedDate = version.published_at ? `<span>${this.escapeHtml(this.s("form.builder.drafts.published"))}: ${this.escapeHtml(this.formatVersionDate(version.published_at))}</span>` : ""
            const loadDisabled = this.readOnly || this.saving || this.loadingDraftVersion || versionId <= 0 ? " disabled" : ""
            const noteDisabled = this.readOnly || this.saving || this.loadingDraftVersion || versionId <= 0 ? " disabled" : ""

            return `<article class="form-builder__draft-row" data-form-builder-draft-version-id="${this.escapeAttr(versionId)}">`
                + `<div class="form-builder__draft-row-header">`
                + `<div><strong>${this.escapeHtml(this.s("form.builder.drafts.version"))} ${this.escapeHtml(versionNumber)}</strong><div class="form-builder__draft-meta"><span>${this.escapeHtml(this.s("form.builder.drafts.created"))}: ${this.escapeHtml(this.formatVersionDate(version.created_at))}</span>${publishedDate}</div></div>`
                + `<div class="form-builder__draft-badges">${badges}</div>`
                + `</div>`
                + `<label class="form-label form-builder__draft-note">`
                + `<span>${this.escapeHtml(this.s("form.builder.drafts.note"))}</span>`
                + `<textarea rows="2" maxlength="1000" class="form-control form-control-sm" data-version-id="${this.escapeAttr(versionId)}" data-action="change->form-builder#updateDraftNote" placeholder="${this.escapeAttr(this.s("form.builder.drafts.note_placeholder"))}"${noteDisabled}>${this.escapeHtml(note)}</textarea>`
                + `</label>`
                + `<div class="form-builder__draft-actions">`
                + `<button type="button" class="btn btn-outline-primary btn-sm" data-version-id="${this.escapeAttr(versionId)}" data-action="form-builder#loadDraftVersion"${loadDisabled}>${this.escapeHtml(this.s("form.builder.action.load_draft"))}</button>`
                + `</div>`
                + `</article>`
        }).join("")
    }

    updateDraftsButton() {
        if (!this.hasDraftsButtonTarget) {
            return
        }

        const label = String(this.s("form.builder.panel.drafts"))
        const count = Array.isArray(this.versions) ? this.versions.length : 0
        this.draftsButtonTarget.innerHTML = `<i class="bi bi-clock-history" aria-hidden="true"></i> ${this.escapeHtml(label)} (${this.escapeHtml(String(count))})`
    }

    draftBadge(label, type) {
        return `<span class="badge text-bg-${this.escapeAttr(type)} bg-opacity-75">${this.escapeHtml(label)}</span>`
    }

    draftStatusLabel(status) {
        return this.s(`form.builder.drafts.status.${status}`) || status
    }

    formatVersionDate(value) {
        const raw = String(value || "").trim()

        if (raw === "") {
            return ""
        }

        const parsed = new Date(raw.replace(/\s+/, "T"))

        return Number.isNaN(parsed.getTime()) ? raw : parsed.toLocaleString()
    }

    renderPanelTabs() {
        const inputActive = this.activePanel === "input"

        if (this.hasFormPropertiesPaneTarget) {
            this.formPropertiesPaneTarget.hidden = inputActive
        }

        if (this.hasInputPropertiesPaneTarget) {
            this.inputPropertiesPaneTarget.hidden = !inputActive
        }

        if (this.hasFormTabButtonTarget) {
            this.formTabButtonTarget.classList.toggle("is-active", !inputActive)
            this.formTabButtonTarget.setAttribute("aria-selected", inputActive ? "false" : "true")
        }

        if (this.hasInputTabButtonTarget) {
            this.inputTabButtonTarget.classList.toggle("is-active", inputActive)
            this.inputTabButtonTarget.setAttribute("aria-selected", inputActive ? "true" : "false")
        }
    }

    setActivePanel(panel, dispatch = true) {
        const nextPanel = this.normalizePanel(panel)
        const changed = this.activePanel !== nextPanel
        this.activePanel = nextPanel
        this.renderPanelTabs()

        if (changed && dispatch) {
            this.dispatchPanelChange()
        }
    }

    normalizePanel(panel) {
        return String(panel) === "input" ? "input" : "form"
    }

    dispatchDirtyChange() {
        this.element.dispatchEvent(new CustomEvent("form-builder:dirty-change", {
            bubbles: true,
            detail: { dirty: this.dirty },
        }))
    }

    dispatchBuilderChanged(action, state) {
        this.element.dispatchEvent(new CustomEvent("form-builder:changed", {
            bubbles: true,
            detail: {
                action,
                definition_slug: this.definitionSlug,
                dirty: this.dirty,
                state,
            },
        }))
    }

    dispatchPanelChange() {
        this.element.dispatchEvent(new CustomEvent("form-builder:panel-change", {
            bubbles: true,
            detail: { panel: this.activePanel },
        }))
    }

    showConflict() {
        this.localConflict = true
        this.localStateBaseServerHash = this.localStateBaseServerHash || this.baseServerHash
        this.showConflictActions()
        this.setStatus(this.s("form.builder.status.conflict"))
        this.updateButtons()
    }

    hideConflictActions() {
        if (this.hasConflictActionsTarget) {
            this.conflictActionsTarget.hidden = true
        }
    }

    showConflictActions() {
        if (this.hasConflictActionsTarget) {
            this.conflictActionsTarget.hidden = false
        }
    }

    baseFormData() {
        const formData = new FormData()
        formData.set("definition_slug", this.definitionSlug || "capture-preview")
        formData.set("descriptor_json", JSON.stringify(this.descriptor))
        formData.set("csrf_token", this.csrfTokenValue)

        return formData
    }

    async postForm(url, formData, allowConflict = false) {
        const response = await fetch(url, {
            method: "POST",
            headers: { Accept: "application/json" },
            body: formData,
        })
        const responseText = await response.text()
        let payload = {}

        try {
            payload = responseText === "" ? {} : JSON.parse(responseText)
        } catch (_error) {
            throw new Error(this.s("form.builder.error_request"))
        }

        if (payload === null || typeof payload !== "object") {
            throw new Error(this.s("form.builder.error_request"))
        }

        if (!response.ok && !(allowConflict && response.status === 409)) {
            throw new Error(payload?.error?.message || this.s("form.builder.error_request"))
        }

        return payload
    }

    errorMessage(error, fallbackKey) {
        return error instanceof Error && error.message !== "" ? error.message : this.s(fallbackKey)
    }

    pushUndo(scope = "") {
        if (this.readOnly) {
            return
        }

        const scopeKey = String(scope || "")

        if (scopeKey !== "" && this.undoScope === scopeKey) {
            this.scheduleUndoScopeReset(scopeKey)

            return
        }

        const previous = this.snapshot()
        const last = this.undoStack[this.undoStack.length - 1]

        if (JSON.stringify(previous) === JSON.stringify(last)) {
            this.scheduleUndoScopeReset(scopeKey)

            return
        }

        this.undoStack.push(previous)
        this.undoStack = this.undoStack.slice(-75)
        this.redoStack = []
        this.undoScope = scopeKey
        this.scheduleUndoScopeReset(scopeKey)
    }

    undoScopeForEvent(prefix, event) {
        const target = event?.target
        const targetName = target?.dataset?.formBuilderTarget || target?.name || target?.id || "default"

        return `${prefix}:${targetName}`
    }

    scheduleUndoScopeReset(scopeKey) {
        window.clearTimeout(this.undoScopeTimer)

        if (scopeKey === "") {
            this.undoScope = ""

            return
        }

        this.undoScopeTimer = window.setTimeout(() => {
            if (this.undoScope === scopeKey) {
                this.undoScope = ""
            }
        }, 800)
    }

    resetUndoScope() {
        window.clearTimeout(this.undoScopeTimer)
        this.undoScope = ""
    }

    snapshot() {
        return {
            descriptor: this.clone(this.descriptor),
            selectedIndex: this.selectedIndex,
        }
    }

    restoreSnapshot(snapshot) {
        if (!snapshot) {
            return
        }

        this.descriptor = this.clone(snapshot.descriptor)
        this.selectedIndex = snapshot.selectedIndex
        this.setActivePanel(this.selectedIndex === null ? "form" : "input")
    }

    loadLocalState() {
        if (this.storageKey() === "") {
            return false
        }

        try {
            const raw = window.localStorage.getItem(this.storageKey())

            if (!raw) {
                return false
            }

            const stored = JSON.parse(raw)

            if (stored?.descriptor) {
                const storedBaseHash = String(stored.baseServerHash || "")
                this.descriptor = stored.descriptor
                this.selectedIndex = Number.isInteger(stored.selectedIndex) ? stored.selectedIndex : null
                this.setActivePanel(this.selectedIndex === null ? this.activePanel : "input")
                this.undoStack = Array.isArray(stored.undoStack) ? stored.undoStack.slice(-75) : []
                this.redoStack = Array.isArray(stored.redoStack) ? stored.redoStack.slice(-75) : []
                this.dirty = this.descriptorJson(this.descriptor) !== this.serverDescriptorJson
                this.localStateBaseServerHash = storedBaseHash
                this.localConflict = storedBaseHash !== this.baseServerHash
                this.setStatus(this.s(!this.localConflict
                    ? (this.dirty ? "form.builder.status.dirty" : "form.builder.status.clean")
                    : "form.builder.status.conflict"))

                if (this.localConflict) {
                    this.showConflictActions()
                }

                return true
            }
        } catch {
            this.setStatus(this.s("form.builder.warning.local_storage"))
        }

        return false
    }

    persistLocalState() {
        if (this.storageKey() === "") {
            return
        }

        try {
            window.localStorage.setItem(this.storageKey(), JSON.stringify({
                descriptor: this.descriptor,
                selectedIndex: this.selectedIndex,
                undoStack: this.undoStack.slice(-75),
                redoStack: this.redoStack.slice(-75),
                baseServerHash: this.localConflict ? this.localStateBaseServerHash : this.baseServerHash,
                revision: Date.now(),
            }))
        } catch {
            this.undoStack = []
            this.redoStack = []
            this.setStatus(this.s("form.builder.warning.local_storage"))
        }
    }

    clearLocalState() {
        if (this.storageKey() !== "") {
            window.localStorage.removeItem(this.storageKey())
        }
    }

    storageKey() {
        return this.definitionSlug !== "" ? `radaptor:form-builder:v1:${this.definitionSlug}` : ""
    }

    isPointInsidePreview(clientX, clientY) {
        if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) {
            return false
        }

        const rect = this.previewFrameTarget.getBoundingClientRect()

        return clientX >= rect.left && clientX <= rect.right && clientY >= rect.top && clientY <= rect.bottom
    }

    isKeyedI18nMode() {
        return this.descriptor?.i18n_mode === "keyed"
            || this.hasFormDefinitionI18nReference(this.descriptor)
    }

    displayKeyedI18nMode() {
        return this.isKeyedI18nMode()
            || (this.readOnly && this.hasI18nReference(this.descriptor))
    }

    hasFormDefinitionI18nReference(value) {
        return this.i18nReferenceKeys(value).some((key) => key.startsWith("form_def."))
    }

    hasI18nReference(value) {
        return this.i18nReferenceKeys(value).length > 0
    }

    i18nReferenceKeys(value) {
        const keys = []
        this.collectI18nReferenceKeys(value, keys)

        return keys
    }

    textDefinitionKey(value) {
        if (!value || typeof value !== "object") {
            return ""
        }

        const objectKeys = Object.keys(value)
        const isTextDefinition = typeof value.key === "string"
            && value.key.trim() !== ""
            && objectKeys.every((key) => ["text", "key", "params"].includes(key))

        return isTextDefinition ? value.key.trim() : ""
    }

    translationUrlForTextDefinition(value) {
        return this.translationUrlForKey(this.textDefinitionKey(value))
    }

    translationUrlForRequiredValidator(field) {
        const validator = Array.isArray(field?.validators)
            ? field.validators.find((item) => item?.type === "required")
            : null

        return this.translationUrlForTextDefinition(validator?.message)
    }

    translationUrlForOptions(field) {
        if (!this.isOptionField(field?.type)) {
            return ""
        }

        const keys = this.optionEntries(field)
            .map((option) => (typeof option === "string" ? "" : this.textDefinitionKey(option.label)))
            .filter(Boolean)

        return this.translationUrlForKeys(keys)
    }

    translationUrlForKeys(keys) {
        const parsed = keys
            .map((key) => this.parseTranslationKey(key))
            .filter(Boolean)

        if (parsed.length === 0) {
            return ""
        }

        const domain = parsed[0].domain
        const messageKeys = parsed
            .filter((item) => item.domain === domain)
            .map((item) => item.key)

        if (messageKeys.length !== parsed.length) {
            return ""
        }

        return this.translationWorkbenchUrl(domain, this.commonTranslationSearch(messageKeys))
    }

    translationUrlForKey(key) {
        const parsed = this.parseTranslationKey(key)

        return parsed ? this.translationWorkbenchUrl(parsed.domain, parsed.key) : ""
    }

    parseTranslationKey(key) {
        const parts = String(key || "").split(".")

        if (parts.length < 2 || parts[0] === "" || parts.slice(1).join(".") === "") {
            return null
        }

        return {
            domain: parts[0],
            key: parts.slice(1).join("."),
        }
    }

    translationWorkbenchUrl(domain, search) {
        if (this.i18nWorkbenchUrl === "") {
            return ""
        }

        const url = new URL(this.i18nWorkbenchUrl, window.location.origin)
        url.searchParams.set("domain", domain)

        if (search !== "") {
            url.searchParams.set("search", search)
        } else {
            url.searchParams.delete("search")
        }

        return `${url.pathname}${url.search}`
    }

    commonTranslationSearch(keys) {
        if (keys.length === 1) {
            return keys[0]
        }

        let prefix = keys[0] || ""
        keys.slice(1).forEach((key) => {
            while (prefix !== "" && !key.startsWith(prefix)) {
                prefix = prefix.slice(0, -1)
            }
        })

        if (prefix.includes(".")) {
            return prefix.slice(0, prefix.lastIndexOf(".") + 1)
        }

        return ""
    }

    collectI18nReferenceKeys(value, keys) {
        if (!value || typeof value !== "object") {
            return
        }

        const objectKeys = Object.keys(value)
        const isTextDefinition = typeof value.key === "string"
            && value.key.trim() !== ""
            && objectKeys.every((key) => ["text", "key", "params"].includes(key))

        if (isTextDefinition) {
            keys.push(value.key.trim())
        }

        Object.values(value).forEach((child) => {
            if (child && typeof child === "object") {
                this.collectI18nReferenceKeys(child, keys)
            }
        })
    }

    textDefinition(path, text) {
        const value = String(text || "")

        // Empty values stay literal so clearing a field does not create blank translation rows or churn keys.
        if (!this.isKeyedI18nMode() || value.trim() === "") {
            return { text: value }
        }

        return {
            key: this.i18nKey(path),
            text: value,
        }
    }

    i18nKey(path) {
        return `form_def.${this.formI18nSlug()}.${String(path || "").replace(/[^a-z0-9_.]+/g, "_").replace(/^[._]+|[._]+$/g, "")}`
    }

    formI18nSlug() {
        return this.identifier(this.definitionSlug || "capture_new")
    }

    fieldI18nSegment(field) {
        return this.identifier(field?.key || field?.name || "field")
    }

    optionI18nSegment(optionValue) {
        return this.identifier(optionValue || "option")
    }

    normalizeDescriptorI18n() {
        this.descriptor.title = this.textDefinition("title", this.textValue(this.descriptor.title))
        this.descriptor.description = this.textDefinition("description", this.textValue(this.descriptor.description))
        this.descriptor.submit_label = this.textDefinition("submit_label", this.textValue(this.descriptor.submit_label))
        ;(this.descriptor.fields || []).forEach((field) => this.normalizeFieldI18n(field))
    }

    normalizeFieldI18n(field) {
        if (!field || typeof field !== "object" || !this.isKeyedI18nMode()) {
            return
        }

        const segment = this.fieldI18nSegment(field)
        field.label = this.textDefinition(`fields.${segment}.label`, this.textValue(field.label))

        if (field.help) {
            field.help = this.textDefinition(`fields.${segment}.help`, this.textValue(field.help))
        }

        if (field.explanation) {
            field.explanation = this.textDefinition(`fields.${segment}.explanation`, this.textValue(field.explanation))
        }

        if (this.isOptionField(field.type)) {
            field.values = this.optionEntries(field).map((option) => {
                if (typeof option === "string") {
                    const value = String(option)
                    return {
                        inputtype: "option",
                        value,
                        label: this.textDefinition(`fields.${segment}.options.${this.optionI18nSegment(value)}.label`, option),
                    }
                }

                const value = String(option.value || this.identifier(this.textValue(option.label)) || "")
                return {
                    ...option,
                    value,
                    label: this.textDefinition(`fields.${segment}.options.${this.optionI18nSegment(value)}.label`, this.textValue(option.label)),
                }
            })
        }
    }

    literalizeDescriptorI18n() {
        this.descriptor.title = { text: this.textValue(this.descriptor.title) }
        this.descriptor.description = { text: this.textValue(this.descriptor.description) }
        this.descriptor.submit_label = { text: this.textValue(this.descriptor.submit_label) }
        ;(this.descriptor.fields || []).forEach((field) => this.literalizeFieldI18n(field))
    }

    literalizeFieldI18n(field) {
        if (!field || typeof field !== "object") {
            return
        }

        field.label = { text: this.textValue(field.label) }

        if (field.help) {
            field.help = { text: this.textValue(field.help) }
        }

        if (field.explanation) {
            field.explanation = { text: this.textValue(field.explanation) }
        }

        if (Array.isArray(field.validators)) {
            field.validators = field.validators.map((validator) => {
                if (!validator || typeof validator !== "object" || !("message" in validator)) {
                    return validator
                }

                return {
                    ...validator,
                    message: { text: this.textValue(validator.message) },
                }
            })
        }

        if (this.isOptionField(field.type)) {
            field.values = this.optionEntries(field).map((option) => {
                if (typeof option === "string") {
                    return option
                }

                return {
                    ...option,
                    label: { text: this.textValue(option.label) },
                }
            })
        }
    }

    syncRequiredValidator(field) {
        field.validators = Array.isArray(field.validators) ? field.validators.filter((validator) => validator?.type !== "required") : []

        if (field.required) {
            field.validators.unshift({ type: "required" })
        }
    }

    syncEnumValidator(field, values) {
        field.validators = Array.isArray(field.validators) ? field.validators.filter((validator) => validator?.type !== "enum") : []
        field.validators.push({ type: "enum", values })
    }

    parseOptions(value, field) {
        const fieldSegment = field ? this.fieldI18nSegment(field) : ""

        return String(value || "")
            .split(/\r?\n/)
            .map((line) => line.trim())
            .filter(Boolean)
            .map((line) => {
                const [rawValue, ...labelParts] = line.split("=")
                const optionValue = this.identifier(rawValue.trim())
                return {
                    inputtype: "option",
                    value: optionValue,
                    label: fieldSegment !== ""
                        ? this.textDefinition(`fields.${fieldSegment}.options.${this.optionI18nSegment(optionValue)}.label`, (labelParts.join("=").trim() || rawValue.trim()))
                        : { text: (labelParts.join("=").trim() || rawValue.trim()) },
                }
            })
    }

    optionsText(field) {
        return this.optionEntries(field)
            .map((option) => {
                if (typeof option === "string") {
                    return option
                }

                return `${option.value || ""}=${this.displayTextValue(option.label)}`
            })
            .join("\n")
    }

    optionEntries(field) {
        const options = field.values || field.options || []

        if (Array.isArray(options)) {
            return options
        }

        if (options && typeof options === "object") {
            return Object.entries(options).map(([key, value]) => {
                if (field.type === "radiogroup") {
                    return {
                        value: this.textValue(value),
                        label: { text: key },
                    }
                }

                return {
                    value: key,
                    label: { text: this.textValue(value) },
                }
            })
        }

        return []
    }

    uniqueIdentifier(base) {
        const normalized = this.identifier(base)
        const used = new Set((this.descriptor.fields || []).flatMap((field) => [field.name, field.key]))
        let candidate = normalized
        let index = 2

        while (used.has(candidate)) {
            candidate = `${normalized}_${index}`
            index += 1
        }

        return candidate
    }

    identifier(value) {
        const normalized = String(value || "field").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "")
        return /^[a-z]/.test(normalized) ? normalized : `field_${normalized || "1"}`
    }

    isOptionField(type) {
        return ["select", "radiogroup", "checkboxgroup"].includes(type)
    }

    hasValidator(field, type) {
        return Array.isArray(field.validators) && field.validators.some((validator) => validator?.type === type)
    }

    textValue(value) {
        if (typeof value === "string") {
            return value
        }

        if (value && typeof value === "object") {
            if ("text" in value) {
                return String(value.text || "")
            }

            if (typeof value.key === "string" && value.key !== "" && Object.prototype.hasOwnProperty.call(this.strings, value.key)) {
                return this.s(value.key)
            }

            return ""
        }

        return ""
    }

    displayTextValue(value) {
        if (this.readOnly && value && typeof value === "object" && typeof value.key === "string" && value.key !== "" && Object.prototype.hasOwnProperty.call(this.strings, value.key)) {
            return this.s(value.key)
        }

        return this.textValue(value)
    }

    escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, (char) => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            "\"": "&quot;",
            "'": "&#039;",
        }[char]))
    }

    escapeAttr(value) {
        return this.escapeHtml(value)
    }

    clone(value) {
        return JSON.parse(JSON.stringify(value ?? null))
    }

    descriptorJson(descriptor) {
        return JSON.stringify(descriptor || {})
    }

    setStatus(message) {
        this.statusTarget.textContent = message
    }

    s(key) {
        return this.strings[key] || key
    }
}
