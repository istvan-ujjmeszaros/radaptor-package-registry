# Radaptor Portal Admin Theme

`radaptor/themes/portal-admin` provides the Bootstrap 5 based admin theme
(`RadaptorPortalAdmin`) for Radaptor CMS layouts and widgets.
It contains theme templates, layout wrappers, JS/CSS asset wiring, and admin UI styling.

## Installation

Use through a registry-first consumer app:

- [`radaptor-app`](https://github.com/istvan-ujjmeszaros/radaptor-app)
- [`radaptor-portal`](https://github.com/istvan-ujjmeszaros/radaptor-portal)

The theme is resolved from package metadata; no manual copy step is required.

## Dependencies

From `.registry-package.json`:

- `radaptor/core/cms` (`^0.1.0`)

## License

This package is distributed under the proprietary evaluation license in
[LICENSE](./LICENSE).
Evaluation-only: no production/commercial/distribution/derivative use without
a separate license agreement.

## Contact

istvan@radaptor.com
