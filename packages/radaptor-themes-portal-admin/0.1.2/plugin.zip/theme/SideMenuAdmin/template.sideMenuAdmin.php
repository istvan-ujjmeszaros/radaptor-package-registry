<?php assert(isset($this) && $this instanceof Template); ?>
<ul class="nav flex-column sidebar-menu">
		<!-- Administration -->
		<li class="nav-item sidebar-section-title">
			<small class="text-muted text-uppercase px-3"><?= e($this->strings['admin.menu.section.administration']) ?></small>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::USERLIST); ?>">
				<i class="bi bi-people me-2"></i>
				<span><?= e($this->strings['user.list.title']) ?></span>
			</a>
		</li>
	<?php if (defined(WidgetList::class . '::MCPTOKENS')): ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url((string) constant(WidgetList::class . '::MCPTOKENS')); ?>">
				<i class="bi bi-key me-2"></i>
				<span><?= e($this->strings['admin.menu.mcp_tokens']) ?></span>
			</a>
		</li>
	<?php endif; ?>
	<?php if (Roles::hasRole(RoleList::ROLE_USERGROUPS_ADMIN)): ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::USERGROUPLIST); ?>">
				<i class="bi bi-person-badge me-2"></i>
				<span><?= e($this->strings['admin.menu.usergroups']) ?></span>
			</a>
		</li>
	<?php endif; ?>
	<?php if (Roles::hasRole(RoleList::ROLE_ROLES_ADMIN)): ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::ROLELIST); ?>">
				<i class="bi bi-shield-check me-2"></i>
				<span><?= e($this->strings['admin.menu.roles']) ?></span>
			</a>
		</li>
	<?php endif; ?>

	<?php if (Roles::hasRole(RoleList::ROLE_SYSTEM_ADMINISTRATOR)): ?>
		<!-- Configuration -->
		<li class="nav-item sidebar-section-title">
			<small class="text-muted text-uppercase px-3"><?= e($this->strings['admin.menu.section.configuration']) ?></small>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::RESOURCETREE); ?>">
				<i class="bi bi-diagram-3 me-2"></i>
				<span><?= e($this->strings['admin.menu.resource_tree']) ?></span>
			</a>
		</li>
	<li class="nav-item">
		<a class="nav-link" href="<?= widget_url('I18nWorkbench'); ?>">
			<i class="bi bi-translate me-2"></i>
			<span><?= e($this->strings['admin.menu.translations']) ?></span>
		</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?= widget_url(WidgetList::IMPORTEXPORT); ?>">
			<i class="bi bi-arrow-down-up me-2"></i>
			<span><?= e($this->strings['admin.menu.import_export']) ?></span>
		</a>
	</li>
	<?php endif; ?>
	<?php if (Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER)): ?>
	<?php if (!Roles::hasRole(RoleList::ROLE_SYSTEM_ADMINISTRATOR)): ?>
		<!-- Configuration (header for developers without admin) -->
		<li class="nav-item sidebar-section-title">
			<small class="text-muted text-uppercase px-3"><?= e($this->strings['admin.menu.section.configuration']) ?></small>
		</li>
	<?php endif; ?>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::ADMINMENU); ?>">
				<i class="bi bi-list me-2"></i>
				<span><?= e($this->strings['admin.menu.admin_menu']) ?></span>
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= form_url(FormList::THEMESELECTOR, -1); ?>">
				<i class="bi bi-palette me-2"></i>
				<span><?= e($this->strings['admin.menu.theme_selector']) ?></span>
			</a>
		</li>
	<?php endif; ?>

	<?php if (Roles::hasRole(RoleList::ROLE_SYSTEM_DEVELOPER)): ?>
		<!-- Developer Tools -->
		<li class="nav-item sidebar-section-title">
			<small class="text-muted text-uppercase px-3"><?= e($this->strings['admin.menu.section.developer_tools']) ?></small>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= widget_url(WidgetList::WIDGETPREVIEW); ?>">
				<i class="bi bi-puzzle me-2"></i>
				<span><?= e($this->strings['admin.menu.widget_preview']) ?></span>
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="<?= event_url('system.phpinfo'); ?>">
				<i class="bi bi-info-circle me-2"></i>
				<span><?= e($this->strings['admin.menu.phpinfo']) ?></span>
			</a>
		</li>
		<?php if (defined(WidgetList::class . '::RUNTIMEDIAGNOSTICS')): ?>
			<li class="nav-item">
				<a class="nav-link" href="<?= widget_url((string) constant(WidgetList::class . '::RUNTIMEDIAGNOSTICS')); ?>">
					<i class="bi bi-activity me-2"></i>
					<span><?= e($this->strings['admin.menu.runtime_diagnostics'] ?? 'Runtime diagnostics') ?></span>
				</a>
			</li>
		<?php endif; ?>
		<li class="nav-item">
			<a class="nav-link" href="/admin/demo/template-engines.html">
				<i class="bi bi-file-earmark-code me-2"></i>
				<span><?= e($this->strings['admin.menu.template_engines']) ?></span>
			</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="/admin/developer/cli-runner.html">
				<i class="bi bi-terminal me-2"></i>
				<span><?= e($this->strings['admin.menu.cli_runner']) ?></span>
			</a>
		</li>
	<?php endif; ?>
</ul>
