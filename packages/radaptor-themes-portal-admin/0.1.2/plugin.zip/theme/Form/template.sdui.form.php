<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$this->registerLibrary(LibrariesRadaptorPortalAdmin::__RADAPTOR_PORTAL_ADMIN_SITE);

$form_id = (string)($this->props['form_id'] ?? '');
$action = (string)($this->props['action'] ?? '');
$method = (string)($this->props['method'] ?? 'post');
$form_class = trim((string)($this->props['form_class'] ?? ''));
$autocomplete = (bool)($this->props['autocomplete'] ?? true);
$title = (string)($this->props['title'] ?? '');
$sub_title = (string)($this->props['sub_title'] ?? '');
$button_save = is_array($this->props['button_save'] ?? null) ? $this->props['button_save'] : null;
$button_cancel = is_array($this->props['button_cancel'] ?? null) ? $this->props['button_cancel'] : null;
$post_javascript_file = (string)($this->props['post_javascript_file'] ?? '');
$focusable = (bool)($this->props['focusable'] ?? true);
$html_attributes = is_array($this->props['html_attributes'] ?? null) ? $this->props['html_attributes'] : [
	'data-controller' => 'form-timezone',
];

$html_attributes_string = '';

foreach ($html_attributes as $attribute_name => $attribute_value) {
	if (!is_string($attribute_name) || $attribute_name === '') {
		continue;
	}

	if ($attribute_value === null || $attribute_value === false) {
		continue;
	}

	if ($attribute_value === true) {
		$html_attributes_string .= ' ' . $attribute_name;

		continue;
	}

	$html_attributes_string .= ' ' . $attribute_name . '="' . e((string)$attribute_value) . '"';
}

$form_classes = trim($form_class . ' sdui-form');
?>
<form id="<?= e($form_id) ?>" action="<?= e($action) ?>" method="<?= e($method) ?>" class="<?= e($form_classes) ?>"<?= !$autocomplete ? ' autocomplete="off"' : '' ?><?= $html_attributes_string ?>>
	<?php if ($title !== '' || $sub_title !== ''): ?>
		<div class="mb-4">
			<?php if ($title !== ''): ?>
				<h1 class="h4 mb-2"><?= e($title) ?></h1>
			<?php endif; ?>

			<?php if ($sub_title !== ''): ?>
				<p class="text-body-secondary mb-0"><?= e($sub_title) ?></p>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<input type="hidden" name="form_id" value="<?= e($form_id) ?>">
	<?= $this->fetchSlot('hidden_fields') ?>
	<?= $this->fetchSlot('rows') ?>

	<div class="d-flex flex-wrap gap-2 mt-4">
		<?php if (is_array($button_save)): ?>
			<button class="btn btn-primary <?= e((string)($button_save['class'] ?? '')) ?>" name="submit_button" value="<?= AbstractForm::_SUBMIT_VALUE_SAVE ?>" type="submit">
				<?= Icons::get($button_save['icon'] ?? IconNames::FORM_SAVE) ?>
				<?= e((string)($button_save['text'] ?? 'Save')) ?>
			</button>
		<?php endif; ?>

		<?php if (is_array($button_cancel)): ?>
			<button class="btn btn-secondary <?= e((string)($button_cancel['class'] ?? '')) ?>" name="submit_button" value="<?= AbstractForm::_SUBMIT_VALUE_CANCEL ?>" type="submit">
				<?= Icons::get($button_cancel['icon'] ?? IconNames::FORM_CANCEL) ?>
				<?= e((string)($button_cancel['text'] ?? 'Cancel')) ?>
			</button>
		<?php endif; ?>
	</div>
</form>

<?php if ($post_javascript_file !== ''): ?>
	<script type="text/javascript" src="<?= Config::PATH_CDN->value(); ?>scripts_form/<?= e($post_javascript_file) ?>"></script>
<?php endif; ?>

<?php if ($focusable): ?>
	<script>
		document.querySelector('#<?= e($form_id) ?> input:not([type="hidden"]):not([readonly])')?.focus()
	</script>
<?php endif; ?>
