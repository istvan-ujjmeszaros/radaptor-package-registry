<?php assert(isset($this) && $this instanceof Template); ?>
<div class="editBar">
	<?php foreach ($this->props['widget_edit_commands'] as $widgetEditCommand): ?>
		<?php if (!is_array($widgetEditCommand)) {
			continue;
		} ?>
		<?php $icon = isset($widgetEditCommand['icon']) ? IconNames::tryFrom((string)$widgetEditCommand['icon']) : null; ?>
		<a href="<?= (string)($widgetEditCommand['url'] ?? ''); ?>" title="<?= (string)($widgetEditCommand['title'] ?? ''); ?>">
			<?= Icons::get($icon); ?>
		</a>
	<?php endforeach; ?>
	<?php if ($this->getWidgetConnection()->getWidget()->defaultEditCommandsAreEnabled()): ?>
		<a href="<?= form_url(FormList::WIDGETCONNECTIONPARAMS, $this->getWidgetConnection()->connection_id); ?>"
		   title="<?= e($this->strings['cms.widget_connection_params.title']) ?>">
			<?= Icons::get(IconNames::ALIGN); ?>
		</a>
		<?php if ($this->getTheme()->getWidthPossibilities()): ?>
			<a href="<?= form_url(FormList::WIDGETCONNECTIONSETTINGS, $this->getWidgetConnection()->connection_id); ?>"
			   title="<?= e($this->strings['form.widget_connection_settings.title']) ?>">
				<?= Icons::get(IconNames::CONTENT_FORMATTING); ?>
			</a>
		<?php endif; ?>
		<?php if (!$this->getWidgetConnection()->isFirst()): ?>
			<a href="<?= event_url('widgetConnection.swap', [
				'item_id' => $this->getWidgetConnection()->connection_id,
				'swap_id' => $this->getWidgetConnection()->previous()->connection_id,
			]); ?>" title="<?= e($this->strings['common.move_up']) ?>">
				<?= Icons::get(IconNames::WIDGET_UP); ?>
			</a>
		<?php endif; ?>
		<?php if (!$this->getWidgetConnection()->isLast()): ?>
			<a href="<?= event_url('widgetConnection.swap', [
				'item_id' => $this->getWidgetConnection()->connection_id,
				'swap_id' => $this->getWidgetConnection()->next()->connection_id,
			]); ?>" title="<?= e($this->strings['common.move_down']) ?>">
				<?= Icons::get(IconNames::WIDGET_DOWN); ?>
			</a>
		<?php endif; ?>
		<a href="<?= event_url('widgetConnection.remove', ['item_id' => $this->getWidgetConnection()->connection_id]); ?>"
		   title="<?= e($this->strings['cms.widget_connection.remove_from_webpage']) ?>">
			<?= Icons::get(IconNames::WIDGET_REMOVE); ?>
		</a>
	<?php endif; ?>
</div>
