<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class PackageSmokeTest extends TestCase
{
	public function testRegistryPackageMetadataIsValid(): void
	{
		$root = dirname(__DIR__);
		$metadata_path = $root . '/.registry-package.json';
		$this->assertFileExists($metadata_path);

		$decoded = json_decode((string) file_get_contents($metadata_path), true);
		$this->assertIsArray($decoded);
		$this->assertSame('radaptor/themes/portal-admin', $decoded['package'] ?? null);
		$this->assertSame('theme', $decoded['type'] ?? null);
		$this->assertSame('portal-admin', $decoded['id'] ?? null);
		$this->assertIsString($decoded['dependencies']['radaptor/core/cms'] ?? null);
		$this->assertMatchesRegularExpression('/^\^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $decoded['dependencies']['radaptor/core/cms']);
	}

	public function testThemeEntrypointsExist(): void
	{
		$root = dirname(__DIR__);

		$this->assertFileExists($root . '/theme/_layouts/template.layout_admin_default.php');
		$this->assertFileExists($root . '/theme/Cms/template._admin_dropdown.php');
		$this->assertDirectoryExists($root . '/public/assets/radaptor-portal-admin');
		$this->assertFileExists($root . '/public/assets/radaptor-portal-admin/controllers/form-builder-controller.js');
		$this->assertFileExists($root . '/public/assets/radaptor-portal-admin/controllers/form-list-controller.js');
		$this->assertFileExists($root . '/public/assets/radaptor-portal-admin/controllers/form-builder-preview-drop-controller.js');
		$this->assertFileExists($root . '/public/assets/themes/radaptor-portal-admin/css/form-builder.css');
	}

	public function testFormAdminEntrypointsAreWiredToTheListWidgetAndAssets(): void
	{
		$root = dirname(__DIR__);
		$side_menu_source = (string) file_get_contents($root . '/theme/SideMenuAdmin/template.sideMenuAdmin.php');
		$library_source = (string) file_get_contents($root . '/theme/class.LibrariesRadaptorPortalAdmin.php');
		$list_controller_source = (string) file_get_contents($root . '/public/assets/radaptor-portal-admin/controllers/form-list-controller.js');
		$css_source = (string) file_get_contents($root . '/public/assets/themes/radaptor-portal-admin/css/form-builder.css');

		$this->assertStringContainsString('::CAPTUREFORMLIST', $side_menu_source);
		$this->assertStringContainsString('::CAPTUREFORMBUILDER', $side_menu_source);
		$this->assertStringContainsString('widget_url($captureFormListWidget)', $side_menu_source);
		$this->assertStringContainsString('__ADMIN_FORM_BUILDER', $library_source);
		$this->assertStringContainsString('/assets/packages/themes/radaptor-portal-admin/css/form-builder.css', $library_source);
		$this->assertStringContainsString('searchParams.get("form")', $list_controller_source);
		$this->assertStringContainsString('searchParams.get("edit")', $list_controller_source);
		$this->assertStringContainsString('window.location.replace(url.toString())', $list_controller_source);
		$this->assertStringContainsString('searchParams.set("form", slug)', $list_controller_source);
		$this->assertStringContainsString('searchParams.delete("form")', $list_controller_source);
		$this->assertStringContainsString('searchParams.delete("edit")', $list_controller_source);
		$this->assertStringNotContainsString('searchParams.set("edit"', $list_controller_source);
		$this->assertStringContainsString('fragmentUrl.searchParams.set("definition_slug", slug)', $list_controller_source);
		$this->assertStringContainsString('body:has(.form-list)', $css_source);
		$this->assertStringContainsString('.form-list__card', $css_source);
		$this->assertStringContainsString('.form-list__editor-modal', $css_source);
	}

	public function testFormBuilderControllerKeepsReviewGuards(): void
	{
		$root = dirname(__DIR__);
		$source = (string) file_get_contents($root . '/public/assets/radaptor-portal-admin/controllers/form-builder-controller.js');

		$this->assertStringContainsString('pushUndo(this.undoScopeForEvent("form", event))', $source);
		$this->assertStringContainsString('pushUndo(this.undoScopeForEvent(`field:${this.selectedIndex}`, event))', $source);
		$this->assertStringContainsString('scheduleUndoScopeReset(scopeKey)', $source);
		$this->assertStringContainsString('const shouldOverwrite = overwrite === true', $source);
		$this->assertStringContainsString('uniqueIdentifier(base)', $source);
		$this->assertStringContainsString('hasFieldIdentifierConflict(identifier, selectedIndex)', $source);
		$this->assertStringContainsString('parseOptions(value)', $source);
		$this->assertStringNotContainsString("dropRoot.classList.add(\"radaptor-form-builder-drop-active\")\n\n            return", $source);
	}
}
