import { Controller } from "/assets/packages/radaptor-portal-admin/js/stimulus.js"
import { renderInlineLoader } from "/assets/packages/radaptor-portal-admin/js/async-loader.js"
import { createFormHooksPanel } from "./form-hooks-panel.js"

export default class extends Controller {
    static targets = [
        "status",
        "modal",
        "editorHost",
        "hooksModal",
        "hooksTitleSlug",
        "hooksStatus",
        "hooksPresetSelect",
        "hooksList",
        "hooksEditor",
        "hookTargetUrlGroup",
        "hookTargetUrlInput",
        "hookSecretGroup",
        "hookSecretInput",
        "hookEnabledInput",
        "hookNonProductionInput",
        "hookMetadataAddButton",
        "hookMetadataRows",
        "hookExcludedFields",
        "hookLogsBody",
        "hookDeleteButton",
        "hookSaveButton",
    ]

    static values = {
        createUrl: String,
        editorFragmentUrl: String,
        hooksListUrl: String,
        hooksSaveUrl: String,
        hooksDeleteUrl: String,
        hooksDeliveriesUrl: String,
        csrfToken: String,
        strings: Object,
    }

    connect() {
        this.modalInstance = null
        this.editorSlug = ""
        this.editorPanel = "form"
        this.editorDirty = false
        this.listNeedsRefresh = false
        this.editorRequestId = 0
        this.editorAbortController = null
        this.modalHidePrevented = false
        this.hooksDefinitionSlug = ""
        this.hooksPanel = createFormHooksPanel(this, {
            controllerName: "form-list",
            getDefinitionSlug: () => this.hooksDefinitionSlug,
            setDefinitionSlug: (slug) => { this.hooksDefinitionSlug = slug },
            slugFromEvent: (event) => event?.params?.slug || event?.currentTarget?.dataset?.formListSlugParam || "",
            requireDefinitionSlug: true,
        })
        this.boundModalHide = (event) => this.beforeModalHide(event)
        this.boundModalHidden = () => this.afterModalHidden()
        this.boundDirtyChange = (event) => this.onBuilderDirtyChange(event)
        this.boundBuilderChanged = (event) => this.onBuilderChanged(event)
        this.boundPanelChange = (event) => this.onBuilderPanelChange(event)
        this.boundPopState = () => this.openFromUrl({ replace: true })

        if (this.hasModalTarget) {
            this.modalTarget.addEventListener("hide.bs.modal", this.boundModalHide)
            this.modalTarget.addEventListener("hidden.bs.modal", this.boundModalHidden)
        }

        this.element.addEventListener("form-builder:dirty-change", this.boundDirtyChange)
        this.element.addEventListener("form-builder:changed", this.boundBuilderChanged)
        this.element.addEventListener("form-builder:panel-change", this.boundPanelChange)
        window.addEventListener("popstate", this.boundPopState)
        this.openFromUrl({ replace: true })
    }

    disconnect() {
        this.cancelEditorRequest()
        this.editorRequestId += 1
        this.hooksPanel?.disconnect()

        if (this.hasModalTarget) {
            this.modalTarget.removeEventListener("hide.bs.modal", this.boundModalHide)
            this.modalTarget.removeEventListener("hidden.bs.modal", this.boundModalHidden)
        }

        this.element.removeEventListener("form-builder:dirty-change", this.boundDirtyChange)
        this.element.removeEventListener("form-builder:changed", this.boundBuilderChanged)
        this.element.removeEventListener("form-builder:panel-change", this.boundPanelChange)
        window.removeEventListener("popstate", this.boundPopState)
    }

    async create(event) {
        event.preventDefault()
        const form = event.currentTarget
        const formData = new FormData(form)
        formData.set("csrf_token", this.csrfTokenValue)

        try {
            const payload = await this.postForm(this.createUrlValue, formData)
            const slug = payload?.data?.definition?.definition_slug || formData.get("definition_slug")
            this.listNeedsRefresh = true
            form.reset()
            await this.openEditorSlug(String(slug), { panel: "form" })
        } catch (error) {
            this.setStatus(this.errorMessage(error, "form.builder.error_create"))
        }
    }

    openEditor(event) {
        if (!this.isPlainPrimaryClick(event)) {
            return
        }

        event.preventDefault()
        const slug = event.params.slug || event.currentTarget?.dataset?.formListSlugParam || ""
        this.openEditorSlug(String(slug), { panel: this.panelFromUrl() })
    }

    requestCloseEditor(event) {
        event.preventDefault()
        this.modal()?.hide()
    }

    openHooks(event) {
        this.hooksPanel?.open(event)
    }

    closeHooks(event) {
        this.hooksPanel?.close(event)
    }

    closeHooksOnBackdrop(event) {
        this.hooksPanel?.closeOnBackdrop(event)
    }

    createHook(event) {
        this.hooksPanel?.create(event)
    }

    selectHook(event) {
        this.hooksPanel?.select(event)
    }

    addHookMetadataRow(event) {
        this.hooksPanel?.addMetadataRow(event)
    }

    removeHookMetadataRow(event) {
        this.hooksPanel?.removeMetadataRow(event)
    }

    saveHook(event) {
        return this.hooksPanel?.save(event)
    }

    deleteHook(event) {
        return this.hooksPanel?.delete(event)
    }

    async openEditorSlug(slug, options = {}) {
        if (slug === "" || !this.hasModalTarget || !this.hasEditorHostTarget) {
            return
        }

        const panel = this.normalizeEditorPanel(options.panel)
        if (!this.confirmEditorTransition(slug, panel)) {
            return
        }

        this.cancelEditorRequest()
        const requestId = this.editorRequestId + 1
        const abortController = new AbortController()
        this.editorRequestId = requestId
        this.editorAbortController = abortController
        this.editorSlug = slug
        this.editorPanel = panel
        this.editorDirty = false
        this.updateEditorUrl(slug, panel, Boolean(options.replace))
        this.setEditorLoading()
        this.modal()?.show()

        try {
            const fragmentUrl = new URL(this.editorFragmentUrlValue, window.location.origin)
            fragmentUrl.searchParams.set("definition_slug", slug)
            fragmentUrl.searchParams.set("panel", panel)
            const response = await fetch(fragmentUrl.toString(), {
                method: "GET",
                headers: { Accept: "text/html" },
                signal: abortController.signal,
            })
            const html = await response.text()

            if (!response.ok) {
                throw new Error(html)
            }

            if (!this.isCurrentEditorRequest(requestId, slug)) {
                return
            }

            this.editorHostTarget.innerHTML = html
        } catch (error) {
            if (error?.name === "AbortError" || !this.isCurrentEditorRequest(requestId, slug)) {
                return
            }

            this.editorHostTarget.innerHTML = `<div class="alert alert-danger m-3" role="alert">${this.escapeHtml(this.s("form.list.editor_load_failed"))}</div>`
        } finally {
            if (this.editorRequestId === requestId) {
                this.editorAbortController = null
            }
        }
    }

    openFromUrl(options = {}) {
        const url = new URL(window.location.href)
        const slug = url.searchParams.get("form") || ""
        const legacySlug = slug === "" ? url.searchParams.get("edit") || "" : ""

        if (legacySlug !== "") {
            url.searchParams.delete("edit")
            url.searchParams.set("form", legacySlug)
            window.location.replace(url.toString())

            return
        }

        if (slug === "") {
            if (this.editorSlug !== "") {
                this.modalHidePrevented = false
                this.modal()?.hide()
                if (this.modalHidePrevented && this.editorSlug !== "") {
                    this.updateEditorUrl(this.editorSlug, this.editorPanel, true)
                }
            }

            return
        }

        this.openEditorSlug(slug, { replace: Boolean(options.replace), panel: this.panelFromUrl() })
    }

    beforeModalHide(event) {
        this.modalHidePrevented = false

        if (!this.editorDirty) {
            return
        }

        if (!window.confirm(this.s("form.builder.warning.discard_unsaved"))) {
            this.modalHidePrevented = true
            event.preventDefault()
        }
    }

    afterModalHidden() {
        this.cancelEditorRequest()
        this.editorRequestId += 1
        this.editorSlug = ""
        this.editorPanel = "form"
        this.editorDirty = false
        this.setEditorLoading()
        const url = this.urlWithoutEditor()
        window.history.replaceState({}, "", url.toString())

        if (this.listNeedsRefresh) {
            window.location.assign(url.pathname + url.search)
        }
    }

    onBuilderDirtyChange(event) {
        this.editorDirty = Boolean(event.detail?.dirty)
    }

    onBuilderChanged(event) {
        this.editorDirty = Boolean(event.detail?.dirty)
        this.listNeedsRefresh = true
    }

    onBuilderPanelChange(event) {
        if (this.editorSlug === "") {
            return
        }

        const panel = this.normalizeEditorPanel(event.detail?.panel)
        this.editorPanel = panel
        this.updateEditorUrl(this.editorSlug, panel, true)
    }

    modal() {
        if (!this.hasModalTarget || !window.bootstrap?.Modal) {
            this.setStatus(this.s("form.list.editor_load_failed"))
            return null
        }

        this.modalInstance = this.modalInstance || window.bootstrap.Modal.getOrCreateInstance(this.modalTarget)

        return this.modalInstance
    }

    updateEditorUrl(slug, panel, replace = false) {
        const url = new URL(window.location.href)
        url.searchParams.delete("edit")
        url.searchParams.set("form", slug)
        url.searchParams.set("panel", panel)
        window.history[replace ? "replaceState" : "pushState"]({}, "", url.toString())
    }

    urlWithoutEditor() {
        const url = new URL(window.location.href)
        url.searchParams.delete("edit")
        url.searchParams.delete("form")
        url.searchParams.delete("panel")

        return url
    }

    panelFromUrl() {
        return this.normalizeEditorPanel(new URL(window.location.href).searchParams.get("panel"))
    }

    normalizeEditorPanel(panel) {
        const value = String(panel || "").toLowerCase()

        return ["input", "hooks"].includes(value) ? value : "form"
    }

    confirmEditorTransition(slug, panel) {
        if (!this.editorDirty || this.editorSlug === "" || (this.editorSlug === slug && this.editorPanel === panel)) {
            return true
        }

        if (window.confirm(this.s("form.builder.warning.discard_unsaved"))) {
            return true
        }

        this.updateEditorUrl(this.editorSlug, this.editorPanel, true)

        return false
    }

    cancelEditorRequest() {
        if (this.editorAbortController) {
            this.editorAbortController.abort()
            this.editorAbortController = null
        }
    }

    isCurrentEditorRequest(requestId, slug) {
        return this.editorRequestId === requestId && this.editorSlug === slug
    }

    setEditorLoading() {
        if (this.hasEditorHostTarget) {
            this.editorHostTarget.innerHTML = this.editorLoadingHtml()
        }
    }

    editorLoadingHtml() {
        const label = this.s("form.list.editor_loading")

        return `<div class="form-list__editor-loading"><span>${this.escapeHtml(label)}</span>${renderInlineLoader({ label, size: 24, color: "#8b5cf6" })}</div>`
    }

    async postForm(url, formData) {
        const response = await fetch(url, {
            method: "POST",
            headers: { Accept: "application/json" },
            body: formData,
        })
        const payload = await response.json().catch(() => ({}))

        if (!response.ok) {
            throw new Error(payload?.error?.message || this.s("form.builder.error_request"))
        }

        return payload
    }

    setStatus(message) {
        if (this.hasStatusTarget) {
            this.statusTarget.textContent = message
        }
    }

    isPlainPrimaryClick(event) {
        return event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey
    }

    errorMessage(error, fallbackKey) {
        return error instanceof Error && error.message !== "" ? error.message : this.s(fallbackKey)
    }

    escapeHtml(value) {
        return String(value).replace(/[&<>"']/g, (char) => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            "\"": "&quot;",
            "'": "&#039;",
        }[char]))
    }

    escapeAttr(value) {
        return this.escapeHtml(value)
    }

    s(key) {
        return this.stringsValue?.[key] || key
    }
}
