<?php assert(isset($this) && $this instanceof Template); ?>
<?php
$values = is_array($this->props['values'] ?? null) ? $this->props['values'] : [];
?>
<div class="col-12">
	<?php if ((string)($this->props['label'] ?? '') !== ''): ?>
		<label class="form-label d-block"><?= e((string)($this->props['label'] ?? '')) ?></label>
	<?php endif; ?>
	<div class="btn-group flex-wrap" role="group">
		<?php foreach ($values as $value): ?>
			<?php
			$url = (string)($value['url'] ?? '');
			$label = (string)($value['label'] ?? $url);
			$active = (bool)($value['active'] ?? false);
			?>
			<?php if ($active): ?>
				<span class="btn btn-sm btn-primary disabled" aria-current="true"><?= e($label) ?></span>
			<?php else: ?>
				<a class="btn btn-sm btn-outline-secondary" href="<?= e($url) ?>"><?= e($label) ?></a>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>
	<?= $this->fetchContent('helper') ?>
</div>
