<?php

class History
{
	/**
	 * @param list<string> $related_tablenames
	 * @return array<int, array{
	 *     audit_id: int,
	 *     modify_group_id: int|null,
	 *     trigger_type: string,
	 *     tablename: string,
	 *     row_id: int,
	 *     triggered_datetime: string,
	 *     user_id: int,
	 *     col: string|null,
	 *     old_value: string|null,
	 *     new_value: string|null
	 * }>
	 */
	public static function getRelatedModificationRows(
		string $tablename,
		int $row_id,
		string $connected_context,
		array $related_tablenames = [],
		string $dsn = ''
	): array {
		$dsn = Db::normalizeDsn($dsn);
		$audit_db = AuditConfig::getAuditDatabaseName($dsn);

		$related_tablenames = array_values(array_filter(
			array_unique(array_map(
				static fn (mixed $value): string => trim((string) $value),
				$related_tablenames
			)),
			static fn (string $value): bool => $value !== ''
		));

		$params = [$tablename, $row_id];
		$related_filter = '';

		if ($related_tablenames !== []) {
			$placeholders = implode(', ', array_fill(0, count($related_tablenames), '?'));
			$related_filter = " OR (
        connected_context = ?
        AND connected_owner_id = ?
        AND tablename IN ({$placeholders})
    )";

			$params[] = $connected_context;
			$params[] = $row_id;
			$params = [...$params, ...$related_tablenames];
		}

		$query = "
SELECT
    a.audit_id,
    a.modify_group_id,
    a.trigger_type,
    a.tablename,
    a.row_id,
    a.triggered_datetime,
    a.user_id,
    ad.col,
    ad.old_value,
    ad.new_value
FROM
    {$audit_db}._audit a
    LEFT JOIN {$audit_db}.audit_data ad
        ON a.audit_id = ad.audit_id
WHERE (
        tablename = ?
        AND row_id = ?
    ){$related_filter}
ORDER BY triggered_datetime;
";

		$stmt = Db::instance($dsn)->prepare($query);
		$stmt->execute($params);

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public static function addCommentAsAuditTransaction(int $audit_id, ?string $comment): int
	{
		$audit_data = Audit::getAuditMetadata($audit_id);
		$subject_type = trim((string) ($audit_data['connected_context'] ?? ''));
		$subject_id = $audit_data['connected_owner_id'] ?? null;

		if ($subject_type === '') {
			$subject_type = (string) $audit_data['tablename'];
		}

		if (!is_int($subject_id)) {
			$subject_id = (int) $audit_data['row_id'];
		}

		$comment_id = EntityComment::addComment($subject_type, $subject_id, $comment);

		EntityCommentAuditConnection::createFromArray([
			'comment_id' => $comment_id,
			'audit_id' => $audit_id,
		]);

		return $comment_id;
	}

	/**
	 * Get all modifications with comments for a specific row in a table.
	 *
	 * @param string $tablename The name of the table.
	 * @param int $row_id The ID of the row.
	 * @param string $dsn The Data Source Name.
	 * @return array<array{
	 *     ordered_audit_id: int,
	 *     trigger_type: string,
	 *     tablename: string,
	 *     row_id: int,
	 *     triggered_datetime: string,
	 *     user_id: int,
	 *     app: string,
	 *     comment?: array{
	 *         comment_id: int,
	 *         subject_type: string,
	 *         subject_id: int,
	 *         comment: string,
	 *         created: string,
	 *         created_by: int,
	 *         modified: string,
	 *         modified_by: int
	 *     }|string,
	 *     data?: array<string, mixed>,
	 *     'comment-id': int
	 * }>|null
	 */
	public static function getAllModificationsWithComments(string $tablename, int $row_id, string $dsn = ''): ?array
	{
		$dsn = Db::normalizeDsn($dsn);
		$audit_db = AuditConfig::getAuditDatabaseName($dsn);

		$query = "
			SELECT
				a.audit_id ordered_audit_id,
				a.trigger_type,
				a.tablename,
				a.row_id,
				a.triggered_datetime,
				a.user_id,
				a.app
			FROM
				{$audit_db}._audit a
			WHERE tablename = 'comments'
				AND row_id IN
				(SELECT
					comment_id
				FROM
					" . Db::getDbFromDsn($dsn) . ".comments
				WHERE subject_type = ?
					AND subject_id = ?)
			GROUP BY tablename,
				row_id
			UNION
			SELECT
				a.audit_id ordered_audit_id,
				a.trigger_type,
				a.tablename,
				a.row_id,
				a.triggered_datetime,
				a.user_id,
				a.app
			FROM
				{$audit_db}._audit a
			WHERE tablename = ?
				AND row_id = ?
			ORDER BY ordered_audit_id
		";

		$rs = DbHelper::selectManyFromQuery(
			$query,
			[
				$tablename,
				$row_id,
				$tablename,
				$row_id,
			]
		);

		if (count($rs) === 0) {
			return null;
		}

		$i = 0;

		foreach ($rs as $key => &$modify) {
			if ($modify['tablename'] != 'comments') {
				$query = "SELECT comment_id FROM comment_audit_connections WHERE audit_id=? LIMIT 1";
				$stmt = Db::instance($dsn)->prepare($query);

				$stmt->execute([$modify['ordered_audit_id']]);

				$connected_comment = $stmt->fetchColumn();

				if ($connected_comment !== false) {
					$modify['comment'] = isset($rs[$key + 1]) && $rs[$key + 1]['tablename'] == 'comments'
						? EntityComment::getCommentData($rs[$key + 1]['row_id'])
						: 'COMMENT ERROR';
					unset($rs[$key + 1]);
				}

				$modify['data'] = Audit::getAuditData($modify['ordered_audit_id']);
			} else {
				$modify['comment'] = EntityComment::getCommentData($modify['row_id']);
			}

			$modify['comment-id'] = ++$i;
		}

		// @phpstan-ignore-next-line The query result is normalized above before returning.
		return array_values($rs);
	}
}
