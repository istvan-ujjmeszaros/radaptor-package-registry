<?php

class PluginHistory extends AbstractPlugin
{
	public function getId(): string
	{
		return 'history';
	}

	public function getBasePath(): string
	{
		return __DIR__;
	}
}
