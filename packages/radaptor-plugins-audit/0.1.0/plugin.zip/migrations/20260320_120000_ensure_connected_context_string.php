<?php

class Migration_20260320_120000_ensure_connected_context_string
{
	public function getDescription(): string
	{
		return 'Ensure audit connected_context uses VARCHAR(64)';
	}

	public function run(): void
	{
		$dsn = Db::normalizeDsn('');
		$audit_dsn = AuditConfig::getAuditDsn($dsn);
		$audit_db = AuditConfig::getAuditDatabaseName($dsn);
		$pdo = Db::instance($audit_dsn);

		$stmt = $pdo->query("SHOW COLUMNS FROM {$audit_db}._audit LIKE 'connected_context_id'");

		if ($stmt->rowCount() > 0) {
			$pdo->exec(
				"ALTER TABLE {$audit_db}._audit CHANGE COLUMN connected_context_id connected_context VARCHAR(64) DEFAULT NULL"
			);

			$pdo->exec("TRUNCATE TABLE {$audit_db}._audit");
			$pdo->exec("TRUNCATE TABLE {$audit_db}.audit_data");
		}

		$stmt = $pdo->query("SHOW COLUMNS FROM {$audit_db}._audit LIKE 'connected_context'");
		$row = $stmt->fetch(PDO::FETCH_ASSOC);

		if ($row && !str_contains(strtolower((string) $row['Type']), 'varchar')) {
			$pdo->exec(
				"ALTER TABLE {$audit_db}._audit MODIFY COLUMN connected_context VARCHAR(64) DEFAULT NULL"
			);
		}
	}
}
