<?php

class AuditTriggerManager
{
	public const string COMMENT_NO_AUDIT = '__noaudit';

	public static function rebuildForConfiguredDatabases(): void
	{
		foreach (self::getAvailablePrimaryDsns() as $dsn) {
			self::rebuildForDsn($dsn);
		}
	}

	public static function deleteForConfiguredDatabases(): void
	{
		foreach (self::getAvailablePrimaryDsns() as $dsn) {
			self::deleteForDsn($dsn);
		}
	}

	/**
	 * @param array<string, structSQLTable>|null $db_data
	 */
	public static function rebuildForDsn(string $dsn, ?array $db_data = null): void
	{
		$dsn = Db::normalizeDsn($dsn);
		self::deleteForDsn($dsn);

		$audit_dsn = AuditConfig::getAuditDsn($dsn);

		if (!Db::checkDsnConnection($audit_dsn)) {
			return;
		}

		$db_data ??= self::buildSchemaData($dsn);

		foreach ($db_data as $table_data) {
			if ($table_data->comment == self::COMMENT_NO_AUDIT) {
				continue;
			}

			self::createTriggerBI($table_data, $dsn);
			self::createTriggerBU($table_data, $dsn);
			self::createTriggerBD($table_data, $dsn);
		}
	}

	public static function deleteForDsn(string $dsn): void
	{
		$dsn = Db::normalizeDsn($dsn);
		$stmt = Db::instance($dsn)
			->prepare("SHOW TRIGGERS WHERE `Trigger` LIKE '%_BI' OR `Trigger` LIKE '%_BU' OR `Trigger` LIKE '%_BD' OR `Trigger` LIKE '%_AU'");
		$stmt->execute();
		$triggers = $stmt->fetchAll(PDO::FETCH_ASSOC);

		foreach ($triggers as $trigger) {
			Db::instance($dsn)->exec("DROP TRIGGER IF EXISTS `{$trigger['Trigger']}`");
		}
	}

	/**
	 * @return list<string>
	 */
	private static function getAvailablePrimaryDsns(): array
	{
		$candidates = [Config::DB_DEFAULT_DSN->value()];
		$test_dsn = Db::rewriteDsnToTesting(Config::DB_DEFAULT_DSN->value());

		if (Db::checkDsnConnection($test_dsn)) {
			$candidates[] = $test_dsn;
		}

		$unique_dsns = [];

		foreach ($candidates as $candidate) {
			$normalized = Db::normalizeDsn($candidate);
			$unique_dsns[$normalized] = $normalized;
		}

		return array_values($unique_dsns);
	}

	/**
	 * @return array<string, structSQLTable>
	 */
	private static function buildSchemaData(string $dsn): array
	{
		$stmt = Db::instance($dsn)->prepare('SHOW TABLES');
		$stmt->execute();
		$tables = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
		$db_data = [];

		foreach ($tables as $table_name) {
			$db_data[$table_name] = GeneratorHelper::getTableDataFromDb(
				dsn: $dsn,
				tablename: $table_name,
			);
		}

		return $db_data;
	}

	private static function getAuditApplicationCheckString(string $dsn): string
	{
		if (AuditConfig::isAnonymousEnabled()) {
			return '';
		}

		$audit_db = AuditConfig::getAuditDatabaseName($dsn);

		return "	IF @application_user_id IS NULL OR @application_id IS NULL THEN
		CALL {$audit_db}.fail('@application_user_id and @application_id must be set!');
	END IF;
";
	}

	/**
	 * @param string[] $primary_keys
	 * @return array{0: string, 1: string}
	 */
	private static function generatePrimaryKeyExpressions(array $primary_keys, string $value_type = 'NEW'): array
	{
		$pkey_conditions = [];

		foreach ($primary_keys as $pkey) {
			$pkey_conditions[] = "{$value_type}.`{$pkey}`";
		}

		$row_id_value = count($primary_keys) === 1
			? $pkey_conditions[0]
			: 'NULL';
		$composite_pkeys_value = count($primary_keys) > 1
			? 'JSON_ARRAY(' . implode(', ', $pkey_conditions) . ')'
			: 'NULL';

		return [$row_id_value, $composite_pkeys_value];
	}

	private static function createTriggerBI(structSQLTable $table_data, string $dsn): false|int
	{
		$lines = [];
		$having_auto_increment = false;
		$audit_db = AuditConfig::getAuditDatabaseName($dsn);

		foreach ($table_data->fields as $field) {
			if ($field->comment == self::COMMENT_NO_AUDIT) {
				continue;
			}

			if ($field->is_auto_increment && in_array($field->column_name, $table_data->pkeys, true)) {
				$having_auto_increment = true;
				$lines[] = "IF NEW.`{$field->column_name}`=0 THEN";
				$lines[] = "    INSERT INTO {$audit_db}.audit_data SET audit_id = @audit_id, col = '{$field->column_name}', new_value = CASE WHEN NEW.`{$field->column_name}` = 0 THEN @next_id ELSE NEW.`{$field->column_name}` END;";
				$lines[] = "ELSE";
				$lines[] = "    INSERT INTO {$audit_db}.audit_data SET audit_id = @audit_id, col = '{$field->column_name}', new_value = NEW.`{$field->column_name}`;";
				$lines[] = "END IF;";
			} else {
				$lines[] = "INSERT INTO {$audit_db}.audit_data SET audit_id = @audit_id, col = '{$field->column_name}', new_value = NEW.`{$field->column_name}`;";
			}
		}

		if ($lines === []) {
			return false;
		}

		[$row_id_value, $composite_pkeys_value] = self::generatePrimaryKeyExpressions($table_data->pkeys);
		$next_id_line = $having_auto_increment
			? "    SET @next_id = (SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='{$table_data->table_name}');\n"
			: '';
		$where_clause = implode(' AND ', array_map(
			static fn (string $pkey): string => "`{$pkey}` = NEW.`{$pkey}`",
			$table_data->pkeys
		));
		$lines_string = "        " . implode("\n        ", $lines);

		$trigger = "
CREATE TRIGGER `{$table_data->table_name}_BI` BEFORE INSERT ON `{$table_data->table_name}`
FOR EACH ROW BEGIN
    DECLARE existing_count INT DEFAULT 0;

    SELECT COUNT(*) INTO existing_count
    FROM `{$table_data->table_name}`
    WHERE {$where_clause};

    IF existing_count = 0 THEN
" . self::getAuditApplicationCheckString($dsn) . "
{$next_id_line}
        INSERT INTO {$audit_db}._audit SET trigger_type='BI', modify_group_id=@modify_group_id, connected_context=@connected_context, connected_owner_id=@connected_owner_id, tablename='{$table_data->table_name}', row_id={$row_id_value}, composite_pkeys={$composite_pkeys_value}, triggered_datetime=NOW(), user_id = @application_user_id, app = @application_id;

        SET @audit_id = LAST_INSERT_ID();

{$lines_string}
    END IF;

END;";

		return Db::instance($dsn)->exec($trigger);
	}

	private static function createTriggerBU(structSQLTable $table_data, string $dsn): false|int
	{
		$null = '';
		$lines = [];
		$if_string = '';
		$i = 0;
		$audit_db = AuditConfig::getAuditDatabaseName($dsn);

		foreach ($table_data->fields as $field) {
			if ($field->comment == self::COMMENT_NO_AUDIT) {
				continue;
			}

			if (++$i > 1) {
				$if_string .= ' OR';
			}

			$if_string .= " COALESCE(OLD.`{$field->column_name}`, '{$null}')<>COALESCE(NEW.`{$field->column_name}`, '{$null}')";
			$lines[] = "IF COALESCE(OLD.`{$field->column_name}`, NULL, '{$null}')<>COALESCE(NEW.`{$field->column_name}`, NULL, '{$null}') THEN
			INSERT INTO {$audit_db}.audit_data SET audit_id = @audit_id, col = '{$field->column_name}', old_value = COALESCE(OLD.`{$field->column_name}`, NULL, '{$null}'), new_value = COALESCE(NEW.`{$field->column_name}`, NULL, '{$null}');
		END IF;";
		}

		if ($lines === []) {
			return false;
		}

		$lines_string = implode("\n		", $lines);
		[$row_id_value, $composite_pkeys_value] = self::generatePrimaryKeyExpressions($table_data->pkeys);
		$pkey_checks = implode(' OR ', array_map(
			static fn (string $pkey): string => "COALESCE(OLD.`{$pkey}`, '{$null}') <> COALESCE(NEW.`{$pkey}`, '{$null}')",
			$table_data->pkeys
		));

		$trigger = "
CREATE TRIGGER `{$table_data->table_name}_BU` BEFORE UPDATE ON `{$table_data->table_name}`
FOR EACH ROW BEGIN
" . self::getAuditApplicationCheckString($dsn) . "
	IF {$pkey_checks} THEN
		CALL {$audit_db}.fail('Can not modify primary key value!');
	END IF;

	IF{$if_string} THEN
		INSERT INTO {$audit_db}._audit SET trigger_type='BU', modify_group_id=@modify_group_id, connected_context=@connected_context, connected_owner_id=@connected_owner_id, tablename='{$table_data->table_name}', row_id = {$row_id_value}, composite_pkeys = {$composite_pkeys_value}, triggered_datetime=NOW(), user_id = @application_user_id, app = @application_id;
		SET @audit_id = LAST_INSERT_ID();

		{$lines_string}

	END IF;
END;";

		return Db::instance($dsn)->exec($trigger);
	}

	private static function createTriggerBD(structSQLTable $table_data, string $dsn): false|int
	{
		$lines = [];
		$audit_db = AuditConfig::getAuditDatabaseName($dsn);

		foreach ($table_data->fields as $field) {
			if ($field->comment == self::COMMENT_NO_AUDIT) {
				continue;
			}

			$lines[] = "INSERT INTO {$audit_db}.audit_data SET audit_id = @audit_id, col = '{$field->column_name}', old_value = OLD.`{$field->column_name}`;";
		}

		if ($lines === []) {
			return false;
		}

		$lines_string = implode("\n\t", $lines);
		[$row_id_value, $composite_pkeys_value] = self::generatePrimaryKeyExpressions($table_data->pkeys, 'OLD');

		$trigger = "
CREATE TRIGGER `{$table_data->table_name}_BD` BEFORE DELETE ON `{$table_data->table_name}`
FOR EACH ROW BEGIN
" . self::getAuditApplicationCheckString($dsn) . "
	INSERT INTO {$audit_db}._audit SET trigger_type='BD', modify_group_id=@modify_group_id, connected_context=@connected_context, connected_owner_id=@connected_owner_id, tablename='{$table_data->table_name}', row_id = {$row_id_value}, composite_pkeys = {$composite_pkeys_value}, triggered_datetime=NOW(), user_id = @application_user_id, app = @application_id;

	SET @audit_id = LAST_INSERT_ID();

	{$lines_string}

END;";

		return Db::instance($dsn)->exec($trigger);
	}
}
