<?php

class AuditConfig
{
	/**
	 * @return array{dsn: ?string, dsn_test: ?string, enable_anonymous: bool}
	 */
	public static function get(): array
	{
		$config = PluginConfigHelper::load('audit', dirname(__DIR__));

		return [
			'dsn' => self::normalizeOptionalString($config['dsn'] ?? null),
			'dsn_test' => self::normalizeOptionalString($config['dsn_test'] ?? null),
			'enable_anonymous' => array_key_exists('enable_anonymous', $config)
				? (bool) $config['enable_anonymous']
				: ApplicationConfig::DB_AUDIT_ENABLE_ANONYMOUS,
		];
	}

	public static function getAuditDsn(string $primary_dsn = ''): string
	{
		$primary_dsn = Db::normalizeDsn($primary_dsn);
		$config = self::get();

		if (self::isTestingPrimaryDsn($primary_dsn)) {
			if ($config['dsn_test'] !== null) {
				return $config['dsn_test'];
			}

			if ($config['dsn'] !== null) {
				return self::rewriteAuditDsnToTesting($config['dsn']);
			}
		}

		if ($config['dsn'] !== null) {
			return $config['dsn'];
		}

		return Db::rewriteDsnToAudit($primary_dsn);
	}

	public static function getAuditDatabaseName(string $primary_dsn = ''): string
	{
		return Db::getDbFromDsn(self::getAuditDsn($primary_dsn));
	}

	public static function isAnonymousEnabled(): bool
	{
		return self::get()['enable_anonymous'];
	}

	private static function isTestingPrimaryDsn(string $dsn): bool
	{
		return str_ends_with(Db::getDbFromDsn($dsn), '_test');
	}

	private static function rewriteAuditDsnToTesting(string $audit_dsn): string
	{
		$parts = explode(';', $audit_dsn);
		$rewritten = [];

		foreach ($parts as $part) {
			if (!str_starts_with($part, 'dbname=')) {
				$rewritten[] = $part;

				continue;
			}

			$db_name = substr($part, strlen('dbname='));

			if (str_ends_with($db_name, '_test_audit')) {
				$rewritten[] = $part;

				continue;
			}

			if (str_ends_with($db_name, '_audit')) {
				$db_name = substr($db_name, 0, -strlen('_audit')) . '_test_audit';
			} else {
				$db_name .= '_test';
			}

			$rewritten[] = 'dbname=' . $db_name;
		}

		return implode(';', $rewritten);
	}

	private static function normalizeOptionalString(mixed $value): ?string
	{
		if (!is_string($value)) {
			return null;
		}

		$value = trim($value);

		return $value === '' ? null : $value;
	}
}
