<?php

class Audit
{
	/**
	 * Begins a modification group.
	 *
	 * @param string $connected_context The connected context identifier (e.g. 'tracker_project').
	 * @param int $connected_owner_id The connected owner ID.
	 * @param string $dsn The Data Source Name (DSN).
	 *
	 * @return void
	 */
	public static function beginModificationGroup(string $connected_context, int $connected_owner_id, string $dsn = ''): void
	{
		$dsn = Db::normalizeDsn($dsn);
		$audit_dsn = AuditConfig::getAuditDsn($dsn);
		$audit_db = AuditConfig::getAuditDatabaseName($dsn);
		$query = "SET @modify_group_id = (SELECT COALESCE(MAX(modify_group_id),0)+1 FROM {$audit_db}._audit), @connected_context=?, @connected_owner_id=?";

		$stmt = Db::instance($audit_dsn)->prepare($query);
		$stmt->execute([
			$connected_context,
			$connected_owner_id,
		]);
	}

	/**
	 * Sets the connected data for the modification group.
	 *
	 * @param string $connected_context The connected context identifier (e.g. 'tracker_project').
	 * @param int $connected_owner_id The ID of the connected owner.
	 * @param string $dsn The Data Source Name (DSN) string. Defaults to an empty string.
	 * @return void
	 */
	public static function setModificationGroupConnectedData(string $connected_context, int $connected_owner_id, string $dsn = ''): void
	{
		$dsn = Db::normalizeDsn($dsn);

		$query = "SET @connected_context=?, @connected_owner_id=?";

		$stmt = Db::instance(AuditConfig::getAuditDsn($dsn))->prepare($query);
		$stmt->execute([
			$connected_context,
			$connected_owner_id,
		]);
	}

	/**
	 * Ends the modification group by resetting related database session variables.
	 *
	 * @param string $dsn The data source name.
	 * @return void
	 */
	public static function endModificationGroup(string $dsn = ''): void
	{
		$dsn = Db::normalizeDsn($dsn);

		$query = "SET @modify_group_id = NULL, @connected_context = NULL, @connected_owner_id = NULL";

		Db::instance(AuditConfig::getAuditDsn($dsn))->exec($query);
	}

	/**
	 * Check if the given DSN is audited.
	 *
	 * @param string $dsn The Data Source Name to check.
	 * @return bool True if the DSN is audited, false otherwise.
	 */
	public static function isAudited(string $dsn = ''): bool
	{
		$dsn = Db::normalizeDsn($dsn);

		return Db::checkDsnConnection(AuditConfig::getAuditDsn($dsn));
	}

	/**
	 * Get the last audit ID from the audit table.
	 *
	 * @param string $dsn The data source name.
	 * @return int|null The last audit ID or null if not found.
	 */
	public static function getLastAuditId(string $dsn = ''): ?int
	{
		$dsn = Db::normalizeDsn($dsn);
		$audit_dsn = AuditConfig::getAuditDsn($dsn);
		$audit_db = AuditConfig::getAuditDatabaseName($dsn);
		$query = "SELECT audit_id, tablename FROM {$audit_db}._audit ORDER BY audit_id DESC LIMIT 1";

		$stmt = Db::instance($audit_dsn)->prepare($query);

		$stmt->execute();

		$rs = $stmt->fetch(PDO::FETCH_ASSOC);

		if (!isset($rs['audit_id'])) {
			return null;
		}

		return $rs['audit_id'];
	}

	/**
	 * Get creation data for a specific row in a table.
	 *
	 * @param string $tablename The name of the table.
	 * @param int $row_id The ID of the row.
	 * @param string $dsn The Data Source Name.
	 * @return array{audit_id: int, trigger_type: string, user_id: int, username: string, app: string, triggered_datetime: string, last_seen: string}|null The creation data or null if not found.
	 */
	public static function getCreationData(string $tablename, int $row_id, string $dsn = ''): ?array
	{
		$dsn = Db::normalizeDsn($dsn);

		$query = "
			SELECT
				a.audit_id,
				a.trigger_type,
				u.user_id,
				u.username,
				a.app,
				a.triggered_datetime,
				u.last_seen
			FROM
				" . AuditConfig::getAuditDatabaseName($dsn) . "._audit a
			LEFT JOIN
				" . Db::getDbFromDsn($dsn) . ".users u
			ON a.user_id = u.user_id
			WHERE trigger_type = 'BI'
				AND tablename = ?
				AND row_id = ?
			ORDER BY a.triggered_datetime ASC
			LIMIT 1;
			";

		$stmt = Db::instance($dsn)->prepare($query);
		$stmt->execute([
			$tablename,
			$row_id,
		]);

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	/**
	 * Get last modification data for a specific row in a table.
	 *
	 * @param string $tablename The name of the table.
	 * @param int $row_id The ID of the row.
	 * @param string $dsn The Data Source Name.
	 * @return array{audit_id: int, trigger_type: string, user_id: int, username: string, app: string, triggered_datetime: string, last_seen: string}|null The last modification data or null if not found.
	 */
	public static function getLastModifyData(string $tablename, int $row_id, string $dsn = ''): ?array
	{
		$dsn = Db::normalizeDsn($dsn);

		$query = "
			SELECT
				a.audit_id,
				a.trigger_type,
				u.user_id,
				u.username,
				a.app,
				a.triggered_datetime,
				u.last_seen
			FROM
				" . AuditConfig::getAuditDatabaseName($dsn) . "._audit a
			LEFT JOIN
				" . Db::getDbFromDsn($dsn) . ".users u
			ON a.user_id = u.user_id
			WHERE trigger_type = 'BU'
				AND tablename = ?
				AND row_id = ?
			ORDER BY a.triggered_datetime DESC
			LIMIT 1;
			";

		$stmt = Db::instance($dsn)->prepare($query);
		$stmt->execute([
			$tablename,
			$row_id,
		]);

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	/**
	 * Get deletion data for a specific row in a table.
	 *
	 * @param string $tablename The name of the table.
	 * @param int $row_id The ID of the row.
	 * @param string $dsn The Data Source Name.
	 * @return array{audit_id: int, trigger_type: string, user_id: int, username: string, app: string, triggered_datetime: string, last_seen: string}|null The deletion data or null if not found.
	 */
	public static function getDeletionData(string $tablename, int $row_id, string $dsn = ''): ?array
	{
		$dsn = Db::normalizeDsn($dsn);

		$query = "
			SELECT
				a.audit_id,
				a.trigger_type,
				u.user_id,
				u.username,
				a.app,
				a.triggered_datetime,
				u.last_seen
			FROM
				" . AuditConfig::getAuditDatabaseName($dsn) . "._audit a
			LEFT JOIN
				" . Db::getDbFromDsn($dsn) . ".users u
			ON a.user_id = u.user_id
			WHERE trigger_type = 'BD'
				AND tablename = ?
				AND row_id = ?
			ORDER BY a.triggered_datetime DESC
			LIMIT 1;
			";

		$stmt = Db::instance($dsn)->prepare($query);
		$stmt->execute([
			$tablename,
			$row_id,
		]);

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	/**
	 * Get all modifications for a specific row in a table.
	 *
	 * @param string $tablename The name of the table.
	 * @param int $row_id The ID of the row.
	 * @param string $dsn The Data Source Name.
	 * @return array<array{audit_id: int, tablename: string, row_id: int, trigger_type: string, user_id: int, username: string, app: string, triggered_datetime: string, last_seen: string}>|null The array of modifications or null if not found.
	 */
	public static function getAllModifications(string $tablename, int $row_id, string $dsn = ''): ?array
	{
		$dsn = Db::normalizeDsn($dsn);

		$query = "
			SELECT
				a.audit_id,
				a.tablename,
				a.row_id,
				a.trigger_type,
				u.user_id,
				u.username,
				a.app,
				a.triggered_datetime,
				u.last_seen
			FROM
				" . AuditConfig::getAuditDatabaseName($dsn) . "._audit a
			LEFT JOIN
				" . Db::getDbFromDsn($dsn) . ".users u
			ON a.user_id = u.user_id
			WHERE tablename = ?
				AND row_id = ?
			ORDER BY a.triggered_datetime DESC ;
			";

		$stmt = Db::instance($dsn)->prepare($query);
		$stmt->execute([
			$tablename,
			$row_id,
		]);

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	/**
	 * Retrieves audit data for a given audit ID.
	 *
	 * @param int $audit_id The ID of the audit to retrieve data for.
	 * @param bool $get_calculated_fields_raw_values Whether to include calculated fields with raw values.
	 * @param string $dsn The Data Source Name for the database connection.
	 * @return array<int, array{
	 *     audit_id: int,
	 *     col: string,
	 *     old_value: ?string,
	 *     new_value: ?string
	 * }>|null The audit data as an array of associative arrays, or null if no data is found.
	 */
	public static function getAuditData(int $audit_id, bool $get_calculated_fields_raw_values = false, string $dsn = ''): ?array
	{
		$dsn = Db::normalizeDsn($dsn);

		if ($get_calculated_fields_raw_values) {
			$filter = "";
		} else {
			$filter = "AND col NOT LIKE '__%' ";
		}

		$query = "
			SELECT
				*
			FROM
				" . AuditConfig::getAuditDatabaseName($dsn) . ".audit_data ad
			WHERE audit_id=? {$filter};
			";

		$stmt = Db::instance($dsn)->prepare($query);
		$stmt->execute([$audit_id]);

		return $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	/**
	 * Retrieves audit metadata for a given audit ID.
	 *
	 * @param int $audit_id The ID of the audit to retrieve metadata for.
	 * @param string $dsn The Data Source Name for the database connection.
	 * @return array{
	 *     tablename: string,
	 *     row_id: int,
	 *     connected_context?: string|null,
	 *     connected_owner_id?: int|null
	 * }|null The audit metadata as an associative array, or null if no data is found.
	 */
	public static function getAuditMetadata(int $audit_id, string $dsn = ''): ?array
	{
		$dsn = Db::normalizeDsn($dsn);

		$query = "SELECT tablename, row_id, connected_context, connected_owner_id FROM " . AuditConfig::getAuditDatabaseName($dsn) . "._audit WHERE audit_id=? LIMIT 1";

		$stmt = Db::instance($dsn)->prepare($query);

		$stmt->execute([$audit_id]);

		return $stmt->fetch(PDO::FETCH_ASSOC);
	}

	/**
	 * Retrieves the last modification time for a specific row in a table.
	 *
	 * @param string $tablename The name of the table.
	 * @param int $row_id The ID of the row.
	 * @param string $dsn The Data Source Name for the database connection.
	 * @return string The last modification time as a string.
	 */
	public static function getLastModifyTime(string $tablename, int $row_id, string $dsn = ''): string
	{
		$dsn = Db::normalizeDsn($dsn);

		$query = "
			SELECT
				triggered_datetime
			FROM
				" . AuditConfig::getAuditDatabaseName($dsn) . "._audit a
			WHERE tablename = ?
				AND row_id = ?
			ORDER BY audit_id DESC LIMIT 1;
			";

		return DbHelper::selectOneColumnFromQuery(
			$query,
			[$tablename, $row_id]
		);
	}
}
