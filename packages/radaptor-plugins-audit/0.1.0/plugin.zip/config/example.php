<?php

return [
	// Optional explicit audit DSNs. Leave them unset to derive <main_db>_audit
	// and <main_db>_test_audit automatically.
	//
	// 'dsn' => 'mysql:host=mariadb;port=3306;user=root;password=radaptor;dbname=tracker_audit',
	// 'dsn_test' => 'mysql:host=mariadb;port=3306;user=root;password=radaptor;dbname=tracker_test_audit',
];
