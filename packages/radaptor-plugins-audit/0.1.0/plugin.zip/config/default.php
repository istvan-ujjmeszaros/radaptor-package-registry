<?php

return [
	// Leave null to derive <main_db>_audit and <main_db>_test_audit automatically.
	'dsn' => null,
	'dsn_test' => null,
	'enable_anonymous' => ApplicationConfig::DB_AUDIT_ENABLE_ANONYMOUS,
];
