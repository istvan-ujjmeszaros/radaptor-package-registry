<?php

class PluginAudit extends AbstractPlugin
{
	public function getId(): string
	{
		return 'audit';
	}

	public function getBasePath(): string
	{
		return __DIR__;
	}

	public function afterBuildDb(string $dsn, array $db_data): void
	{
		AuditTriggerManager::rebuildForDsn($dsn, $db_data);
	}

	public function afterSync(): void
	{
		AuditTriggerManager::rebuildForConfiguredDatabases();
	}

	public function beforeUninstall(): void
	{
		AuditTriggerManager::deleteForConfiguredDatabases();
	}
}
