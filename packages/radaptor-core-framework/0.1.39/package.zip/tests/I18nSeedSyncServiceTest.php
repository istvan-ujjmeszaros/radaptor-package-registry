<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../classes/enum.CsvImportMode.php';
require_once __DIR__ . '/../classes/class.LocaleService.php';
require_once __DIR__ . '/../classes/class.LocaleRegistry.php';
require_once __DIR__ . '/../classes/class.I18nCsvSchema.php';
require_once __DIR__ . '/../classes/class.I18nSeedSyncService.php';

if (!class_exists('ImportExportDatasetI18nTranslations', false)) {
	final class ImportExportDatasetI18nTranslations
	{
		/** @var list<array{csv: string, options: array<string, mixed>}> */
		public static array $imports = [];

		/**
		 * @param array<string, mixed> $options
		 * @return array<string, mixed>
		 */
		public function import(string $csvContent, array $options = []): array
		{
			self::$imports[] = [
				'csv' => $csvContent,
				'options' => $options,
			];

			$processed = self::countRows($csvContent);

			return [
				'processed' => $processed,
				'inserted' => $processed,
				'updated' => 0,
				'imported' => $processed,
				'skipped' => 0,
				'deleted' => 0,
				'errors' => [],
				'row_results' => array_fill(0, $processed, ['reason' => 'imported']),
			];
		}

		private static function countRows(string $csvContent): int
		{
			$handle = fopen('php://temp', 'r+');

			if ($handle === false) {
				return 0;
			}

			fwrite($handle, $csvContent);
			rewind($handle);
			fgetcsv($handle, 0, ',', '"', '');
			$count = 0;

			while (($row = fgetcsv($handle, 0, ',', '"', '')) !== false) {
				if ($row === [null]) {
					continue;
				}

				$count++;
			}

			fclose($handle);

			return $count;
		}
	}
}

final class I18nSeedSyncServiceTest extends TestCase
{
	private string $tempDir;

	protected function setUp(): void
	{
		$this->tempDir = sys_get_temp_dir() . '/radaptor-i18n-sync-' . bin2hex(random_bytes(6));
		mkdir($this->tempDir, 0o755, true);
		ImportExportDatasetI18nTranslations::$imports = [];
	}

	protected function tearDown(): void
	{
		$this->deleteTree($this->tempDir);
	}

	public function testUnderscoreOnlyLegacySeedFileIsImportedForCanonicalLocale(): void
	{
		$this->writeSeed('en_US', 'Legacy text');

		$result = I18nSeedSyncService::syncDirectory($this->tempDir, [
			'dry_run' => true,
		]);

		$this->assertFalse($result['has_errors']);
		$this->assertSame(['en-US'], $result['locales']);
		$this->assertSame(1, $result['files_processed']);
		$this->assertSame($this->tempDir . '/en_US.csv', $result['files'][0]['file']);
		$this->assertSame('en-US', $result['files'][0]['locale']);
		$this->assertCount(1, ImportExportDatasetI18nTranslations::$imports);
		$this->assertStringContainsString('Legacy text', ImportExportDatasetI18nTranslations::$imports[0]['csv']);
		$this->assertSame('en-US', ImportExportDatasetI18nTranslations::$imports[0]['options']['expect_locale']);
	}

	public function testCanonicalSeedFileWinsOverLegacyDuplicate(): void
	{
		$this->writeSeed('en_US', 'Legacy text');
		$this->writeSeed('en-US', 'Canonical text');

		$result = I18nSeedSyncService::syncDirectory($this->tempDir, [
			'dry_run' => true,
		]);

		$this->assertFalse($result['has_errors']);
		$this->assertSame(['en-US'], $result['locales']);
		$this->assertSame(1, $result['files_processed']);
		$this->assertSame($this->tempDir . '/en-US.csv', $result['files'][0]['file']);
		$this->assertCount(1, ImportExportDatasetI18nTranslations::$imports);
		$this->assertStringContainsString('Canonical text', ImportExportDatasetI18nTranslations::$imports[0]['csv']);
		$this->assertStringNotContainsString('Legacy text', ImportExportDatasetI18nTranslations::$imports[0]['csv']);
	}

	private function writeSeed(string $filenameLocale, string $text): void
	{
		$locale = LocaleService::canonicalize($filenameLocale);
		$path = $this->tempDir . '/' . $filenameLocale . '.csv';
		$handle = fopen($path, 'w');

		$this->assertIsResource($handle);
		fputcsv($handle, I18nCsvSchema::NORMALIZED_HEADER, ',', '"', '');
		fputcsv($handle, ['admin', 'menu.locales', '', $locale, 'Locales', 'Locales', '0', '0', $text], ',', '"', '');
		fclose($handle);
	}

	private function deleteTree(string $path): void
	{
		if (!is_dir($path)) {
			return;
		}

		$items = scandir($path);

		if ($items === false) {
			return;
		}

		foreach ($items as $item) {
			if ($item === '.' || $item === '..') {
				continue;
			}

			$child = $path . '/' . $item;

			if (is_dir($child)) {
				$this->deleteTree($child);
			} else {
				unlink($child);
			}
		}

		rmdir($path);
	}
}
