<?php

class CLICommandI18nDoctor extends AbstractCLICommand
{
	public function getName(): string
	{
		return 'Diagnose i18n workflow health';
	}

	public function getDocs(): string
	{
		return <<<'DOC'
			Run the i18n seed linter, fallback literal scanner, hardcoded UI scanner, shipped database sync audit, package reference audit, locale diagnostics and coverage summary.

			Usage: radaptor i18n:doctor [--all-packages] [--json] [--strict-hardcoded]

			JSON shipped_database.status values:
			  ok          database matches shipped seeds
			  customized  only human-reviewed rows differ from shipped expected_text
			  needs_sync  missing or changed rows can be repaired with suggested_command
			  error       seed read/validation or audit failed

			shipped_database.conflicts is a compatibility alias for customized_rows.
			DOC;
	}

	public function isWebRunnable(): bool
	{
		return true;
	}

	public function getWebTimeout(): int
	{
		return 90;
	}

	public function run(): void
	{
		$json = Request::hasArg('json');
		$all_packages = Request::hasArg('all-packages');
		$strict_hardcoded = Request::hasArg('strict-hardcoded');
		$lint = I18nSeedLintService::lint(I18nSeedTargetDiscovery::discoverTargets([
			'all_packages' => $all_packages,
		]), [
			'check_global_duplicates' => !$all_packages,
		]);
		$literals = I18nFallbackLiteralScanner::scan([
			'all_packages' => $all_packages,
		]);
		$hardcoded = I18nHardcodedUiScanner::scan([
			'all_packages' => $all_packages,
		]);
		$shipped_database = I18nShippedDatabaseAuditService::audit([
			'all_packages' => $all_packages,
		]);
		$references = $this->auditPackageReferences($all_packages);
		$locale_diagnostics = LocaleDiagnosticsService::diagnose();
		$coverage = I18nCoverageService::summarize();
		$missing_total = array_sum(array_map(
			static fn (array $locale): int => (int) ($locale['missing'] ?? 0),
			$coverage['locales']
		));
		$stale_total = array_sum(array_map(
			static fn (array $locale): int => (int) ($locale['stale'] ?? 0),
			$coverage['locales']
		));
		$failed = $lint['errors'] > 0
			|| $literals['issues'] > 0
			|| !in_array($shipped_database['status'], ['ok', 'customized'], true)
			|| ($references['status'] ?? 'ok') === 'error'
			|| $locale_diagnostics['status'] !== 'success'
			|| $missing_total > 0
			|| $stale_total > 0
			|| ($strict_hardcoded && $hardcoded['issues'] > 0);
		$result = [
			'status' => $failed ? 'error' : 'success',
			'scope' => $all_packages ? 'all_packages' : 'active',
			'lint' => $lint,
			'literals' => $literals,
			'hardcoded_ui' => $hardcoded,
			'shipped_database' => $shipped_database,
			'i18n_references' => $references,
			'locales' => $locale_diagnostics,
			'coverage' => $coverage,
		];

		if ($json) {
			echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";

			if ($failed) {
				exit(1);
			}

			return;
		}

		echo "Seed lint: {$lint['errors']} errors, {$lint['warnings']} warnings\n";
		echo 'Scope: ' . ($all_packages ? 'all packages audit' : 'active sync scope') . "\n";
		echo "Fallback literals: {$literals['issues']} issues, {$literals['allowed_literals']} allowed literals\n";
		echo "Hardcoded UI literals: {$hardcoded['issues']} warnings\n";
		echo "Shipped DB sync: {$shipped_database['status']}, missing {$shipped_database['missing_rows']}, changed {$shipped_database['changed_rows']}, customized {$shipped_database['customized_rows']}\n";
		echo "I18n references: {$references['status']}, missing {$references['missing_references']}, references {$references['references_scanned']}\n";
		echo 'Locale diagnostics: ' . count($locale_diagnostics['issues']) . ' errors, ' . count($locale_diagnostics['warnings']) . ' warnings, ' . count($locale_diagnostics['info']) . " info\n";

		foreach (array_slice($hardcoded['results'], 0, 10) as $row) {
			echo "WARNING {$row['file']}:{$row['line']} literal=\"{$row['literal']}\" {$row['code']}\n";
		}

		foreach (array_slice($shipped_database['issues'], 0, 10) as $row) {
			echo 'ERROR shipped-db ' . json_encode($row, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
		}

		foreach (array_slice($references['issues'], 0, 10) as $row) {
			echo 'ERROR i18n-reference ' . json_encode($row, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
		}

		foreach (array_slice($locale_diagnostics['issues'], 0, 10) as $row) {
			echo 'ERROR locale ' . json_encode($row, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
		}

		foreach (array_slice($locale_diagnostics['warnings'], 0, 10) as $row) {
			echo 'WARNING locale ' . json_encode($row, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
		}

		foreach (array_slice($locale_diagnostics['info'], 0, 10) as $row) {
			echo 'INFO locale ' . json_encode($row, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
		}

		if ($hardcoded['issues'] > 10) {
			$remaining = $hardcoded['issues'] - 10;
			echo "... and {$remaining} more hardcoded UI warning(s)\n";
		}

		echo "Coverage missing translations: {$missing_total}\n";
		echo "Coverage stale translations: {$stale_total}\n";

		foreach ($coverage['locales'] as $locale) {
			echo "{$locale['locale']}: {$locale['translated']}/{$locale['total']} translated ({$locale['translated_percent']}%), missing {$locale['missing']}, stale {$locale['stale']}\n";
		}

		if ($failed) {
			exit(1);
		}
	}

	/**
	 * @return array{
	 *     status: string,
	 *     references_scanned: int,
	 *     missing_references: int,
	 *     issues: list<array<string, mixed>>
	 * }
	 */
	private function auditPackageReferences(bool $all_packages): array
	{
		if (!class_exists('I18nReferenceAuditService')) {
			return [
				'status' => 'skipped',
				'references_scanned' => 0,
				'missing_references' => 0,
				'issues' => [],
			];
		}

		$service_class = 'I18nReferenceAuditService';

		if (!method_exists($service_class, 'audit')) {
			return [
				'status' => 'skipped',
				'references_scanned' => 0,
				'missing_references' => 0,
				'issues' => [],
			];
		}

		/** @var array{status: string, references_scanned: int, missing_references: int, issues: list<array<string, mixed>>} $result */
		$result = $service_class::audit([
			'all_packages' => $all_packages,
		]);

		return $result;
	}
}
