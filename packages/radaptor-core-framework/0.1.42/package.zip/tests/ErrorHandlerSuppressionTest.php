<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../bootstrap.error_handlers.php';

final class ErrorHandlerSuppressionTest extends TestCase
{
	private int $_previous_error_reporting = 0;

	protected function setUp(): void
	{
		parent::setUp();

		$this->_previous_error_reporting = error_reporting();
	}

	protected function tearDown(): void
	{
		error_reporting($this->_previous_error_reporting);

		parent::tearDown();
	}

	public function testTestingEnvironmentHandlerRespectsSuppressedWarnings(): void
	{
		error_reporting(E_ALL & ~E_USER_WARNING);

		$this->assertFalse(testingEnvironmentErrorToExceptionConversionHandler(
			E_USER_WARNING,
			'suppressed warning'
		));
	}

	public function testRuntimeErrorHandlerRespectsSuppressedWarningsWithoutOutput(): void
	{
		error_reporting(E_ALL & ~E_USER_WARNING);

		ob_start();

		try {
			$result = errorHandler(E_USER_WARNING, 'suppressed warning', __FILE__, __LINE__);
			$output = (string)ob_get_clean();
		} catch (Throwable $exception) {
			ob_end_clean();

			throw $exception;
		}

		$this->assertFalse($result);
		$this->assertSame('', $output);
	}
}
