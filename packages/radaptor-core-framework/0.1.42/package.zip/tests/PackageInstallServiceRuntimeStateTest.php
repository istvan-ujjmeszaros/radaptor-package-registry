<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

if (!defined('DEPLOY_ROOT')) {
	$fixture_root = sys_get_temp_dir() . '/radaptor-package-runtime-state-' . bin2hex(random_bytes(6));
	define('DEPLOY_ROOT', $fixture_root . '/');
	define('PACKAGE_RUNTIME_STATE_CREATED_DEPLOY_ROOT', true);
} else {
	define('PACKAGE_RUNTIME_STATE_CREATED_DEPLOY_ROOT', false);
}

require_once __DIR__ . '/../classes/class.PackageTypeHelper.php';
require_once __DIR__ . '/../classes/class.PackageVersionHelper.php';
require_once __DIR__ . '/../classes/class.PackageDependencyHelper.php';
require_once __DIR__ . '/../classes/class.PackageMetadataHelper.php';
require_once __DIR__ . '/../classes/class.PackageManifest.php';
require_once __DIR__ . '/../classes/class.PackageLockfile.php';
require_once __DIR__ . '/../classes/class.PackageRegistryClient.php';
require_once __DIR__ . '/../classes/class.GitRepositoryInspector.php';
require_once __DIR__ . '/../classes/class.LayoutRenameRegistry.php';
require_once __DIR__ . '/../classes/class.LayoutReconciliationService.php';
require_once __DIR__ . '/../classes/seeding/class.SeedRunner.php';
require_once __DIR__ . '/../classes/class.PackageInstallService.php';

final class PackageInstallServiceRuntimeStateTest extends TestCase
{
	/** @var list<string> */
	private static array $_temp_roots = [];

	private static ?string $_package_id = null;

	public static function tearDownAfterClass(): void
	{
		self::deleteTree(self::packageTarget());

		foreach (self::$_temp_roots as $root) {
			self::deleteTree($root);
		}

		if (PACKAGE_RUNTIME_STATE_CREATED_DEPLOY_ROOT === true) {
			self::deleteTree(rtrim(DEPLOY_ROOT, '/'));
		}
	}

	protected function tearDown(): void
	{
		self::deleteTree(self::packageTarget());

		foreach (self::$_temp_roots as $root) {
			self::deleteTree($root);
		}

		self::$_temp_roots = [];

		parent::tearDown();
	}

	public function testInstalledRegistryPackageMatchesLockWhenMetadataMatches(): void
	{
		$target = self::packageTarget();
		$package_id = self::packageId();
		self::writeMetadata($target, 'radaptor/core/' . $package_id, 'core', $package_id, '0.1.39');

		$this->assertTrue($this->matchesLock($target, self::lockedPackage('0.1.39')));
	}

	public function testInstalledRegistryPackageMatchesLockWhenMetadataVersionNeedsNormalization(): void
	{
		$target = self::packageTarget();
		$package_id = self::packageId();
		self::writeMetadata($target, 'radaptor/core/' . $package_id, 'core', $package_id, '1.0');

		$this->assertTrue($this->matchesLock($target, self::lockedPackage('1.0.0')));
	}

	public function testInstalledRegistryPackageDoesNotMatchWhenVersionDiffers(): void
	{
		$target = self::packageTarget();
		$package_id = self::packageId();
		self::writeMetadata($target, 'radaptor/core/' . $package_id, 'core', $package_id, '0.1.38');

		$this->assertFalse($this->matchesLock($target, self::lockedPackage('0.1.39')));
	}

	public function testInstalledRegistryPackageDoesNotMatchWhenMetadataIsMissingOrInvalid(): void
	{
		$target = self::packageTarget();
		self::mkdir($target);
		$this->assertFalse($this->matchesLock($target, self::lockedPackage('0.1.39')));

		file_put_contents($target . '/.registry-package.json', '{not-json');
		$this->assertFalse($this->matchesLock($target, self::lockedPackage('0.1.39')));
	}

	public function testRegistryPackageRefreshDetectionUsesInstalledRuntimeMetadata(): void
	{
		$target = self::packageTarget();
		$package_id = self::packageId();
		$package_key = 'core:' . self::packageId();
		$package_name = 'radaptor/core/' . $package_id;
		$current = [$package_key => self::lockedPackage('0.1.39')];
		$next = [$package_key => self::lockedPackage('0.1.39')];

		self::writeMetadata($target, $package_name, 'core', $package_id, '0.1.39');
		$this->assertSame([], $this->collectRefreshKeys($current, $next));

		unlink($target . '/.registry-package.json');
		$this->assertSame([$package_key], $this->collectRefreshKeys($current, $next));

		self::writeMetadata($target, $package_name, 'core', $package_id, '0.1.38');
		$this->assertSame([$package_key], $this->collectRefreshKeys($current, $next));
	}

	public function testDryRunReportsRefreshedWhenLockfileIsUnchangedButRuntimeMetadataIsStale(): void
	{
		$package_id = self::packageId();
		$package_key = 'core:' . $package_id;
		$package_name = 'radaptor/core/' . $package_id;
		$registry_root = self::tempRoot('registry');
		$registry_url = self::fileUrl($registry_root . '/registry.json');
		$dist_url = self::fileUrl($registry_root . '/dist/' . $package_id . '.zip');

		self::writeRegistry($registry_root . '/registry.json', $package_name, $package_id, '1.0.0', $dist_url);
		self::writeManifest($registry_root . '/radaptor.json', $package_name, $package_id, $registry_url, '1.0.0');
		self::writeResolvedLockFromManifest($registry_root . '/radaptor.json', $registry_root . '/radaptor.lock.json');
		self::writeMetadata(self::packageTarget(), $package_name, 'core', $package_id, '0.9.0');

		$result = PackageInstallService::syncPaths(
			$registry_root . '/radaptor.json',
			$registry_root . '/radaptor.lock.json',
			false,
			true,
			null,
			false,
			false,
			true
		);

		$this->assertFalse($result['lockfile_changed']);
		$this->assertSame('refreshed', self::packageAction($result, $package_key));
	}

	public function testRegistryPackageRefreshPreservesCleanupSafetyGuards(): void
	{
		$target = self::packageTarget();
		self::mkdir($target . '/.git');

		$this->expectException(RuntimeException::class);
		$this->expectExceptionMessage('contains .git metadata');

		$method = new ReflectionMethod(PackageInstallService::class, 'installRegistryPackage');
		$method->invoke(null, self::lockedPackage('0.1.39'), $target);
	}

	/**
	 * @param array<string, mixed> $locked_package
	 */
	private function matchesLock(string $target, array $locked_package): bool
	{
		$method = new ReflectionMethod(PackageInstallService::class, 'installedRegistryPackageMatchesLock');

		return (bool) $method->invoke(null, $locked_package, $target);
	}

	/**
	 * @param array<string, array<string, mixed>> $current
	 * @param array<string, array<string, mixed>> $next
	 * @return list<string>
	 */
	private function collectRefreshKeys(array $current, array $next): array
	{
		$method = new ReflectionMethod(PackageInstallService::class, 'collectRegistryPackageKeysNeedingInstall');
		$result = $method->invoke(null, $current, $next);

		$this->assertIsArray($result);

		return array_values(array_map('strval', $result));
	}

	/**
	 * @return array<string, mixed>
	 */
	private static function lockedPackage(string $version): array
	{
		$package_id = self::packageId();

		return [
			'type' => 'core',
			'id' => $package_id,
			'package' => 'radaptor/core/' . $package_id,
			'resolved' => [
				'type' => 'registry',
				'path' => 'packages/registry/core/' . $package_id,
				'version' => $version,
			],
		];
	}

	private static function packageTarget(): string
	{
		return rtrim(DEPLOY_ROOT, '/') . '/packages/registry/core/' . self::packageId();
	}

	private static function packageId(): string
	{
		if (self::$_package_id === null) {
			self::$_package_id = 'framework-runtime-state-' . strtolower(bin2hex(random_bytes(4)));
		}

		return self::$_package_id;
	}

	private static function tempRoot(string $name): string
	{
		$root = sys_get_temp_dir() . '/radaptor-package-runtime-state-' . $name . '-' . bin2hex(random_bytes(6));
		self::$_temp_roots[] = $root;
		self::mkdir($root);

		return $root;
	}

	private static function writeMetadata(string $target, string $package, string $type, string $id, string $version): void
	{
		self::mkdir($target);
		file_put_contents(
			$target . '/.registry-package.json',
			json_encode([
				'package' => $package,
				'type' => $type,
				'id' => $id,
				'version' => $version,
			], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
		);
	}

	private static function mkdir(string $path): void
	{
		if (!is_dir($path) && !mkdir($path, 0o777, true) && !is_dir($path)) {
			throw new RuntimeException("Unable to create fixture directory: {$path}");
		}
	}

	private static function writeRegistry(string $path, string $package, string $id, string $version, string $dist_url): void
	{
		self::writeJson($path, [
			'packages' => [
				$package => [
					'latest' => $version,
					'versions' => [
						$version => [
							'type' => 'core',
							'id' => $id,
							'dist' => [
								'type' => 'zip',
								'url' => $dist_url,
								'sha256' => str_repeat('a', 64),
							],
						],
					],
				],
			],
		]);
	}

	private static function writeManifest(string $path, string $package, string $id, string $registry_url, string $version): void
	{
		self::writeJson($path, [
			'manifest_version' => 1,
			'registries' => [
				'default' => [
					'url' => $registry_url,
				],
			],
			'core' => [
				$id => [
					'package' => $package,
					'source' => [
						'type' => 'registry',
						'registry' => 'default',
						'version' => $version,
					],
				],
			],
		]);
	}

	private static function writeResolvedLockFromManifest(string $manifest_path, string $lock_path): void
	{
		$manifest = PackageManifest::loadFromPath($manifest_path);
		$method = new ReflectionMethod(PackageInstallService::class, 'buildNextLockState');
		$result = $method->invoke(null, $manifest, [
			'lockfile_version' => 1,
			'packages' => [],
		], dirname($lock_path), true);

		if (!is_array($result) || !isset($result['packages']) || !is_array($result['packages'])) {
			throw new RuntimeException('Unable to build resolved package lock fixture.');
		}

		PackageLockfile::write([
			'lockfile_version' => 1,
			'packages' => $result['packages'],
		], $lock_path);
	}

	/**
	 * @param array<string, mixed> $data
	 */
	private static function writeJson(string $path, array $data): void
	{
		self::mkdir(dirname($path));
		file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n");
	}

	/**
	 * @param array<string, mixed> $result
	 */
	private static function packageAction(array $result, string $package_key): string
	{
		foreach (($result['packages'] ?? []) as $package) {
			if (($package['package_key'] ?? null) === $package_key) {
				return (string) ($package['action'] ?? '');
			}
		}

		throw new RuntimeException("Package summary not found: {$package_key}");
	}

	private static function fileUrl(string $path): string
	{
		return 'file://' . str_replace('\\', '/', $path);
	}

	private static function deleteTree(string $path): void
	{
		if (!is_dir($path)) {
			return;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ($iterator as $item) {
			$item->isDir() ? rmdir($item->getPathname()) : unlink($item->getPathname());
		}

		rmdir($path);
	}
}
