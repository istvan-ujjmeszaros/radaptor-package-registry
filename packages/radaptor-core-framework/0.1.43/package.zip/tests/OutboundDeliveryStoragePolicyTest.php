<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../modules/OutboundDelivery/classes/class.OutboundDeliveryJob.php';
require_once __DIR__ . '/../modules/OutboundDelivery/classes/class.OutboundDeliveryStorage.php';

final class OutboundDeliveryStoragePolicyTest extends TestCase
{
	public function testRetryableFailureSchedulesRetryBeforeMaxAttempts(): void
	{
		$policy = OutboundDeliveryStorage::resolveFailurePolicy(1, true, 3);

		$this->assertSame(OutboundDeliveryStorage::FAIL_OUTCOME_RETRY_SCHEDULED, $policy['outcome']);
		$this->assertSame(2, $policy['delay_seconds']);
	}

	public function testRetryableFailureDeadLettersAtMaxAttempts(): void
	{
		$policy = OutboundDeliveryStorage::resolveFailurePolicy(3, true, 3);

		$this->assertSame(OutboundDeliveryStorage::FAIL_OUTCOME_TERMINAL_DEAD_LETTERED, $policy['outcome']);
		$this->assertNull($policy['delay_seconds']);
	}

	public function testNonRetryableFailureDeadLettersImmediately(): void
	{
		$policy = OutboundDeliveryStorage::resolveFailurePolicy(1, false, 5);

		$this->assertSame(OutboundDeliveryStorage::FAIL_OUTCOME_TERMINAL_DEAD_LETTERED, $policy['outcome']);
		$this->assertNull($policy['delay_seconds']);
	}
}
