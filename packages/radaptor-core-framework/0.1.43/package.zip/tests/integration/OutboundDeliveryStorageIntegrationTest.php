<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class OutboundDeliveryStorageIntegrationTest extends TestCase
{
	private static bool $_runtime_bootstrapped = false;
	private static ?int $_runtime_schema_token = null;

	private bool $_transaction_started = false;

	protected function setUp(): void
	{
		self::bootstrapConsumerRuntime();
		self::requireOutboundDeliveryFiles();
		self::installOutboundDeliveryTables();

		foreach ([
			Db::class,
			DbHelper::class,
			OutboundDeliveryJob::class,
			OutboundDeliveryStorage::class,
		] as $class_name) {
			if (!class_exists($class_name)) {
				self::markTestSkipped('The Radaptor consumer app runtime with outbound delivery storage is required.');
			}
		}

		$pdo = Db::instance();

		if (!$pdo->inTransaction()) {
			$pdo->beginTransaction();
			$this->_transaction_started = true;
		}
	}

	protected function tearDown(): void
	{
		if ($this->_transaction_started) {
			$pdo = Db::instance();

			if ($pdo->inTransaction()) {
				$pdo->rollBack();
			}
		}

		$this->_transaction_started = false;
	}

	public static function tearDownAfterClass(): void
	{
		if (self::$_runtime_schema_token !== null && class_exists(DbSchemaData::class, false)) {
			DbSchemaData::popRuntimeSchema(self::$_runtime_schema_token);
			self::$_runtime_schema_token = null;
		}
	}

	public function testCompleteArchivesAndRemovesReservedQueueRow(): void
	{
		$job_id = $this->enqueueAndReserveJob('complete');

		OutboundDeliveryStorage::complete($job_id, 204, 'accepted');

		$this->assertNull($this->fetchQueueRow($job_id));
		$archive = $this->fetchArchiveRow($job_id);
		$this->assertIsArray($archive);
		$this->assertSame(204, (int)$archive['http_status']);
		$this->assertSame('accepted', (string)$archive['response_body_preview']);
	}

	public function testRetryableFailureUpdatesReservedQueueRowByPrimaryKey(): void
	{
		$job_id = $this->enqueueAndReserveJob('retry');

		$outcome = OutboundDeliveryStorage::fail($job_id, 'HTTP_503', 'Temporarily unavailable', true, 503);

		$this->assertSame(OutboundDeliveryStorage::FAIL_OUTCOME_RETRY_SCHEDULED, $outcome);
		$row = $this->fetchQueueRow($job_id);
		$this->assertIsArray($row);
		$this->assertSame(OutboundDeliveryStorage::STATUS_RETRY_WAIT, (string)$row['status']);
		$this->assertSame(1, (int)$row['attempts']);
		$this->assertNull($row['reserved_at']);
		$this->assertSame(503, (int)$row['last_http_status']);
		$this->assertSame('HTTP_503', (string)$row['last_error_code']);
		$this->assertSame('Temporarily unavailable', (string)$row['last_error_message']);
	}

	public function testTerminalFailureDeadLettersAndRemovesReservedQueueRow(): void
	{
		$job_id = $this->enqueueAndReserveJob('terminal');

		$outcome = OutboundDeliveryStorage::fail($job_id, 'HTTP_400', 'Bad request', false, 400);

		$this->assertSame(OutboundDeliveryStorage::FAIL_OUTCOME_TERMINAL_DEAD_LETTERED, $outcome);
		$this->assertNull($this->fetchQueueRow($job_id));
		$dead_letter = $this->fetchDeadLetterRow($job_id);
		$this->assertIsArray($dead_letter);
		$this->assertSame(400, (int)$dead_letter['last_http_status']);
		$this->assertSame('HTTP_400', (string)$dead_letter['error_code']);
	}

	public function testWorkerAddsFrameworkIdempotencyHeader(): void
	{
		$job_id = 'outbound-test-worker-' . bin2hex(random_bytes(6));
		OutboundDeliveryStorage::enqueue(new OutboundDeliveryJob(
			$job_id,
			OutboundDeliveryJob::TYPE_HTTP_POST_JSON,
			'https://hooks.example.com/capture',
			['event' => 'phpunit.outbound_delivery', 'job_id' => $job_id],
			['X-Test' => '1'],
			'phpunit',
			null,
			null,
			3,
		));
		$client = new class () extends OutboundHttpJsonClient {
			/**
			 * @var list<array{url: string, payload: array<string, mixed>, headers: array<string, string>, framework_headers: array<string, string>}>
			 */
			public array $calls = [];

			public function postJson(string $url, array $payload, array $headers = [], array $framework_headers = []): OutboundHttpResponse
			{
				$this->calls[] = [
					'url' => $url,
					'payload' => $payload,
					'headers' => $headers,
					'framework_headers' => $framework_headers,
				];

				return new OutboundHttpResponse(204, '');
			}
		};

		$this->assertTrue(OutboundDeliveryWorker::runOnce('phpunit-worker', $client));
		$this->assertSame(1, count($client->calls));
		$this->assertSame('1', $client->calls[0]['headers']['X-Test']);
		$this->assertSame($job_id, $client->calls[0]['framework_headers'][OutboundHttpJsonClient::IDEMPOTENCY_HEADER]);
		$this->assertNull($this->fetchQueueRow($job_id));
		$this->assertIsArray($this->fetchArchiveRow($job_id));
	}

	private function enqueueAndReserveJob(string $suffix): string
	{
		$job_id = 'outbound-test-' . $suffix . '-' . bin2hex(random_bytes(6));
		OutboundDeliveryStorage::enqueue(new OutboundDeliveryJob(
			$job_id,
			'phpunit.outbound_delivery',
			'https://hooks.example.com/capture',
			['event' => 'phpunit.outbound_delivery', 'job_id' => $job_id],
			['X-Test' => '1'],
			'phpunit',
			null,
			null,
			3,
		));

		$row = OutboundDeliveryStorage::reserveNext();
		$this->assertIsArray($row);
		$this->assertSame($job_id, (string)$row['job_id']);
		$this->assertSame(OutboundDeliveryStorage::STATUS_RESERVED, (string)$row['status']);

		return $job_id;
	}

	/**
	 * @return array<string, mixed>|null
	 */
	private function fetchQueueRow(string $job_id): ?array
	{
		return $this->fetchOne(OutboundDeliveryStorage::TABLE_QUEUE, $job_id);
	}

	/**
	 * @return array<string, mixed>|null
	 */
	private function fetchArchiveRow(string $job_id): ?array
	{
		return $this->fetchOne(OutboundDeliveryStorage::TABLE_ARCHIVE, $job_id);
	}

	/**
	 * @return array<string, mixed>|null
	 */
	private function fetchDeadLetterRow(string $job_id): ?array
	{
		return $this->fetchOne(OutboundDeliveryStorage::TABLE_DEAD_LETTER, $job_id);
	}

	/**
	 * @return array<string, mixed>|null
	 */
	private function fetchOne(string $table, string $job_id): ?array
	{
		$stmt = Db::instance()->prepare("SELECT * FROM `{$table}` WHERE job_id = ? LIMIT 1");
		$stmt->execute([$job_id]);
		$row = $stmt->fetch(PDO::FETCH_ASSOC);

		return is_array($row) ? $row : null;
	}

	private static function installOutboundDeliveryTables(): void
	{
		(new Migration_20260529_090000_add_outbound_delivery_queue())->run();

		if (self::$_runtime_schema_token === null) {
			self::$_runtime_schema_token = DbSchemaData::pushRuntimeSchema(
				DbSchemaDataBuilder::buildSchemaArray([Db::normalizeDsn()])
			);
		}
	}

	private static function requireOutboundDeliveryFiles(): void
	{
		$root = dirname(__DIR__, 2);

		foreach ([
			'migrations/20260529_090000_add_outbound_delivery_queue.php',
			'modules/OutboundDelivery/classes/class.OutboundDeliveryException.php',
			'modules/OutboundDelivery/classes/class.OutboundHttpResponse.php',
			'modules/OutboundDelivery/classes/class.OutboundDeliveryJob.php',
			'modules/OutboundDelivery/classes/class.OutboundHttpJsonClient.php',
			'modules/OutboundDelivery/classes/class.OutboundDeliveryStorage.php',
			'modules/OutboundDelivery/classes/class.OutboundDeliveryWorker.php',
		] as $relative_path) {
			$path = $root . '/' . $relative_path;

			if (!is_file($path)) {
				self::markTestSkipped("Missing outbound delivery file: {$relative_path}");
			}

			require_once $path;
		}
	}

	private static function bootstrapConsumerRuntime(): void
	{
		if (self::$_runtime_bootstrapped || class_exists('Db', autoload: false)) {
			self::$_runtime_bootstrapped = true;

			return;
		}

		$bootstrap = getenv('RADAPTOR_APP_TEST_BOOTSTRAP') ?: '/app/bootstrap/bootstrap.testing.php';

		if (!is_file($bootstrap)) {
			self::markTestSkipped('Set RADAPTOR_APP_TEST_BOOTSTRAP or run from the Radaptor app container to execute outbound delivery storage integration tests.');
		}

		require_once $bootstrap;
		restore_error_handler();
		restore_exception_handler();

		self::$_runtime_bootstrapped = true;
	}
}
