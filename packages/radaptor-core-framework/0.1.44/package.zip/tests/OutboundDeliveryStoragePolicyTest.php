<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../modules/OutboundDelivery/classes/class.OutboundDeliveryJob.php';
require_once __DIR__ . '/../modules/OutboundDelivery/classes/class.OutboundDeliveryStorage.php';

final class OutboundDeliveryStoragePolicyTest extends TestCase
{
	public function testRetryableFailureSchedulesRetryBeforeMaxAttempts(): void
	{
		$policy = OutboundDeliveryStorage::resolveFailurePolicy(1, true, 3);

		$this->assertSame(OutboundDeliveryStorage::FAIL_OUTCOME_RETRY_SCHEDULED, $policy['outcome']);
		$this->assertSame(2, $policy['delay_seconds']);
	}

	public function testRetryDelayJitterIsDeterministicAndBounded(): void
	{
		$method = new ReflectionMethod(OutboundDeliveryStorage::class, 'getRetryDelaySeconds');
		$method->setAccessible(true);

		$base_delay = $method->invoke(null, 1);
		$jittered_delay = $method->invoke(null, 1, 'outbound-test-jitter');

		$this->assertSame(2, $base_delay);
		$this->assertSame($jittered_delay, $method->invoke(null, 1, 'outbound-test-jitter'));
		$this->assertGreaterThanOrEqual($base_delay, $jittered_delay);
		$this->assertLessThanOrEqual(4, $jittered_delay);
		$this->assertSame(3600, $method->invoke(null, 20, 'outbound-test-jitter'));
	}

	public function testRetryableFailureDeadLettersAtMaxAttempts(): void
	{
		$policy = OutboundDeliveryStorage::resolveFailurePolicy(3, true, 3);

		$this->assertSame(OutboundDeliveryStorage::FAIL_OUTCOME_TERMINAL_DEAD_LETTERED, $policy['outcome']);
		$this->assertNull($policy['delay_seconds']);
	}

	public function testNonRetryableFailureDeadLettersImmediately(): void
	{
		$policy = OutboundDeliveryStorage::resolveFailurePolicy(1, false, 5);

		$this->assertSame(OutboundDeliveryStorage::FAIL_OUTCOME_TERMINAL_DEAD_LETTERED, $policy['outcome']);
		$this->assertNull($policy['delay_seconds']);
	}
}
