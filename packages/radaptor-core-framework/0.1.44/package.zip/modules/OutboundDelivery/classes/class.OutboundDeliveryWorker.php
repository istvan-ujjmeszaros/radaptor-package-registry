<?php

declare(strict_types=1);

class OutboundDeliveryWorker
{
	public const string WORKER_TYPE = 'outbound_delivery';
	public const string QUEUE_NAME = 'http_webhook';
	public const string IDEMPOTENCY_HEADER = OutboundHttpJsonClient::IDEMPOTENCY_HEADER;

	private const int WORKER_SLEEP_MS = 500;
	private const int PURGE_INTERVAL_SECONDS = 300;

	private static ?string $workerInstanceId = null;

	public static function getStaleAfterSeconds(): int
	{
		return max(15, (int) ceil(self::WORKER_SLEEP_MS / 1000) * 20);
	}

	public static function runForever(?OutboundHttpJsonClient $client = null): void
	{
		$next_purge_at = time() + self::PURGE_INTERVAL_SECONDS;

		self::ensureWorkerRegistered();

		try {
			for (;;) {
				$processed = self::runOnce(self::$workerInstanceId, $client);

				if (RuntimeWorkerPauseControl::getActivePauseRequest(self::WORKER_TYPE, self::QUEUE_NAME) !== null) {
					usleep(self::WORKER_SLEEP_MS * 1000);

					continue;
				}

				if (time() >= $next_purge_at) {
					OutboundDeliveryStorage::purgeArchives();
					$next_purge_at = time() + self::PURGE_INTERVAL_SECONDS;
				}

				if (!$processed) {
					usleep(self::WORKER_SLEEP_MS * 1000);
				}
			}
		} finally {
			RuntimeWorkerRegistry::markStopping(self::$workerInstanceId, self::WORKER_TYPE, self::QUEUE_NAME);
		}
	}

	public static function runOnce(?string $worker_instance_id = null, ?OutboundHttpJsonClient $client = null): bool
	{
		$registered_here = false;
		$paused = false;

		if ($worker_instance_id === null) {
			self::ensureWorkerRegistered();
			$worker_instance_id = self::$workerInstanceId;
			$registered_here = $worker_instance_id !== null;
		}

		Cache::flush();

		try {
			if (RuntimeWorkerPauseControl::pauseIfRequested($worker_instance_id, self::WORKER_TYPE, self::QUEUE_NAME)) {
				$paused = true;

				return false;
			}

			RuntimeWorkerRegistry::heartbeat(
				$worker_instance_id,
				self::WORKER_TYPE,
				self::QUEUE_NAME,
				RuntimeWorkerRegistry::STATE_IDLE
			);

			$row = OutboundDeliveryStorage::reserveNext();

			if (!is_array($row)) {
				return false;
			}

			$job_id = (string) ($row['job_id'] ?? '');
			$job_type = (string) ($row['job_type'] ?? '');

			if ($job_id === '') {
				return false;
			}

			RuntimeWorkerRegistry::heartbeat(
				$worker_instance_id,
				self::WORKER_TYPE,
				self::QUEUE_NAME,
				RuntimeWorkerRegistry::STATE_BUSY,
				$job_id,
				$job_type
			);

			try {
				$response = self::processJob($row, $client ?? new OutboundHttpJsonClient());
			} catch (OutboundDeliveryException $e) {
				OutboundDeliveryStorage::fail(
					$job_id,
					$e->getErrorCodeString(),
					$e->getMessage(),
					$e->isRetryable(),
					$e->getHttpStatusCode()
				);

				return true;
			} catch (Throwable $e) {
				OutboundDeliveryStorage::fail($job_id, 'EXECUTION_ERROR', $e->getMessage(), true);

				return true;
			}

			OutboundDeliveryStorage::complete($job_id, $response->statusCode, $response->bodyPreview());

			return true;
		} finally {
			if ($registered_here) {
				RuntimeWorkerRegistry::markStopping($worker_instance_id, self::WORKER_TYPE, self::QUEUE_NAME);
				self::$workerInstanceId = null;
			} elseif (!$paused) {
				RuntimeWorkerRegistry::heartbeat(
					$worker_instance_id,
					self::WORKER_TYPE,
					self::QUEUE_NAME,
					RuntimeWorkerRegistry::STATE_IDLE
				);
			}
		}
	}

	private static function ensureWorkerRegistered(): void
	{
		if (self::$workerInstanceId !== null) {
			return;
		}

		self::$workerInstanceId = RuntimeWorkerRegistry::register(self::WORKER_TYPE, self::QUEUE_NAME, [
			'command' => 'outbounddelivery:run',
		]);
	}

	/**
	 * @param array<string, mixed> $row
	 */
	private static function processJob(array $row, OutboundHttpJsonClient $client): OutboundHttpResponse
	{
		$job_type = (string) ($row['job_type'] ?? '');

		if ($job_type !== OutboundDeliveryJob::TYPE_HTTP_POST_JSON) {
			throw new OutboundDeliveryException('UNKNOWN_JOB_TYPE', 'Unsupported outbound delivery job type: ' . $job_type, false);
		}

		$target_url = trim((string) ($row['target_url'] ?? ''));
		$payload = json_decode((string) ($row['payload_json'] ?? ''), true);
		$headers = self::decodeHeaders($row['headers_json'] ?? null);
		$job_id = (string) ($row['job_id'] ?? '');

		if (!is_array($payload)) {
			throw new OutboundDeliveryException('INVALID_PAYLOAD', 'Invalid outbound delivery payload JSON.', false);
		}

		$framework_headers = $job_id !== '' ? [self::IDEMPOTENCY_HEADER => $job_id] : [];
		$response = $client->postJson($target_url, $payload, $headers, $framework_headers);

		if (!$response->isSuccessful()) {
			throw new OutboundDeliveryException(
				'HTTP_UNEXPECTED_STATUS',
				'Outbound delivery endpoint returned HTTP status ' . $response->statusCode . '.',
				self::isRetryableHttpStatus($response->statusCode),
				$response->statusCode
			);
		}

		return $response;
	}

	/**
	 * @return array<string, string>
	 */
	private static function decodeHeaders(mixed $headers_json): array
	{
		if (!is_string($headers_json) || trim($headers_json) === '') {
			return [];
		}

		$decoded = json_decode($headers_json, true);

		if (!is_array($decoded)) {
			throw new OutboundDeliveryException('INVALID_HEADERS', 'Invalid outbound delivery headers JSON.', false);
		}

		$headers = [];

		foreach ($decoded as $name => $value) {
			if (!is_string($name) || (!is_string($value) && !is_numeric($value))) {
				throw new OutboundDeliveryException('INVALID_HEADERS', 'Outbound delivery headers must be a string map.', false);
			}

			$headers[$name] = (string) $value;
		}

		return $headers;
	}

	private static function isRetryableHttpStatus(int $status_code): bool
	{
		return in_array($status_code, [408, 425, 429], true) || ($status_code >= 500 && $status_code <= 599);
	}
}
