<?php

class MailHandler
{
	/**
	 * Legacy email bridge.
	 *
	 * @param string $body The body of the email message
	 * @param string $subject The subject of the email (default: "-- új üzenet a weboldalról --")
	 * @param array<string> $cc_array Legacy additional recipient list
	 * @return bool Returns true when the email was queued successfully, false otherwise
	 */
	public static function sendMail(string $body, string $subject = "-- új üzenet a weboldalról --", array $cc_array = []): bool
	{
		$recipients = self::buildRecipients($cc_array);

		if ($recipients === [] || !class_exists(EmailOrchestrator::class)) {
			return false;
		}

		try {
			EmailOrchestrator::enqueueTransactionalSnapshotAsSystem(
				subject: $subject,
				htmlBody: $body,
				textBody: trim(strip_tags($body)),
				recipients: $recipients,
			);

			return true;
		} catch (Throwable $exception) {
			if (class_exists(Kernel::class)) {
				Kernel::logException($exception, 'MailHandler email bridge enqueue failed');
			} else {
				error_log('MailHandler email bridge enqueue failed: ' . $exception->getMessage());
			}

			return false;
		}
	}

	/**
	 * @param array<string> $additional_recipients
	 * @return list<array{email: string}>
	 */
	private static function buildRecipients(array $additional_recipients): array
	{
		$recipient_values = [];
		$default_recipient = self::getLegacyDefaultRecipient();

		if ($default_recipient !== '') {
			$recipient_values[] = $default_recipient;
		}

		foreach ($additional_recipients as $recipient) {
			$recipient_values[] = (string) $recipient;
		}

		$recipients = [];

		foreach ($recipient_values as $recipient) {
			$recipient = trim($recipient);

			if ($recipient === '' || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
				continue;
			}

			$recipients[] = ['email' => $recipient];
		}

		return $recipients;
	}

	private static function getLegacyDefaultRecipient(): string
	{
		if (defined(Config::class . '::EMAIL_TO_ADDRESS')) {
			$config_case = constant(Config::class . '::EMAIL_TO_ADDRESS');

			if (is_object($config_case) && method_exists($config_case, 'value')) {
				return trim((string) $config_case->value());
			}
		}

		if (defined(ApplicationConfig::class . '::EMAIL_TO_ADDRESS')) {
			return trim((string) constant(ApplicationConfig::class . '::EMAIL_TO_ADDRESS'));
		}

		return '';
	}
}
