<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class RuntimeWorkerHandlerRegistryTest extends TestCase
{
	public function testParseScopeListTrimsMultipleScopes(): void
	{
		$this->assertSame(
			[
				[
					'worker_type' => 'email_queue',
					'queue_name' => 'transactional_email',
				],
				[
					'worker_type' => 'outbound_delivery',
					'queue_name' => 'http_webhook',
				],
			],
			RuntimeWorkerHandlerRegistry::parseScopeList(' email_queue:transactional_email, outbound_delivery:http_webhook ')
		);
	}

	public function testParseScopeListRejectsMalformedScope(): void
	{
		$this->expectException(InvalidArgumentException::class);

		RuntimeWorkerHandlerRegistry::parseScopeList('email_queue');
	}

	public function testParseScopeListRejectsEmptyScopeList(): void
	{
		$this->expectException(InvalidArgumentException::class);

		RuntimeWorkerHandlerRegistry::parseScopeList(' , ');
	}
}
