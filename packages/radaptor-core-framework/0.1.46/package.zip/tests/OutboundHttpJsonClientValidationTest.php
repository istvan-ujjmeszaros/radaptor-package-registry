<?php

declare(strict_types=1);

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../modules/OutboundDelivery/classes/class.OutboundDeliveryException.php';
require_once __DIR__ . '/../modules/OutboundDelivery/classes/class.OutboundHttpResponse.php';
require_once __DIR__ . '/../modules/OutboundDelivery/classes/class.OutboundHttpJsonClient.php';

final class OutboundHttpJsonClientValidationTest extends TestCase
{
	public function testAllowsHttpsPublicIpLiteral(): void
	{
		$endpoint = OutboundHttpJsonClient::validateUrlForDelivery('https://8.8.8.8/webhook', false);

		$this->assertSame('8.8.8.8', $endpoint['host']);
		$this->assertSame(['8.8.8.8'], $endpoint['resolved_ips']);
		$this->assertSame('8.8.8.8:443:8.8.8.8', $endpoint['curl_resolve']);
	}

	public function testAllowsHttpsPublicIpv6Literal(): void
	{
		$endpoint = OutboundHttpJsonClient::validateUrlForDelivery('https://[2001:4860:4860::8888]/webhook', false);

		$this->assertSame('2001:4860:4860::8888', $endpoint['host']);
		$this->assertSame(['2001:4860:4860::8888'], $endpoint['resolved_ips']);
		$this->assertSame('[2001:4860:4860::8888]:443:[2001:4860:4860::8888]', $endpoint['curl_resolve']);
	}

	public function testRejectsNonHttpsScheme(): void
	{
		$this->expectException(OutboundDeliveryException::class);
		$this->expectExceptionMessage('must use https');

		OutboundHttpJsonClient::validateUrlForDelivery('http://example.com/webhook', false);
	}

	public function testRejectsLeadingOrTrailingWhitespace(): void
	{
		$this->expectException(OutboundDeliveryException::class);
		$this->expectExceptionMessage('must not contain leading or trailing whitespace');

		OutboundHttpJsonClient::validateUrlForDelivery(' https://example.com/webhook', false);
	}

	public function testRejectsLocalhostName(): void
	{
		$this->expectException(OutboundDeliveryException::class);

		OutboundHttpJsonClient::validateUrlForDelivery('https://localhost/webhook', false);
	}

	public function testRejectsTrailingDotHostname(): void
	{
		$this->expectException(OutboundDeliveryException::class);
		$this->expectExceptionMessage('must not end with a dot');

		OutboundHttpJsonClient::validateUrlForDelivery('https://example.com./webhook', false);
	}

	#[DataProvider('blockedIpProvider')]
	public function testRejectsPrivateLocalLinkLocalAndReservedIpLiterals(string $url): void
	{
		$this->expectException(OutboundDeliveryException::class);
		$this->expectExceptionMessage('private, local, or reserved');

		OutboundHttpJsonClient::validateUrlForDelivery($url, false);
	}

	/**
	 * @return list<array{string}>
	 */
	public static function blockedIpProvider(): array
	{
		return [
			['https://127.0.0.1/webhook'],
			['https://10.0.0.1/webhook'],
			['https://169.254.1.1/webhook'],
			['https://192.0.2.1/webhook'],
			['https://[::1]/webhook'],
			['https://[fc00::1]/webhook'],
		];
	}

	public function testRejectsNumericHostThatIsNotCanonicalIpLiteral(): void
	{
		$this->expectException(OutboundDeliveryException::class);

		OutboundHttpJsonClient::validateUrlForDelivery('https://127.1/webhook', false);
	}

	public function testResponseBodyWriteCallbackStopsAtPreviewLimit(): void
	{
		$client = new OutboundHttpJsonClient(10, 3, 'phpunit', 5);
		$body = '';
		$limit_reached = false;
		$method = new ReflectionMethod(OutboundHttpJsonClient::class, 'responseBodyWriteFunction');
		$callback = $method->invokeArgs($client, [&$body, &$limit_reached]);

		$this->assertIsCallable($callback);
		$this->assertSame(3, $callback(null, 'abc'));
		$this->assertSame(0, $callback(null, 'def'));
		$this->assertSame('abcde', $body);
		$this->assertTrue($limit_reached);
	}

	public function testRejectsCallerSuppliedFrameworkIdempotencyHeader(): void
	{
		$client = new OutboundHttpJsonClient();
		$method = new ReflectionMethod(OutboundHttpJsonClient::class, 'buildCurlHeaders');

		$this->expectException(OutboundDeliveryException::class);
		$this->expectExceptionMessage('controlled by the framework');

		$method->invoke($client, [OutboundHttpJsonClient::IDEMPOTENCY_HEADER => 'external']);
	}
}
