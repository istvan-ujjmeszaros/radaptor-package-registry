<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class MailHandlerTest extends TestCase
{
	public function testBuildRecipientsFiltersInvalidAdditionalRecipients(): void
	{
		$method = new ReflectionMethod(MailHandler::class, 'buildRecipients');
		$recipients = $method->invoke(null, [
			'first@example.com',
			'not-an-email',
			' second@example.com ',
			'',
		]);

		$this->assertContains(['email' => 'first@example.com'], $recipients);
		$this->assertContains(['email' => 'second@example.com'], $recipients);
		$this->assertNotContains(['email' => 'not-an-email'], $recipients);
	}
}
