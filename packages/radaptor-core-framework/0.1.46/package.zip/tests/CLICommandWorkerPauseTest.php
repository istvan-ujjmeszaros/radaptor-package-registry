<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class CLICommandWorkerPauseTest extends TestCase
{
	public function testStaleThresholdComesFromRuntimeWorkerRegistry(): void
	{
		$command = new CLICommandWorkerPause();
		$method = new ReflectionMethod(CLICommandWorkerPause::class, 'resolveStaleAfterSeconds');

		$this->assertSame(
			OutboundDeliveryWorker::getStaleAfterSeconds(),
			$method->invoke($command, OutboundDeliveryWorker::WORKER_TYPE, OutboundDeliveryWorker::QUEUE_NAME)
		);
	}

	public function testUnknownWorkerScopeFallsBackToDefaultStaleThreshold(): void
	{
		$command = new CLICommandWorkerPause();
		$method = new ReflectionMethod(CLICommandWorkerPause::class, 'resolveStaleAfterSeconds');

		$this->assertSame(30, $method->invoke($command, 'unknown_worker', 'unknown_queue'));
	}
}
