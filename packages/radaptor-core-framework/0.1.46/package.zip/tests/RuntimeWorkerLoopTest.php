<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../modules/Worker/interfaces/interface.iRuntimeWorkerHandler.php';
require_once __DIR__ . '/../modules/Worker/classes/class.RuntimeWorkerLoop.php';

final class RuntimeWorkerLoopTest extends TestCase
{
	public function testRunPassPollsEveryHandlerAndReportsProcessedWork(): void
	{
		$first = new RuntimeWorkerLoopTestHandler('first', 'queue', false);
		$second = new RuntimeWorkerLoopTestHandler('second', 'queue', true);
		$next_purge_at = [
			'first/queue' => 100,
			'second/queue' => 100,
		];

		$processed = RuntimeWorkerLoop::runPass(
			[$first, $second],
			[
				'first/queue' => 'worker-first',
				'second/queue' => 'worker-second',
			],
			$next_purge_at,
			10
		);

		$this->assertTrue($processed);
		$this->assertSame(['worker-first'], $first->workerInstanceIds);
		$this->assertSame(['worker-second'], $second->workerInstanceIds);
		$this->assertSame(0, $first->purgeCount);
		$this->assertSame(0, $second->purgeCount);
	}

	public function testRunPassPurgesDueHandlersAndSchedulesNextPurge(): void
	{
		$handler = new RuntimeWorkerLoopTestHandler('worker', 'queue', false, 30);
		$next_purge_at = [
			'worker/queue' => 10,
		];

		$processed = RuntimeWorkerLoop::runPass(
			[$handler],
			['worker/queue' => 'worker-id'],
			$next_purge_at,
			20
		);

		$this->assertFalse($processed);
		$this->assertSame(1, $handler->purgeCount);
		$this->assertSame(50, $next_purge_at['worker/queue']);
	}

	public function testRunPassDoesNotPurgePausedHandlers(): void
	{
		$handler = new RuntimeWorkerLoopTestHandler('worker', 'queue', false, 30);
		$next_purge_at = [
			'worker/queue' => 10,
		];

		$processed = RuntimeWorkerLoop::runPass(
			[$handler],
			['worker/queue' => 'worker-id'],
			$next_purge_at,
			20,
			static fn (iRuntimeWorkerHandler $handler): bool => $handler->getWorkerType() === 'worker'
		);

		$this->assertFalse($processed);
		$this->assertSame(['worker-id'], $handler->workerInstanceIds);
		$this->assertSame(0, $handler->purgeCount);
		$this->assertSame(10, $next_purge_at['worker/queue']);
	}
}

final class RuntimeWorkerLoopTestHandler implements iRuntimeWorkerHandler
{
	/**
	 * @var list<string|null>
	 */
	public array $workerInstanceIds = [];
	public int $purgeCount = 0;

	public function __construct(
		private readonly string $_workerType,
		private readonly string $_queueName,
		private readonly bool $_processed,
		private readonly int $_purgeIntervalSeconds = 60,
	) {
	}

	public function getWorkerType(): string
	{
		return $this->_workerType;
	}

	public function getQueueName(): string
	{
		return $this->_queueName;
	}

	public function getSleepMilliseconds(): int
	{
		return 10;
	}

	public function getStaleAfterSeconds(): int
	{
		return 30;
	}

	public function getPurgeIntervalSeconds(): int
	{
		return $this->_purgeIntervalSeconds;
	}

	public function getMetadata(): array
	{
		return [];
	}

	public function runOnce(?string $worker_instance_id = null): bool
	{
		$this->workerInstanceIds[] = $worker_instance_id;

		return $this->_processed;
	}

	public function purgeArchives(): void
	{
		++$this->purgeCount;
	}
}
