<?php

declare(strict_types=1);

class EmailQueueRuntimeWorkerHandler implements iRuntimeWorkerHandler
{
	public function getWorkerType(): string
	{
		return EmailQueueWorker::WORKER_TYPE;
	}

	public function getQueueName(): string
	{
		return EmailQueueWorker::QUEUE_NAME;
	}

	public function getSleepMilliseconds(): int
	{
		return EmailQueueWorker::getWorkerSleepMilliseconds();
	}

	public function getStaleAfterSeconds(): int
	{
		return EmailQueueWorker::getStaleAfterSeconds();
	}

	public function getPurgeIntervalSeconds(): int
	{
		return EmailQueueWorker::getPurgeIntervalSeconds();
	}

	public function getMetadata(): array
	{
		return [
			'handler_class' => self::class,
			'queue_family' => 'email',
		];
	}

	public function runOnce(?string $worker_instance_id = null): bool
	{
		return EmailQueueWorker::runOnce($worker_instance_id);
	}

	public function purgeArchives(): void
	{
		EmailQueueStorage::purgeArchives();
	}
}
