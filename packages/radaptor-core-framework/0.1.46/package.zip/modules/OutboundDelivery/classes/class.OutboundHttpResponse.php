<?php

declare(strict_types=1);

class OutboundHttpResponse
{
	public function __construct(
		public int $statusCode,
		public string $body,
	) {
	}

	public function isSuccessful(): bool
	{
		return $this->statusCode >= 200 && $this->statusCode <= 299;
	}

	public function bodyPreview(int $max_bytes = 2048): string
	{
		return substr($this->body, 0, max(0, $max_bytes));
	}
}
