<?php

declare(strict_types=1);

class OutboundDeliveryException extends RuntimeException
{
	private string $_errorCode;
	private bool $_retryable;
	private ?int $_httpStatusCode;

	public function __construct(
		string $error_code,
		string $message,
		bool $retryable = false,
		?int $http_status_code = null,
		?Throwable $previous = null
	) {
		parent::__construct($message, 0, $previous);
		$this->_errorCode = $error_code;
		$this->_retryable = $retryable;
		$this->_httpStatusCode = $http_status_code;
	}

	public function getErrorCodeString(): string
	{
		return $this->_errorCode;
	}

	public function isRetryable(): bool
	{
		return $this->_retryable;
	}

	public function getHttpStatusCode(): ?int
	{
		return $this->_httpStatusCode;
	}
}
