<?php

declare(strict_types=1);

class OutboundDeliveryStorage
{
	public const string TABLE_QUEUE = 'outbound_delivery_queue';
	public const string TABLE_ARCHIVE = 'outbound_delivery_archive';
	public const string TABLE_DEAD_LETTER = 'outbound_delivery_dead_letter';

	public const string STATUS_PENDING = 'pending';
	public const string STATUS_RETRY_WAIT = 'retry_wait';
	public const string STATUS_RESERVED = 'reserved';

	public const string FAIL_OUTCOME_RETRY_SCHEDULED = 'retry_scheduled';
	public const string FAIL_OUTCOME_TERMINAL_DEAD_LETTERED = 'terminal_dead_lettered';

	private const int DEFAULT_RESERVATION_TIMEOUT_SECONDS = 300;
	private const int DEFAULT_ARCHIVE_TTL_DAYS = 30;
	private const int DEFAULT_DEAD_LETTER_TTL_DAYS = 180;

	public static function enqueue(OutboundDeliveryJob $job): void
	{
		OutboundHttpJsonClient::validateUrlForDelivery($job->targetUrl, false);
		$payload_json = self::encodeJson($job->payload);

		if (strlen($payload_json) > OutboundDeliveryJob::MAX_PAYLOAD_BYTES) {
			throw new OutboundDeliveryException(
				'PAYLOAD_TOO_LARGE',
				'Outbound delivery payload exceeds the maximum allowed size.',
				false,
			);
		}

		$result = DbHelper::insertHelper(self::TABLE_QUEUE, [
			'job_id' => $job->jobId,
			'job_type' => $job->jobType,
			'target_url' => $job->targetUrl,
			'headers_json' => $job->headers === [] ? null : self::encodeJson($job->headers),
			'payload_json' => $payload_json,
			'requested_by_type' => $job->requestedByType,
			'requested_by_id' => $job->requestedById,
			'status' => self::STATUS_PENDING,
			'max_attempts' => max(1, $job->maxAttempts),
			'run_after_utc' => $job->runAfterUtc ?? date('Y-m-d H:i:s'),
		]);

		if (!is_int($result) || $result <= 0) {
			throw new RuntimeException('Unable to enqueue outbound delivery job.');
		}
	}

	/**
	 * @return array<string, mixed>|null
	 */
	public static function reserveNext(): ?array
	{
		$pdo = Db::instance();
		$reservation_timeout_seconds = self::DEFAULT_RESERVATION_TIMEOUT_SECONDS;

		for ($attempt = 0; $attempt < 4; ++$attempt) {
			$query = "SELECT job_id
				FROM `" . self::TABLE_QUEUE . "`
				WHERE (
					status IN ('" . self::STATUS_PENDING . "', '" . self::STATUS_RETRY_WAIT . "')
					AND run_after_utc <= NOW()
				)
				OR (
					status = '" . self::STATUS_RESERVED . "'
					AND reserved_at IS NOT NULL
					AND reserved_at < (NOW() - INTERVAL {$reservation_timeout_seconds} SECOND)
				)
				ORDER BY run_after_utc ASC, queue_id ASC
				LIMIT 1";

			$select_stmt = $pdo->prepare($query);
			$select_stmt->execute();
			$row = $select_stmt->fetch(PDO::FETCH_ASSOC);

			if (!is_array($row)) {
				return null;
			}

			$job_id = (string) $row['job_id'];
			$update_stmt = $pdo->prepare(
				"UPDATE `" . self::TABLE_QUEUE . "`
				SET status = :status, reserved_at = NOW(), attempts = attempts + 1
				WHERE job_id = :job_id
				AND (
					status IN ('" . self::STATUS_PENDING . "', '" . self::STATUS_RETRY_WAIT . "')
					OR (
						status = '" . self::STATUS_RESERVED . "'
						AND reserved_at IS NOT NULL
						AND reserved_at < (NOW() - INTERVAL {$reservation_timeout_seconds} SECOND)
					)
				)"
			);
			$update_stmt->execute([
				':status' => self::STATUS_RESERVED,
				':job_id' => $job_id,
			]);

			if ($update_stmt->rowCount() !== 1) {
				continue;
			}

			$fetch_stmt = $pdo->prepare("SELECT * FROM `" . self::TABLE_QUEUE . "` WHERE job_id = :job_id LIMIT 1");
			$fetch_stmt->execute([':job_id' => $job_id]);
			$reserved = $fetch_stmt->fetch(PDO::FETCH_ASSOC);

			return is_array($reserved) ? $reserved : null;
		}

		return null;
	}

	public static function complete(string $job_id, ?int $http_status = null, ?string $response_body_preview = null): void
	{
		$pdo = Db::instance();
		$started_transaction = !$pdo->inTransaction();

		try {
			if ($started_transaction) {
				$pdo->beginTransaction();
			}

			$row = self::selectQueueRowForMutation($job_id);

			if (!is_array($row)) {
				if ($started_transaction) {
					$pdo->commit();
				}

				return;
			}

			$queue_id = self::queueIdFromRow($row);

			$result = DbHelper::insertHelper(self::TABLE_ARCHIVE, [
				'job_id' => $row['job_id'],
				'job_type' => $row['job_type'],
				'target_url' => $row['target_url'],
				'headers_json' => $row['headers_json'],
				'payload_json' => $row['payload_json'],
				'requested_by_type' => $row['requested_by_type'],
				'requested_by_id' => $row['requested_by_id'],
				'attempts' => $row['attempts'],
				'http_status' => $http_status,
				'response_body_preview' => $response_body_preview,
				'completed_at' => date('Y-m-d H:i:s'),
				'created_at' => $row['created_at'],
			]);

			if (!is_int($result) || $result <= 0) {
				throw new RuntimeException('Unable to archive completed outbound delivery job.');
			}

			if (!DbHelper::deleteHelper(self::TABLE_QUEUE, ['queue_id' => $queue_id])) {
				throw new RuntimeException('Unable to remove completed outbound delivery job from queue.');
			}

			if ($started_transaction) {
				$pdo->commit();
			}
		} catch (Throwable $e) {
			if ($started_transaction && $pdo->inTransaction()) {
				$pdo->rollBack();
			}

			throw $e;
		}
	}

	public static function fail(string $job_id, string $error_code, string $error_message, bool $retryable, ?int $http_status = null): string
	{
		$pdo = Db::instance();
		$started_transaction = !$pdo->inTransaction();

		try {
			if ($started_transaction) {
				$pdo->beginTransaction();
			}

			$row = self::selectQueueRowForMutation($job_id);

			if (!is_array($row)) {
				if ($started_transaction) {
					$pdo->commit();
				}

				return self::FAIL_OUTCOME_TERMINAL_DEAD_LETTERED;
			}

			$queue_id = self::queueIdFromRow($row);
			$attempts = (int) ($row['attempts'] ?? 0);
			$max_attempts = max(1, (int) ($row['max_attempts'] ?? OutboundDeliveryJob::DEFAULT_MAX_ATTEMPTS));
			$policy = self::resolveFailurePolicy($attempts, $retryable, $max_attempts);

			if ($policy['outcome'] === self::FAIL_OUTCOME_RETRY_SCHEDULED) {
				$updated = DbHelper::updateHelper(self::TABLE_QUEUE, [
					'status' => self::STATUS_RETRY_WAIT,
					'run_after_utc' => date('Y-m-d H:i:s', time() + self::getRetryDelaySeconds($attempts, (string) $row['job_id'])),
					'reserved_at' => null,
					'last_http_status' => $http_status,
					'last_error_code' => $error_code,
					'last_error_message' => $error_message,
				], [
					'queue_id' => $queue_id,
				]);

				if ($updated !== 1) {
					throw new RuntimeException('Unable to schedule retry for outbound delivery job.');
				}

				if ($started_transaction) {
					$pdo->commit();
				}

				return self::FAIL_OUTCOME_RETRY_SCHEDULED;
			}

			$result = DbHelper::insertHelper(self::TABLE_DEAD_LETTER, [
				'job_id' => $row['job_id'],
				'job_type' => $row['job_type'],
				'target_url' => $row['target_url'],
				'headers_json' => $row['headers_json'],
				'payload_json' => $row['payload_json'],
				'requested_by_type' => $row['requested_by_type'],
				'requested_by_id' => $row['requested_by_id'],
				'attempts' => $row['attempts'],
				'last_http_status' => $http_status,
				'error_code' => $error_code,
				'error_message' => $error_message,
				'created_at' => $row['created_at'],
			]);

			if (!is_int($result) || $result <= 0) {
				throw new RuntimeException('Unable to archive dead-letter outbound delivery job.');
			}

			if (!DbHelper::deleteHelper(self::TABLE_QUEUE, ['queue_id' => $queue_id])) {
				throw new RuntimeException('Unable to remove dead-lettered outbound delivery job from queue.');
			}

			if ($started_transaction) {
				$pdo->commit();
			}

			return self::FAIL_OUTCOME_TERMINAL_DEAD_LETTERED;
		} catch (Throwable $e) {
			if ($started_transaction && $pdo->inTransaction()) {
				$pdo->rollBack();
			}

			throw $e;
		}
	}

	public static function purgeArchives(): void
	{
		$archive_ttl_days = self::DEFAULT_ARCHIVE_TTL_DAYS;
		$dead_ttl_days = self::DEFAULT_DEAD_LETTER_TTL_DAYS;

		Db::instance()->exec("DELETE FROM `" . self::TABLE_ARCHIVE . "` WHERE archived_at < DATE_SUB(NOW(), INTERVAL {$archive_ttl_days} DAY)");
		Db::instance()->exec("DELETE FROM `" . self::TABLE_DEAD_LETTER . "` WHERE dead_lettered_at < DATE_SUB(NOW(), INTERVAL {$dead_ttl_days} DAY)");
	}

	/**
	 * @return array{outcome: string, delay_seconds: ?int}
	 */
	public static function resolveFailurePolicy(int $attempts, bool $retryable, int $max_attempts): array
	{
		$attempts = max(0, $attempts);
		$max_attempts = max(1, $max_attempts);

		if ($retryable && $attempts < $max_attempts) {
			return [
				'outcome' => self::FAIL_OUTCOME_RETRY_SCHEDULED,
				'delay_seconds' => self::getRetryDelaySeconds($attempts),
			];
		}

		return [
			'outcome' => self::FAIL_OUTCOME_TERMINAL_DEAD_LETTERED,
			'delay_seconds' => null,
		];
	}

	private static function getRetryDelaySeconds(int $attempts, ?string $job_id = null): int
	{
		$base_delay = min(3600, (int) pow(2, max(1, $attempts)));

		if ($job_id === null || $job_id === '') {
			return $base_delay;
		}

		$jitter_limit = min($base_delay, 60);
		$jitter = (int) ((int) sprintf('%u', crc32($job_id)) % ($jitter_limit + 1));

		return min(3600, $base_delay + $jitter);
	}

	/**
	 * @param array<string, mixed> $row
	 */
	private static function queueIdFromRow(array $row): int
	{
		$queue_id = (int) ($row['queue_id'] ?? 0);

		if ($queue_id <= 0) {
			throw new RuntimeException('Outbound delivery queue row is missing queue_id.');
		}

		return $queue_id;
	}

	/**
	 * @return array<string, mixed>|null
	 */
	private static function selectQueueRowForMutation(string $job_id): ?array
	{
		$stmt = Db::instance()->prepare("SELECT * FROM `" . self::TABLE_QUEUE . "` WHERE job_id = :job_id LIMIT 1 FOR UPDATE");
		$stmt->execute([':job_id' => $job_id]);
		$row = $stmt->fetch(PDO::FETCH_ASSOC);

		return is_array($row) ? $row : null;
	}

	/**
	 * @param array<string, mixed> $data
	 */
	private static function encodeJson(array $data): string
	{
		return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
	}
}
