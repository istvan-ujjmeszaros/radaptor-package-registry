<?php

declare(strict_types=1);

/**
 * @phpstan-type ShapeOutboundDeliveryPayload array<string, mixed>
 * @phpstan-type ShapeOutboundDeliveryHeaders array<string, string>
 */
class OutboundDeliveryJob
{
	public const string TYPE_HTTP_POST_JSON = 'http.post_json';
	public const int DEFAULT_MAX_ATTEMPTS = 5;
	public const int MAX_PAYLOAD_BYTES = 1048576;

	/**
	 * @param ShapeOutboundDeliveryPayload $payload
	 * @param ShapeOutboundDeliveryHeaders $headers
	 */
	public function __construct(
		public string $jobId,
		public string $jobType,
		public string $targetUrl,
		public array $payload,
		public array $headers = [],
		public string $requestedByType = 'system',
		public ?int $requestedById = null,
		public ?string $runAfterUtc = null,
		public int $maxAttempts = self::DEFAULT_MAX_ATTEMPTS,
	) {
	}

	/**
	 * @param ShapeOutboundDeliveryPayload $payload
	 * @param ShapeOutboundDeliveryHeaders $headers
	 */
	public static function httpPostJson(
		string $target_url,
		array $payload,
		array $headers = [],
		string $requested_by_type = 'system',
		?int $requested_by_id = null,
		?string $run_after_utc = null,
		int $max_attempts = self::DEFAULT_MAX_ATTEMPTS,
		?string $job_id = null
	): self {
		return new self(
			$job_id ?? self::createJobId(),
			self::TYPE_HTTP_POST_JSON,
			$target_url,
			$payload,
			$headers,
			$requested_by_type,
			$requested_by_id,
			$run_after_utc,
			$max_attempts
		);
	}

	public static function createJobId(): string
	{
		return 'out_' . bin2hex(random_bytes(16));
	}
}
