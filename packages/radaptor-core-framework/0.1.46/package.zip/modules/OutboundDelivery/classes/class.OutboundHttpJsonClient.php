<?php

declare(strict_types=1);

class OutboundHttpJsonClient
{
	public const string IDEMPOTENCY_HEADER = 'X-Radaptor-Delivery-Job-Id';

	private const int DEFAULT_TIMEOUT_SECONDS = 10;
	private const int DEFAULT_CONNECT_TIMEOUT_SECONDS = 3;
	private const string USER_AGENT = 'RadaptorOutboundDelivery/1.0';

	public function __construct(
		private readonly int $_timeoutSeconds = self::DEFAULT_TIMEOUT_SECONDS,
		private readonly int $_connectTimeoutSeconds = self::DEFAULT_CONNECT_TIMEOUT_SECONDS,
		private readonly string $_userAgent = self::USER_AGENT,
		private readonly int $_maxResponseBytes = 65536,
	) {
	}

	/**
	 * @param array<string, mixed> $payload
	 * @param array<string, string> $headers
	 * @param array<string, string> $framework_headers
	 */
	public function postJson(string $url, array $payload, array $headers = [], array $framework_headers = []): OutboundHttpResponse
	{
		if (!function_exists('curl_init')) {
			throw new OutboundDeliveryException('HTTP_CLIENT_UNAVAILABLE', 'The cURL extension is required for outbound HTTP delivery.', true);
		}

		$endpoint = self::validateUrlForDelivery($url, true);
		$json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
		$body = '';
		$response_size_limit_reached = false;
		$curl = curl_init($endpoint['url']);

		if ($curl === false) {
			throw new OutboundDeliveryException('HTTP_CLIENT_INIT_FAILED', 'Unable to initialize outbound HTTP client.', true);
		}

		$options = [
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $json,
			CURLOPT_HTTPHEADER => $this->buildCurlHeaders($headers, $framework_headers),
			CURLOPT_RETURNTRANSFER => false,
			CURLOPT_WRITEFUNCTION => $this->responseBodyWriteFunction($body, $response_size_limit_reached),
			CURLOPT_FOLLOWLOCATION => false,
			CURLOPT_MAXREDIRS => 0,
			CURLOPT_TIMEOUT => max(1, $this->_timeoutSeconds),
			CURLOPT_CONNECTTIMEOUT => max(1, $this->_connectTimeoutSeconds),
			CURLOPT_SSL_VERIFYHOST => 2,
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_RESOLVE => [$endpoint['curl_resolve']],
			CURLOPT_NOSIGNAL => true,
			CURLOPT_PROXY => '',
		];

		if (defined('CURLOPT_PROTOCOLS_STR')) {
			$options[constant('CURLOPT_PROTOCOLS_STR')] = 'https';
		} elseif (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTPS')) {
			$options[CURLOPT_PROTOCOLS] = CURLPROTO_HTTPS;
		}

		curl_setopt_array($curl, $options);
		$result = curl_exec($curl);
		$curl_errno = curl_errno($curl);
		$curl_error = curl_error($curl);
		$status_code = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
		curl_close($curl);

		if ($result === false && !($response_size_limit_reached && $curl_errno === self::curlWriteErrorCode())) {
			throw new OutboundDeliveryException(
				'HTTP_TRANSPORT_ERROR',
				$curl_error !== '' ? $curl_error : 'Outbound HTTP request failed.',
				self::isCurlErrorRetryable($curl_errno),
				null
			);
		}

		return new OutboundHttpResponse($status_code, $body);
	}

	/**
	 * @return array{
	 *     url: string,
	 *     host: string,
	 *     port: int,
	 *     resolved_ips: list<string>,
	 *     curl_resolve: string
	 * }
	 */
	public static function validateUrlForDelivery(string $url, bool $resolve_dns = true): array
	{
		if ($url !== trim($url)) {
			throw new OutboundDeliveryException('URL_INVALID', 'Outbound delivery URL must not contain leading or trailing whitespace.', false);
		}

		if ($url === '' || preg_match('/[\x00-\x20\x7f]/', $url) === 1) {
			throw new OutboundDeliveryException('URL_INVALID', 'Outbound delivery URL is empty or contains control characters.', false);
		}

		$parts = parse_url($url);

		if (!is_array($parts)) {
			throw new OutboundDeliveryException('URL_INVALID', 'Outbound delivery URL could not be parsed.', false);
		}

		$scheme = strtolower((string) ($parts['scheme'] ?? ''));

		if ($scheme !== 'https') {
			throw new OutboundDeliveryException('URL_SCHEME_NOT_ALLOWED', 'Outbound delivery URL must use https.', false);
		}

		if (isset($parts['user']) || isset($parts['pass'])) {
			throw new OutboundDeliveryException('URL_USERINFO_NOT_ALLOWED', 'Outbound delivery URL must not contain userinfo.', false);
		}

		if (isset($parts['fragment'])) {
			throw new OutboundDeliveryException('URL_FRAGMENT_NOT_ALLOWED', 'Outbound delivery URL must not contain a fragment.', false);
		}

		$host = self::normalizeHost((string) ($parts['host'] ?? ''));
		$port = self::normalizePort($parts['port'] ?? null);
		$resolved_ips = [];

		if (self::isIpLiteral($host)) {
			self::assertSafeIpAddressForDelivery($host);
			$resolved_ips = [$host];
		} else {
			self::assertSafeHostnameForDelivery($host);

			if ($resolve_dns) {
				$resolved_ips = self::resolveHostIps($host);

				foreach ($resolved_ips as $ip) {
					self::assertSafeIpAddressForDelivery($ip);
				}
			}
		}

		return [
			'url' => $url,
			'host' => $host,
			'port' => $port,
			'resolved_ips' => $resolved_ips,
			'curl_resolve' => $resolved_ips === [] ? '' : self::buildCurlResolveEntry($host, $port, $resolved_ips),
		];
	}

	public static function assertSafeIpAddressForDelivery(string $ip): void
	{
		$ip = trim($ip, '[]');

		if (str_starts_with(strtolower($ip), '::ffff:')) {
			$mapped = substr($ip, 7);

			if (filter_var($mapped, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
				$ip = $mapped;
			}
		}

		if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
			throw new OutboundDeliveryException('IP_ADDRESS_NOT_ALLOWED', 'Outbound delivery URL resolves to a private, local, or reserved IP address.', false);
		}

		if (self::isExplicitlyBlockedIpRange($ip)) {
			throw new OutboundDeliveryException('IP_ADDRESS_NOT_ALLOWED', 'Outbound delivery URL resolves to a private, local, or reserved IP address.', false);
		}
	}

	private static function normalizeHost(string $host): string
	{
		$host = strtolower(trim($host));

		if (str_starts_with($host, '[') && str_ends_with($host, ']')) {
			$host = substr($host, 1, -1);
		}

		if ($host === '') {
			throw new OutboundDeliveryException('URL_HOST_MISSING', 'Outbound delivery URL must include a host.', false);
		}

		if (str_ends_with($host, '.')) {
			throw new OutboundDeliveryException('URL_HOST_TRAILING_DOT_NOT_ALLOWED', 'Outbound delivery URL host must not end with a dot.', false);
		}

		return $host;
	}

	private static function normalizePort(mixed $port): int
	{
		if ($port === null) {
			return 443;
		}

		$port = (int) $port;

		if ($port < 1 || $port > 65535) {
			throw new OutboundDeliveryException('URL_PORT_INVALID', 'Outbound delivery URL port is invalid.', false);
		}

		return $port;
	}

	private static function isIpLiteral(string $host): bool
	{
		return filter_var($host, FILTER_VALIDATE_IP) !== false;
	}

	private static function isExplicitlyBlockedIpRange(string $ip): bool
	{
		$cidrs = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false
			? [
				'0.0.0.0/8',
				'10.0.0.0/8',
				'100.64.0.0/10',
				'127.0.0.0/8',
				'169.254.0.0/16',
				'172.16.0.0/12',
				'192.0.0.0/24',
				'192.0.2.0/24',
				'192.168.0.0/16',
				'198.18.0.0/15',
				'198.51.100.0/24',
				'203.0.113.0/24',
				'224.0.0.0/4',
				'240.0.0.0/4',
			]
			: [
				'::/128',
				'::1/128',
				'::ffff:0:0/96',
				'64:ff9b::/96',
				'100::/64',
				'2001::/23',
				'2001:db8::/32',
				'fc00::/7',
				'fe80::/10',
				'ff00::/8',
			];

		foreach ($cidrs as $cidr) {
			if (self::ipInCidr($ip, $cidr)) {
				return true;
			}
		}

		return false;
	}

	private static function ipInCidr(string $ip, string $cidr): bool
	{
		[$range, $prefix_length] = explode('/', $cidr, 2);
		$ip_bin = inet_pton($ip);
		$range_bin = inet_pton($range);

		if ($ip_bin === false || $range_bin === false || strlen($ip_bin) !== strlen($range_bin)) {
			return false;
		}

		$prefix_length = (int) $prefix_length;
		$full_bytes = intdiv($prefix_length, 8);
		$remaining_bits = $prefix_length % 8;

		if ($full_bytes > 0 && substr($ip_bin, 0, $full_bytes) !== substr($range_bin, 0, $full_bytes)) {
			return false;
		}

		if ($remaining_bits === 0) {
			return true;
		}

		$mask = (0xff << (8 - $remaining_bits)) & 0xff;

		return (ord($ip_bin[$full_bytes]) & $mask) === (ord($range_bin[$full_bytes]) & $mask);
	}

	private static function assertSafeHostnameForDelivery(string $host): void
	{
		if (preg_match('/^[0-9.]+$/', $host) === 1 || str_contains($host, ':')) {
			throw new OutboundDeliveryException('URL_HOST_INVALID', 'Outbound delivery URL host is not a valid hostname or IP address.', false);
		}

		if (preg_match('/^[a-z0-9.-]+$/', $host) !== 1) {
			throw new OutboundDeliveryException('URL_HOST_INVALID', 'Outbound delivery URL host contains unsupported characters.', false);
		}

		if (!str_contains($host, '.')) {
			throw new OutboundDeliveryException('URL_HOST_NOT_ALLOWED', 'Outbound delivery URL host must be a fully qualified external hostname.', false);
		}

		foreach (['localhost', '.localhost', '.local', '.localdomain', '.internal', '.test', '.invalid'] as $blocked_suffix) {
			if ($host === ltrim($blocked_suffix, '.') || str_ends_with($host, $blocked_suffix)) {
				throw new OutboundDeliveryException('URL_HOST_NOT_ALLOWED', 'Outbound delivery URL host is local or reserved.', false);
			}
		}
	}

	/**
	 * @return list<string>
	 */
	private static function resolveHostIps(string $host): array
	{
		$ips = [];
		$records = dns_get_record($host, DNS_A | DNS_AAAA);

		if (is_array($records)) {
			foreach ($records as $record) {
				foreach (['ip', 'ipv6'] as $key) {
					$value = $record[$key] ?? null;

					if (is_string($value) && filter_var($value, FILTER_VALIDATE_IP) !== false) {
						$ips[$value] = true;
					}
				}
			}
		}

		if ($ips === []) {
			$fallback = gethostbynamel($host);

			if (is_array($fallback)) {
				foreach ($fallback as $ip) {
					if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
						$ips[$ip] = true;
					}
				}
			}
		}

		if ($ips === []) {
			throw new OutboundDeliveryException('DNS_RESOLUTION_FAILED', 'Outbound delivery URL host did not resolve to an IP address.', true);
		}

		return array_keys($ips);
	}

	/**
	 * @param list<string> $ips
	 */
	private static function buildCurlResolveEntry(string $host, int $port, array $ips): string
	{
		$curl_host = str_contains($host, ':') ? '[' . $host . ']' : $host;
		$curl_ips = array_map(
			static fn (string $ip): string => str_contains($ip, ':') ? '[' . $ip . ']' : $ip,
			$ips
		);

		return $curl_host . ':' . $port . ':' . implode(',', $curl_ips);
	}

	/**
	 * @param array<string, string> $headers
	 * @param array<string, string> $framework_headers
	 * @return list<string>
	 */
	private function buildCurlHeaders(array $headers, array $framework_headers = []): array
	{
		$curl_headers = [
			'Content-Type: application/json',
			'Accept: application/json',
			'User-Agent: ' . $this->_userAgent,
			'Expect:',
		];

		foreach ($headers as $name => $value) {
			$name = trim((string) $name);
			$value = trim((string) $value);

			if ($name === '' || preg_match('/^[A-Za-z0-9-]+$/', $name) !== 1 || preg_match('/[\r\n]/', $value) === 1) {
				throw new OutboundDeliveryException('HTTP_HEADER_INVALID', 'Outbound delivery HTTP header is invalid.', false);
			}

			if (in_array(strtolower($name), $this->controlledHeaderNames(), true)) {
				throw new OutboundDeliveryException('HTTP_HEADER_NOT_ALLOWED', 'Outbound delivery HTTP header is controlled by the framework.', false);
			}

			$curl_headers[] = $name . ': ' . $value;
		}

		foreach ($framework_headers as $name => $value) {
			$name = trim((string) $name);
			$value = trim((string) $value);

			if ($name === '' || preg_match('/^[A-Za-z0-9-]+$/', $name) !== 1 || preg_match('/[\r\n]/', $value) === 1) {
				throw new OutboundDeliveryException('HTTP_HEADER_INVALID', 'Outbound delivery HTTP header is invalid.', false);
			}

			$curl_headers[] = $name . ': ' . $value;
		}

		return $curl_headers;
	}

	/**
	 * @return list<string>
	 */
	private function controlledHeaderNames(): array
	{
		return [
			'host',
			'content-length',
			'content-type',
			'accept',
			'user-agent',
			'transfer-encoding',
			'connection',
			strtolower(self::IDEMPOTENCY_HEADER),
		];
	}

	private function responseBodyWriteFunction(string &$body, bool &$response_size_limit_reached): callable
	{
		$max_response_bytes = max(0, $this->_maxResponseBytes);

		return static function ($curl, string $chunk) use (&$body, &$response_size_limit_reached, $max_response_bytes): int {
			unset($curl);

			$chunk_length = strlen($chunk);
			$remaining_bytes = $max_response_bytes - strlen($body);

			if ($remaining_bytes > 0) {
				$body .= substr($chunk, 0, $remaining_bytes);
			}

			if ($chunk_length > $remaining_bytes) {
				$response_size_limit_reached = true;

				return 0;
			}

			return $chunk_length;
		};
	}

	private static function curlWriteErrorCode(): int
	{
		return defined('CURLE_WRITE_ERROR') ? (int)constant('CURLE_WRITE_ERROR') : 23;
	}

	private static function isCurlErrorRetryable(int $curl_errno): bool
	{
		$retryable = [
			defined('CURLE_COULDNT_RESOLVE_HOST') ? constant('CURLE_COULDNT_RESOLVE_HOST') : 6,
			defined('CURLE_COULDNT_CONNECT') ? constant('CURLE_COULDNT_CONNECT') : 7,
			defined('CURLE_OPERATION_TIMEDOUT') ? constant('CURLE_OPERATION_TIMEDOUT') : 28,
			defined('CURLE_GOT_NOTHING') ? constant('CURLE_GOT_NOTHING') : 52,
			defined('CURLE_SEND_ERROR') ? constant('CURLE_SEND_ERROR') : 55,
			defined('CURLE_RECV_ERROR') ? constant('CURLE_RECV_ERROR') : 56,
		];

		return in_array($curl_errno, $retryable, true);
	}
}
