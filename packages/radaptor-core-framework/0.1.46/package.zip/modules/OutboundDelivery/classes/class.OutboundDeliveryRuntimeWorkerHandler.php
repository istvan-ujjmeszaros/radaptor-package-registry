<?php

declare(strict_types=1);

class OutboundDeliveryRuntimeWorkerHandler implements iRuntimeWorkerHandler
{
	public function __construct(private readonly ?OutboundHttpJsonClient $_client = null)
	{
	}

	public function getWorkerType(): string
	{
		return OutboundDeliveryWorker::WORKER_TYPE;
	}

	public function getQueueName(): string
	{
		return OutboundDeliveryWorker::QUEUE_NAME;
	}

	public function getSleepMilliseconds(): int
	{
		return OutboundDeliveryWorker::getWorkerSleepMilliseconds();
	}

	public function getStaleAfterSeconds(): int
	{
		return OutboundDeliveryWorker::getStaleAfterSeconds();
	}

	public function getPurgeIntervalSeconds(): int
	{
		return OutboundDeliveryWorker::getPurgeIntervalSeconds();
	}

	public function getMetadata(): array
	{
		return [
			'handler_class' => self::class,
			'queue_family' => 'outbound_delivery',
		];
	}

	public function runOnce(?string $worker_instance_id = null): bool
	{
		return OutboundDeliveryWorker::runOnce($worker_instance_id, $this->_client);
	}

	public function purgeArchives(): void
	{
		OutboundDeliveryStorage::purgeArchives();
	}
}
