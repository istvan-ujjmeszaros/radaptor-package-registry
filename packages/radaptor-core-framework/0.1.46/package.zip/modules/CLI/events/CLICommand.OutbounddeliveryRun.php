<?php

/**
 * Run the outbound delivery queue worker.
 *
 * Usage:
 *   radaptor outbounddelivery:run [--once]
 */
class CLICommandOutbounddeliveryRun extends AbstractCLICommand
{
	public function getName(): string
	{
		return 'Run outbound delivery queue workers';
	}

	public function getDocs(): string
	{
		return <<<'DOC'
			Run the outbound delivery queue worker.

			Usage: radaptor outbounddelivery:run [--once]

			Examples:
			  radaptor outbounddelivery:run
			  radaptor outbounddelivery:run --once
			DOC;
	}

	public function isWebRunnable(): bool
	{
		return true;
	}

	public function getWebParams(): array
	{
		return [
			['name' => 'once', 'label' => 'Run once', 'type' => 'flag', 'default' => '1'],
		];
	}

	public function getRiskLevel(): string
	{
		return 'mutation';
	}

	public function run(): void
	{
		$runOnce = Request::hasArg('once');

		echo 'Queue worker mode: outbound delivery' . ($runOnce ? " (once)\n" : " (forever)\n");

		if ($runOnce) {
			OutboundDeliveryWorker::runOnce();
			echo "Queue worker run finished.\n";

			return;
		}

		OutboundDeliveryWorker::runForever();
	}
}
