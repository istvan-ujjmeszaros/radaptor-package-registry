<?php

declare(strict_types=1);

interface iRuntimeWorkerHandler
{
	public function getWorkerType(): string;

	public function getQueueName(): string;

	public function getSleepMilliseconds(): int;

	public function getStaleAfterSeconds(): int;

	public function getPurgeIntervalSeconds(): int;

	/**
	 * @return array<string, mixed>
	 */
	public function getMetadata(): array;

	public function runOnce(?string $worker_instance_id = null): bool;

	public function purgeArchives(): void;
}
