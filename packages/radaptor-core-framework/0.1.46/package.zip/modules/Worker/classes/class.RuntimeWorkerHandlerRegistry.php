<?php

declare(strict_types=1);

class RuntimeWorkerHandlerRegistry
{
	public const string SCOPE_SEPARATOR = ',';
	public const string SCOPE_PART_SEPARATOR = ':';
	// Keep the runtime fallback email-only for older deployments; apps opt into additional scopes via RADAPTOR_WORKER_SCOPES.
	public const string DEFAULT_SCOPE_LIST = EmailQueueWorker::WORKER_TYPE . ':' . EmailQueueWorker::QUEUE_NAME;

	/**
	 * @return list<iRuntimeWorkerHandler>
	 */
	public static function getHandlersForScopeList(?string $scope_list = null): array
	{
		$scope_list = trim((string) ($scope_list ?? self::DEFAULT_SCOPE_LIST));

		if ($scope_list === '') {
			$scope_list = self::DEFAULT_SCOPE_LIST;
		}

		$handlers = [];

		foreach (self::parseScopeList($scope_list) as $scope) {
			$handlers[] = self::getHandler($scope['worker_type'], $scope['queue_name']);
		}

		return $handlers;
	}

	/**
	 * @return list<array{worker_type: string, queue_name: string}>
	 */
	public static function parseScopeList(string $scope_list): array
	{
		$scopes = [];

		foreach (explode(self::SCOPE_SEPARATOR, $scope_list) as $scope) {
			$scope = trim($scope);

			if ($scope === '') {
				continue;
			}

			$parts = explode(self::SCOPE_PART_SEPARATOR, $scope, 2);

			if (count($parts) !== 2 || trim($parts[0]) === '' || trim($parts[1]) === '') {
				throw new InvalidArgumentException('Invalid runtime worker scope: ' . $scope);
			}

			$scopes[] = [
				'worker_type' => trim($parts[0]),
				'queue_name' => trim($parts[1]),
			];
		}

		if ($scopes === []) {
			throw new InvalidArgumentException('At least one runtime worker scope is required.');
		}

		return $scopes;
	}

	public static function getHandler(string $worker_type, string $queue_name): iRuntimeWorkerHandler
	{
		if ($worker_type === EmailQueueWorker::WORKER_TYPE && $queue_name === EmailQueueWorker::QUEUE_NAME) {
			return new EmailQueueRuntimeWorkerHandler();
		}

		if ($worker_type === OutboundDeliveryWorker::WORKER_TYPE && $queue_name === OutboundDeliveryWorker::QUEUE_NAME) {
			return new OutboundDeliveryRuntimeWorkerHandler();
		}

		throw new InvalidArgumentException("Unknown runtime worker scope: {$worker_type}/{$queue_name}");
	}

	/**
	 * @return list<array{worker_type: string, queue_name: string}>
	 */
	public static function getMigrationSensitiveScopes(): array
	{
		return [
			[
				'worker_type' => EmailQueueWorker::WORKER_TYPE,
				'queue_name' => EmailQueueWorker::QUEUE_NAME,
			],
			[
				'worker_type' => OutboundDeliveryWorker::WORKER_TYPE,
				'queue_name' => OutboundDeliveryWorker::QUEUE_NAME,
			],
		];
	}

	public static function getStaleAfterSeconds(string $worker_type, string $queue_name): int
	{
		return self::getHandler($worker_type, $queue_name)->getStaleAfterSeconds();
	}
}
