<?php

declare(strict_types=1);

class RuntimeSwooleQueueWorkerRunner
{
	public static function runFromEnvironment(): void
	{
		if (!class_exists(Swoole\Coroutine::class)) {
			throw new RuntimeException('Swoole extension is not available.');
		}

		$scope_list = getenv('RADAPTOR_WORKER_SCOPES');
		$handlers = RuntimeWorkerHandlerRegistry::getHandlersForScopeList(is_string($scope_list) ? $scope_list : null);
		$stop_requested = false;

		\Swoole\Coroutine\run(static function () use ($handlers, &$stop_requested): void {
			\Swoole\Process::signal(SIGTERM, static function () use (&$stop_requested): void {
				$stop_requested = true;
			});
			\Swoole\Process::signal(SIGINT, static function () use (&$stop_requested): void {
				$stop_requested = true;
			});

			RuntimeWorkerLoop::runForever(
				$handlers,
				static fn (): bool => $stop_requested,
				static fn (float $seconds): mixed => \Swoole\Coroutine::sleep($seconds),
				[
					'command' => 'bin/swoole_queue_worker.php',
					'runtime' => 'swoole',
				]
			);
		});
	}
}
