<?php

declare(strict_types=1);

class RuntimeWorkerLoop
{
	/**
	 * @param list<iRuntimeWorkerHandler> $handlers
	 * @param (callable(): bool)|null $should_stop
	 * @param (callable(float): void)|null $sleep
	 * @param array<string, mixed> $metadata
	 */
	public static function runForever(array $handlers, ?callable $should_stop = null, ?callable $sleep = null, array $metadata = []): void
	{
		$handlers = self::normalizeHandlers($handlers);
		$should_stop ??= static fn (): bool => false;
		$sleep ??= static fn (float $seconds): mixed => usleep((int) max(1, round($seconds * 1000000)));
		$worker_instance_ids = self::registerHandlers($handlers, $metadata);
		$next_purge_at = self::initializePurgeSchedule($handlers, time());

		try {
			while (!$should_stop()) {
				$processed = self::runPass($handlers, $worker_instance_ids, $next_purge_at, time());

				if (!$processed) {
					$sleep(self::resolveSleepSeconds($handlers));
				}
			}
		} finally {
			self::markStopping($handlers, $worker_instance_ids);
		}
	}

	public static function runHandlerOnce(iRuntimeWorkerHandler $handler): bool
	{
		$metadata = ['command' => 'worker:run', 'runtime' => 'cli-once'];
		$worker_instance_id = RuntimeWorkerRegistry::register($handler->getWorkerType(), $handler->getQueueName(), array_merge($metadata, $handler->getMetadata()));

		try {
			return $handler->runOnce($worker_instance_id);
		} finally {
			RuntimeWorkerRegistry::markStopping($worker_instance_id, $handler->getWorkerType(), $handler->getQueueName());
		}
	}

	/**
	 * @param list<iRuntimeWorkerHandler> $handlers
	 * @param array<string, string|null> $worker_instance_ids
	 * @param array<string, int> $next_purge_at
	 * @param (callable(iRuntimeWorkerHandler): bool)|null $is_pause_active
	 */
	public static function runPass(array $handlers, array $worker_instance_ids, array &$next_purge_at, int $now, ?callable $is_pause_active = null): bool
	{
		$is_pause_active ??= static fn (iRuntimeWorkerHandler $handler): bool => self::hasActivePauseRequest($handler);
		$processed = false;

		foreach (self::normalizeHandlers($handlers) as $handler) {
			$scope_key = self::scopeKey($handler);
			$handler_processed = $handler->runOnce($worker_instance_ids[$scope_key] ?? null);

			if (($next_purge_at[$scope_key] ?? 0) <= $now && !$is_pause_active($handler)) {
				$handler->purgeArchives();
				$next_purge_at[$scope_key] = $now + max(1, $handler->getPurgeIntervalSeconds());
			}

			$processed = $handler_processed || $processed;
		}

		return $processed;
	}

	public static function scopeKey(iRuntimeWorkerHandler $handler): string
	{
		return $handler->getWorkerType() . '/' . $handler->getQueueName();
	}

	/**
	 * @param list<iRuntimeWorkerHandler> $handlers
	 * @return list<iRuntimeWorkerHandler>
	 */
	private static function normalizeHandlers(array $handlers): array
	{
		$normalized = [];

		foreach ($handlers as $handler) {
			if (!$handler instanceof iRuntimeWorkerHandler) {
				throw new InvalidArgumentException('Runtime worker handlers must implement iRuntimeWorkerHandler.');
			}

			$normalized[] = $handler;
		}

		if ($normalized === []) {
			throw new InvalidArgumentException('At least one runtime worker handler is required.');
		}

		return $normalized;
	}

	/**
	 * @param list<iRuntimeWorkerHandler> $handlers
	 * @param array<string, mixed> $metadata
	 * @return array<string, string|null>
	 */
	private static function registerHandlers(array $handlers, array $metadata): array
	{
		$worker_instance_ids = [];

		foreach ($handlers as $handler) {
			$scope_key = self::scopeKey($handler);
			$handler_metadata = array_merge($metadata, $handler->getMetadata());
			$worker_instance_ids[$scope_key] = RuntimeWorkerRegistry::register($handler->getWorkerType(), $handler->getQueueName(), $handler_metadata);
		}

		return $worker_instance_ids;
	}

	/**
	 * @param list<iRuntimeWorkerHandler> $handlers
	 * @return array<string, int>
	 */
	private static function initializePurgeSchedule(array $handlers, int $now): array
	{
		$next_purge_at = [];

		foreach ($handlers as $handler) {
			$next_purge_at[self::scopeKey($handler)] = $now + max(1, $handler->getPurgeIntervalSeconds());
		}

		return $next_purge_at;
	}

	/**
	 * @param list<iRuntimeWorkerHandler> $handlers
	 */
	private static function resolveSleepSeconds(array $handlers): float
	{
		$sleep_ms = null;

		foreach ($handlers as $handler) {
			$value = max(1, $handler->getSleepMilliseconds());
			$sleep_ms = $sleep_ms === null ? $value : min($sleep_ms, $value);
		}

		return max(0.001, (float) ($sleep_ms ?? 1) / 1000);
	}

	private static function hasActivePauseRequest(iRuntimeWorkerHandler $handler): bool
	{
		if (!class_exists(RuntimeWorkerPauseControl::class)) {
			return false;
		}

		return is_array(RuntimeWorkerPauseControl::getActivePauseRequest($handler->getWorkerType(), $handler->getQueueName()));
	}

	/**
	 * @param list<iRuntimeWorkerHandler> $handlers
	 * @param array<string, string|null> $worker_instance_ids
	 */
	private static function markStopping(array $handlers, array $worker_instance_ids): void
	{
		foreach ($handlers as $handler) {
			RuntimeWorkerRegistry::markStopping($worker_instance_ids[self::scopeKey($handler)] ?? null, $handler->getWorkerType(), $handler->getQueueName());
		}
	}
}
