<?php

declare(strict_types=1);

/**
 * Add the generic outbound delivery queue foundation.
 *
 * Queue tables are runtime state and are excluded from audit/export flows.
 */
class Migration_20260529_090000_add_outbound_delivery_queue
{
	public function run(): void
	{
		$pdo = Db::instance();

		$pdo->exec("CREATE TABLE IF NOT EXISTS `outbound_delivery_queue` (
			`queue_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			`job_id` VARCHAR(64) NOT NULL,
			`job_type` VARCHAR(128) NOT NULL,
			`target_url` VARCHAR(2048) NOT NULL,
			`headers_json` LONGTEXT NULL,
			`payload_json` LONGTEXT NOT NULL,
			`requested_by_type` VARCHAR(32) NOT NULL,
			`requested_by_id` INT NULL,
			`status` ENUM('pending','reserved','retry_wait') NOT NULL DEFAULT 'pending',
			`attempts` INT NOT NULL DEFAULT 0,
			`max_attempts` INT NOT NULL DEFAULT 5,
			`run_after_utc` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`reserved_at` DATETIME NULL,
			`last_http_status` SMALLINT UNSIGNED NULL,
			`last_error_code` VARCHAR(64) NULL,
			`last_error_message` TEXT NULL,
			`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			`updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (`queue_id`),
			UNIQUE KEY `uq_outbound_delivery_queue_job_id` (`job_id`),
			KEY `idx_outbound_delivery_queue_poll` (`status`, `run_after_utc`, `queue_id`),
			KEY `idx_outbound_delivery_queue_requested_by` (`requested_by_type`, `requested_by_id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='__noaudit, __noexport:disaster_recovery'");

		$pdo->exec("CREATE TABLE IF NOT EXISTS `outbound_delivery_archive` (
			`archive_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			`job_id` VARCHAR(64) NOT NULL,
			`job_type` VARCHAR(128) NOT NULL,
			`target_url` VARCHAR(2048) NOT NULL,
			`headers_json` LONGTEXT NULL,
			`payload_json` LONGTEXT NOT NULL,
			`requested_by_type` VARCHAR(32) NOT NULL,
			`requested_by_id` INT NULL,
			`attempts` INT NOT NULL DEFAULT 0,
			`http_status` SMALLINT UNSIGNED NULL,
			`response_body_preview` TEXT NULL,
			`completed_at` DATETIME NOT NULL,
			`created_at` DATETIME NOT NULL,
			`archived_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`archive_id`),
			KEY `idx_outbound_delivery_archive_job_id` (`job_id`),
			KEY `idx_outbound_delivery_archive_ttl` (`archived_at`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='__noaudit, __noexport:disaster_recovery'");

		$pdo->exec("CREATE TABLE IF NOT EXISTS `outbound_delivery_dead_letter` (
			`dead_letter_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			`job_id` VARCHAR(64) NOT NULL,
			`job_type` VARCHAR(128) NOT NULL,
			`target_url` VARCHAR(2048) NOT NULL,
			`headers_json` LONGTEXT NULL,
			`payload_json` LONGTEXT NOT NULL,
			`requested_by_type` VARCHAR(32) NOT NULL,
			`requested_by_id` INT NULL,
			`attempts` INT NOT NULL DEFAULT 0,
			`last_http_status` SMALLINT UNSIGNED NULL,
			`error_code` VARCHAR(64) NULL,
			`error_message` TEXT NULL,
			`created_at` DATETIME NOT NULL,
			`dead_lettered_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`dead_letter_id`),
			KEY `idx_outbound_delivery_dead_letter_job_id` (`job_id`),
			KEY `idx_outbound_delivery_dead_letter_ttl` (`dead_lettered_at`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='__noaudit, __noexport:disaster_recovery'");
	}

	public function getDescription(): string
	{
		return 'Add outbound delivery queue, archive, and dead-letter tables.';
	}
}
